<?php

//Ushbu kod @UzbekSeenBot kodi bo'lib, @SARVAR_6364 TUZIB CHIQGAN
$orderschannel = "@Mukammal_Paychannel";
$paychannel = "@Mukammal_Paychannel";
$simkey = "4f752fA51b4c7e7d738d47bbA3668c33";
$simfoiz = "40";
$simrub = "150";
$me = "🛎️";
$payme_id = "50501034642726770725";

session_start();
date_default_timezone_set("Asia/Tashkent");
$time = date('H:i');
$timeq = date('H:i:s');

ob_start();
define('API_KEY',"7865877315:AAHsv4B-R2LKyEd2EMPdpSmMFktV8xWDa_A");
$admin="6570342010";
$bot=bot(getMe)->result->username;
$day = date('d');

function enc($var,$exception) {
if($var=="encode"){
return base64_encode($exception);
}elseif($var=="decode"){
return base64_decode($exception);
}
}

function keyboard($a=[]){
$d=json_encode([
inline_keyboard=>$a
]);
return $d;
}

function api_query($s){
$qas = array("ssl"=>array("verify_peer"=>false,"verify_peer_name"=>false));
$content = file_get_contents($s, false, stream_context_create($qas));
return $content ? $content : json_encode(['balance'=>" ?"]);
}

require ("../app/controller/sql_connect.php");

	

function arr($p){
global $connect;
$s = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `providers` WHERE id = $p"));
$data = json_decode(file_get_contents($s['api_url']."?key=".$s['api_key']."&action=services"),1);
$values=[];
$new_arr = [];
$co=0;
foreach($data as $value){

if(!in_array($value['category'], $new_arr)){
$new_arr[] = $value['category'];
$co++;
$values[] =['id'=>$co,'name'=>$value['category']];
}else{
continue;
}
}
$val = ['count'=>$co,'results'=>$values];
return $values ? json_encode($val) : json_encode(["error"=>1]);
}



function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

function deleteFolder($path){
if(is_dir($path) === true){
$files = array_diff(scandir($path), array('.', '..'));
foreach ($files as $file)
deleteFolder(realpath($path) . '/' . $file);
return rmdir($path);
}else if (is_file($path) === true)
return unlink($path);
return false;
}

function token($str,$begin,$end){
for($i = $begin; $i < $end; $i++) $str[$i] = '*';
return $str;
}

function rmdirPro($path){
    $scan = array_diff(scandir($path), ['.','..']);
    foreach($scan as $value){
        if(is_dir("{$path}/{$value}"))
            rmdirPro("{$path}/{$value}");
        else
            @unlink("{$path}/{$value}");
    }
    rmdir($path);
}



function trans($x){
$e = json_decode(file_get_contents("http://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=uz&dt=t&q=".urlencode($x).""),1);
return $e[0][0][0];
}







function number($a){
$form = number_format($a,00,' ',' ');
return $form;
}

function del(){
global $cid,$mid,$chat_id,$message_id;
return bot('deleteMessage',[
'chat_id'=>$chat_id.$cid,
'message_id'=>$message_id.$mid,
]);
}


function edit($id,$mid,$tx,$m){
return bot('editMessageText',[
'chat_id'=>$id,
'message_id'=>$mid,
'text'=>$tx,
'parse_mode'=>"HTML",
'reply_markup'=>$m,
]);
}



function sms($id,$tx,$m){
return bot('sendMessage',[
'chat_id'=>$id,
'text'=>$tx,
'parse_mode'=>"HTML",
'reply_markup'=>$m,
]);
}

function referal($hi){
    $daten = [];
    $rev = [];
    $fayllar = glob("./user/*.*");
    foreach($fayllar as $file){
        if(mb_stripos($file,".users")!==false){
        $value = file_get_contents($file);
        $id = str_replace(["./user/",".users"],["",""],$file);
        $daten[$value] = $id;
        $rev[$id] = $value;
        }
        echo $file;
    }

    asort($rev);
    $reversed = array_reverse($rev);
    for($i=0;$i<$hi;$i+=1){
        $order = $i+1;
        $id = $daten["$reversed[$i]"];
        $ism=bot('getChat',[
        'chat_id'=>$id,
        ])->result->first_name;
        
        $text.= "<b>{$order}</b>. <a href='tg://user?id={$id}'>".str_replace(["<",">","𒐫"],["","",""],$ism)."</a> - "."<code>".floor($reversed[$i])."</code>"." <b> ta</b>"."\n";
    }
    return $text;
}


function get($h){
return file_get_contents($h);
}

function put($h,$r){
file_put_contents($h,$r);
}


if(get("set/kunlik.bonus")){
}else{
if(put("set/kunlik.bonus","0"));
}

if(get("set/xolat.txt")){
}else{
if(put("set/xolat.txt","✅"));
}


function adduser($cid){
	global $connect;
$result = mysqli_query($connect, "SELECT * FROM users WHERE id = $cid");
$row = mysqli_fetch_assoc($result);
if($row){
}else{
$key = md5(uniqid());
$referal = generate();
$rew = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM users"));
$news = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users ORDER BY user_id DESC LIMIT 1"))['user_id'];
$new = $news + 1;
if(empty($key) or empty($referal) or empty($new)){
sms($cid,"<b>⛔ Bazaga saqlanishda xatolik yuz berdi!\n\n✅ Qaytadan /start bosing</b>",null);
} else {
mysqli_query($connect,"INSERT INTO users(`user_id`,`id`,`status`,`balance`,`outing`,`api_key`,`referal`) VALUES ('$new','$cid','active','0','0','$key','$referal');");
}
}
}



function joinchat($id){
$array = array("inline_keyboard");
$get = file_get_contents("set/channel");
$ex = explode("\n",$get);
$soni = substr_count($get,"@");
if($get == null){
return true;
}else{
for($i=0;$i<=count($ex)-1;$i++){
$first_line = $ex[$i];
$kanall=str_replace("@","",$first_line);
     $ret = bot("getChatMember",[
         "chat_id"=>$first_line,
         "user_id"=>$id,
         ]);
             $reti = bot("getChat",[
         "chat_id"=>$first_line,
         ]);
         $ch_namee = $reti->result->title;
$stat = $ret->result->status;
         if((($stat=="creator" or $stat=="administrator" or $stat=="member"))){
 $array['inline_keyboard']["$i"][0]['text'] = "";
$array['inline_keyboard']["$i"][0]['url'] = "https://t.me/$kanall";
         }else{
$array['inline_keyboard']["$i"][0]['text'] = $ch_namee;
$array['inline_keyboard']["$i"][0]['url'] = "https://t.me/$kanall";
$uns = true;
}
}
$array['inline_keyboard']["$i"][0]['text'] = "✅ Tekshirish";
$array['inline_keyboard']["$i"][0]['callback_data'] = "result";
if($uns == true){
     bot('sendMessage',[
         'chat_id'=>$id,
         'text'=>"⛔ <b>Botdan foydalanish uchun, quyidagi kanallarga obuna bo'ling:</b>",
'parse_mode'=>html,
'reply_markup'=>json_encode($array),
]);
}else{
return true;
}
}
}


$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$edituz = $update->callback_query->message->from->id;
$mesuz = $update->callback_query->message->message_id;
$cid = $message->chat->id;
$cidtyp = $message->chat->type;
$miid = $message->message_id;
$name = $message->chat->first_name;
$user1 = $message->from->username;
$tx = $message->text;
$callback = $update->callback_query;
$mmid = $callback->inline_message_id;
$mes = $callback->message;
$mid = $mes->message_id;
$cmtx = $mes->text;
$mmid = $callback->inline_message_id;
$idd = $callback->message->chat->id;
$cbid = $callback->from->id;
$cbuser = $callback->from->username;
$data = $callback->data;
$ida = $callback->id;
$cqid = $update->callback_query->id;
$qid=$cqid;
$cbins = $callback->chat_instance;
$cbchtyp = $callback->message->chat->type;
$step = file_get_contents("step/$from_id.step");
$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$mid = $message->message_id;
$msgs = json_decode(file_get_contents('msgs.json'),true);
$data = $update->callback_query->data;
$type = $message->chat->type;
$text = $message->text;
$sd = $message->text;
$uid= $message->from->id;
$gname = $message->chat->title;
$left = $message->left_chat_member;
$new = $message->new_chat_member;
$name = $message->from->first_name;
$bio = $message->from->about;
$repid = $message->reply_to_message->from->id;
$repname = $message->reply_to_message->from->first_name;
$newid = $message->new_chat_member->id;
$leftid = $message->left_chat_member->id;

$botdel = $update->my_chat_member->new_chat_member;
$botdel_id = $update->my_chat_member->from->id;
$userstatus = $botdel->status;

$newname = $message->new_chat_member->first_name;
$leftname = $message->left_chat_member->first_name;
$username = $message->from->username;
$cmid = $update->callback_query->message->message_id;
$cusername = $message->chat->username;
$repmid = $message->reply_to_message->message_id; 
$ccid = $update->callback_query->message->chat->id;
$cuid = $update->callback_query->message->from->id;
$from_id = $message->from->id;
$chat_id = $update->callback_query->message->chat->id;
$message_id = $update->callback_query->message->message_id;
$call = $update->callback_query;
$mes = $call->message;
$data = $call->data;
$qid = $call->id;
$callbackdata = $update->callback_query->data;
$callcid = $mes->chat->id;
$callmid = $mes->message_id;
$callfrid = $call->from->id;
$calluser = $mes->chat->username;
$callfname = $call->from->first_name;
$photo = $message->photo;
$gif = $message->animation;
$video = $message->video;
$music = $message->audio;
$voice = $message->voice;
$sticker = $message->sticker;
$document = $message->document;
$for = $message->forward_from;
$for_id=$for->id;
$contact = $message->contact;
$nomer_id = $contact->user_id;
$nomer_user = $contact->username;
$nomet_name = $contact->first_name;
$nomer_ph = $contact->phone_number;
$Tc = $update->callback_query->message->chat->type;
$cid2=$chat_id;
$mid2=$message_id;
$sana=date("d/m/Y | H:i");

$res = mysqli_query($connect,"SELECT*FROM user_id WHERE user_id=$cid");
while($a = mysqli_fetch_assoc($res)){
$user_id = $a['user_id'];
$reg = $a['reg'];
}

$res = mysqli_query($connect,"SELECT*FROM kabinet WHERE user_id = $cid");
while($a = mysqli_fetch_assoc($res)){
$kab_id = $a['user_id'];
$pul = $a['pul'];
$pul2 = $a['pul2'];
$odam = $a['odam'];
$ban = $a['ban'];
$status = $a['status'];
}

$res = mysqli_query($connect,"SELECT*FROM card WHERE user_id = $cid");
while($a = mysqli_fetch_assoc($res)){
$cc = $a['cc'];
$fc = $a['fc'];
}

$res = mysqli_query($connect,"SELECT*FROM uid WHERE user_id = $cid");
while($a = mysqli_fetch_assoc($res)){
$fid = $a['uid'];
}

$res = mysqli_query($connect,"SELECT*FROM api WHERE user_id = $cid");
while($a = mysqli_fetch_assoc($res)){
$api_id = $a['user_id'];
$api = $a['api'];
}

function generate(){
$arr = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','R','S','T','U','V','X','Y','Z','1','2','3','4','5','6','7','8','9','0');
$pass = "";
for($i = 0; $i < 7; $i++){
$index = rand(0, count($arr) - 1);
$pass .= $arr[$index];
}
return $pass;
}

if($text){
$reres = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM soxta WHERE user_id = '$cid'"));
if($reres){
mysqli_query($connect,"UPDATE soxta SET come = 'come' WHERE user_id = $cid");
}}

$delname = $update->my_chat_member->from->first_name;
if($botdel){
$reres = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM soxta WHERE user_id = '$botdel_id'"))['id'];
if($userstatus == "kicked"){
$res = mysqli_query($connect,"SELECT * FROM users WHERE user_id = $botdel_id");
$rew = mysqli_fetch_assoc($res);
if($rew['status']=="deactive"){
exit();
}else{
if($reres){
sms($admin,"<b>Foydalanuvchi botni yana blokladi !</b>",json_encode(['inline_keyboard'=>[[['text'=>"$delname",'url'=>"tg://user?id=$botdel_id"]]]]));
mysqli_query($connect, "DELETE FROM myorder WHERE user_id = '$botdel_id'");
mysqli_query($connect,"UPDATE soxta SET come = 'gone' WHERE user_id = $botdel_id");
}else{
mysqli_query($connect, "DELETE FROM myorder WHERE user_id = '$botdel_id'");
mysqli_query($connect, "DELETE FROM users WHERE id = '$botdel_id'");
$ok = mysqli_query($connect, "INSERT INTO soxta(`user_id`,`come`) VALUES ('$botdel_id','gone')")->ok;
if($ok){$ax="1";}else{$ax="0";}
sms($admin,"<b>Foydalanuvchi botni blokladi $ax</b>",json_encode(['inline_keyboard'=>[[['text'=>"$delname",'url'=>"tg://user?id=$botdel_id"]]]]));
}
}
unlink("user/$botdel_id.users");
unlink("user/$botdel_id.step");
unlink("user/$botdel_id.ur");
unlink("user/$botdel_id.params");
unlink("user/$botdel_id.qu");
unlink("user/$botdel_id.si");
}
}

$taklif = file_get_contents("tizim/taklif.txt");
$baza = file_get_contents("step/$cid.txt");
$cid3 = file_get_contents("step/$cid.id");
$qoida = file_get_contents("tizim/qoida.txt");
$cashback = file_get_contents("tizim/cashback.txt");
$cVip = file_get_contents("tizim/cvip.txt");
$holat = file_get_contents("tizim/holat.txt");
$promo = file_get_contents("tizim/kanal2.txt");
$kanal = file_get_contents("tizim/kanal.txt");
$card_cc = file_get_contents("tizim/cc.txt");
$card_fc = file_get_contents("tizim/fc.txt");
$vazi = file_get_contents("tizim/vazifachilar.txt");
$vazbonus = file_get_contents("tizim/vazbonus.txt");
$bonusmiqdor = file_get_contents("tizim/bonusmiqdor.txt");
$taklif = file_get_contents("tizim/taklif.txt");
$spc = file_get_contents("tizim/kodspc.txt");
$promo = file_get_contents("tizim/kanal2.txt");
$guruh1 = file_get_contents("tizim/guruh1.txt");
$gr1_id = file_get_contents("tizim/gr1.txt");
$gpul = file_get_contents("tizim/gpul.txt");
$payme = file_get_contents("tizim/payme.txt");
$paymeapi = file_get_contents("tizim/paymeapi.txt");
$paymeparol = file_get_contents("tizim/paymeparol.txt");
$check = file_get_contents("tizim/check.txt");
$user = file_get_contents("tizim/user.txt");
$valyuta = file_get_contents("tizim/valyuta.txt");
$key = uniqid(uniqid());

$kategoriya = file_get_contents("bot/kategoriya.txt");
$royxat = file_get_contents("bot/$kategoriya/royxat.txt");
$type = file_get_contents("bot/$kategoriya/$royxat/turi.txt");
$narx = file_get_contents("bot/$kategoriya/$royxat/narx.txt");
$kunlik = file_get_contents("bot/$kategoriya/$royxat/kunlik.txt");
$tavsif = file_get_contents("bot/$kategoriya/$royxat/tavsif.txt");
$til = file_get_contents("bot/$kategoriya/$royxat/til.txt");
$versiya = file_get_contents("bot/$kategoriya/$royxat/versiya.txt");


if(isset($update)) {
$result = mysqli_query($connect,"SELECT * FROM users WHERE id = $cid$chat_id");
$rew = mysqli_fetch_assoc($result);
if($rew['status']=="deactive"){
exit();
}
}


if(isset($message)){
$result = mysqli_query($connect,"SELECT * FROM user_id WHERE user_id = $cid");
$rew = mysqli_fetch_assoc($result);
if($rew){
}else{
mysqli_query($connect,"INSERT INTO user_id(`user_id`,`reg`) VALUES ('$cid','$sana | $soat')");
}
}

if(isset($message)){
$result = mysqli_query($connect,"SELECT * FROM kabinet WHERE user_id = $cid");
$rew = mysqli_fetch_assoc($result);
if($rew){
}else{
mysqli_query($connect,"INSERT INTO kabinet(`user_id`,`pul`,`pul2`,`odam`,`ban`,`status`) VALUES ('$cid','0','0','0','unban','Oddiy')");
}
}

if(isset($message)){
$result = mysqli_query($connect,"SELECT * FROM card WHERE user_id = $cid");
$rew = mysqli_fetch_assoc($result);
if($rew){
}else{
mysqli_query($connect,"INSERT INTO card(`user_id`,`cc`,`fc`) VALUES ('$cid','0','0')");
}
}

if(isset($message)){
$result = mysqli_query($connect,"SELECT * FROM api WHERE user_id = $cid");
$rew = mysqli_fetch_assoc($result);
if($rew){
}else{
mysqli_query($connect,"INSERT INTO api(`user_id`,`api`) VALUES ('$cid','$key')");
}
}

if(isset($message)){
$result = mysqli_query($connect,"SELECT * FROM uid WHERE user_id = $cid");
$rew = mysqli_fetch_assoc($result);
if($rew){
}else{
mysqli_query($connect,"INSERT INTO uid(user_id) VALUES ('$cid')");
}
}


$resu = mysqli_query($connect,"SELECT * FROM `settings`");
$setting = mysqli_fetch_assoc($resu);

mysqli_query($connect," create table soxta(
id int(20) auto_increment primary key,
user_id varchar(100),
come varchar(100)
)");


mkdir("kunlik");
mkdir("user");
mkdir("set");
mkdir("step");
mkdir("@SARVAR_6364"); //baza o'chirilmasin


$pul=get("user/$chat_id.pul");
$kunli = get("set/kunlik.bonus");
$step = get("user/$cid.step");
$stepc = get("user/$chat_id.step");
$xolati=get("set/xolat.txt");

$ort=json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⏩ Orqaga"]],
]
]);

$aort=json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🗄️ Boshqaruv"]],
]
]);

$panel = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"⚙ Asosiy"],['text'=>"📊 Statistika"]],
[['text'=>"📢 Kanallar"],['text'=>"✉️ Xabar yuborish"]],
[['text'=>"🔎 Foydalanuvchini boshqarish"]],
[['text'=>"⏰ Cron sozlamasi"],['text'=>"📈 Bot tezligi"]],
[['text'=>"🤖 Bot holati"],['text'=>"🔎 Buyurtma"]],
[['text'=>"⏩ Orqaga"]],
]]);

$panel2 = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"📑 Birlamchi sozlamalar"]],
[['text'=>"💵 Kursni o‘rnatish"],['text'=>"⚖️ Foizni o‘rnatish"]],
[['text'=>"📞 Nomer tizimi"],['text'=>"🛍 Xizmatlar sozlash"]],
[['text'=>"🔑 API sozlash"]],
[['text'=>"🗄️ Boshqaruv"]],
]]);

if($text=="📞 Nomer tizimi" and $cid==$admin){
// if(in_array($cid,$admin)){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"<b>💡 Xozirgi holat \n 🔑 Api kalit : <code>$simkey</code> \n ♻️ Rubl kursi : $simrub \n 💰 Nomerlarga qoyiladigan foiz : $simfoiz \n Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
//[['text'=>"🔑 Kalitni yangilash",'callback_data'=>"simkeyapi"]],
[['text'=>"💰 API balans",'callback_data'=>"simkeyB"]],
]])
]);
}

if($data=="simkeyB"){
$urla = file_get_contents("https://api.sms-activate.org/stubs/handler_api.php?api_key=$simkey&action=getBalance");
if($urla=="BAD_KEY" or $urla=="NO_KEY"){
bot('sendMessage',[
'chat_id'=>$cid2,
'text'=>"⚠️ <b>Botga api ulanmagan yoki api kalit eskirgan !</b>",
'parse_mode'=>"html",
'reply_markup'=>$boshqarish,
]);
}else{
$h=explode(":",$urla)[1];
bot('sendMessage',[
'chat_id'=>$cid2,
'text'=>"API hisobi <pre>$h ₽</pre>",
'parse_mode'=>"html",
'reply_markup'=>$boshqarish,
]);
}
}

if($data == "simkeyapi"){
bot('deleteMessage',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
]);
bot('SendMessage',[
'chat_id'=>$cid2,
'text'=>"📝 <b> SMS-ACTIVATE.ORG dan olingan api kalitni kiriting:</b>",
'parse_mode'=>'html',
'reply_markup'=>$boshqarish,
]);
file_put_contents("step/$cid2.step",'simkeyapi');
}

if($step == "simkeyapi"){
if($tx=="🗄 Boshqarish"){ 
unlink("step/$cid.step"); 
}else{
if(in_array($cid,$admin)){
file_put_contents("admin/simkey.txt",$text);
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"<b>Muvaffaqiyatli o'zgartirildi!</b>",
'parse_mode'=>'html',
'reply_markup'=>$asosiy,
]);
unlink("step/$cid.step");
}}}






$panel2 = json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"📑 Birlamchi sozlamalar"]],
[['text'=>"💵 Kursni o‘rnatish"],['text'=>"⚖️ Foizni o‘rnatish"]],
[['text'=>"📞 Nomer tizimi"],['text'=>"🛍 Xizmatlar sozlash"]],
[['text'=>"🔑 API sozlash"]],
[['text'=>"🗄️ Boshqaruv"]],
]]);


if($text=="/menchi"){
$a = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM soxta WHERE user_id = $cid"))['id'];
sms($cid,"
$a
",$m);
}

if($time=="00:00"){
rmdirPro("kunlik");
rmdirPro("user/mt");
}

if($xolati=="❌"){
if($data){
if($cid2==$admin){
}else{
bot('answerCallbackQuery',[
'callback_query_id'=>$qid,
'text'=>"⛔️ Bot vaqtinchalik o'chirilgan!

Botda ta'mirlash ishlari olib borilayotgan bo'lishi mumkin!",
'show_alert'=>true,
]);
exit();
}
}elseif($text){
if($cid==$admin){
}else{
sms($cid,"<b>⛔️ Bot vaqtinchalik o'chirilgan!</b>

<i>Botda ta'mirlash ishlari olib borilayotgan bo'lishi mumkin!</i>",null);
exit();
}
}
}


if($text=="/menchi"){
$a = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM soxta WHERE user_id = $cid"))['id'];
sms($cid,"
$a
",$m);
}

if($time=="00:00"){
rmdirPro("kunlik");
rmdirPro("user/mt");
}

if($xolati=="❌"){
if($data){
if($cid2==$admin){
}else{
bot('answerCallbackQuery',[
'callback_query_id'=>$qid,
'text'=>"⛔️ Bot vaqtinchalik o'chirilgan!

<b>Botda ta'mirlash ishlari olib borilayotgan bo'lishi mumkin!</b>",
'show_alert'=>true,
]);
exit();
}
}elseif($text){
if($cid==$admin){
}else{
sms($cid,"<b>⛔️ Bot vaqtinchalik o'chirilgan!</b>

<b><i>Botda ta'mirlash ishlari olib borilayotgan bo'lishi mumkin!</i></b>",null);
exit();
}
}
}


$menu=json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🌐 Xizmatlar"],['text'=>"📞 Nomer olish"]],
[['text'=>"📲 Hisobni toldirish"],['text'=>"💳 Hisobim"]],
[['text'=>"🛒 Buyurtmalarim"],['text'=>"🔗 Pul ishlash"]],
[['text'=>"☎️ Murojaat"],['text'=>"🤝 Hamkorlik (API)"]],
[['text'=>"🌟 Premium Xizmati"],['text'=>"⭐️ Stars Xizmati"]],
[['text'=>"📘 Qo'llanma"],['text'=>"🤖 Bot yaratish"]],
]
]);

$menu_p=json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"🌐 Xizmatlar"],['text'=>"📞 Nomer olish"]],
[['text'=>"📲 Hisobni toldirish"],['text'=>"💳 Hisobim"]],
[['text'=>"🛒 Buyurtmalarim"],['text'=>"🔗 Pul ishlash"]],
[['text'=>"☎️ Murojaat"],['text'=>"🤝 Hamkorlik (API)"]],
[['text'=>"🌟 Premium Xizmati"],['text'=>"⭐️ Stars Xizmati"]],
[['text'=>"📘 Qo'llanma"],['text'=>"🤖Bot yaratish"]],
[['text'=>"🗄️ Boshqaruv"]],
]
]);

if($cid==$admin or $chat_id==$admin){
$m = $menu_p;}else{$m = $menu;
}

function delete($cid2,$mid2){
return bot('deleteMessage',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
]);
}

if($text=="🌟 Premium Xizmati"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"<b>Premium Obunalarda birini tanlang!</b>",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"⭐️ 1 oylik 45,000 so'm",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"⭐️ 3 oylik 150,000 so'm",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"⭐️ 6 oylik 200,000 so'm",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"⭐️ 12 oylik 360,000 so'm",url=>"https://t.me/Uzb_Tech_Admin"]], 
]])
]);
}



if($text=="⭐️ Stars Xizmati"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"<b>⭐️ Endilikda @MukammalSmm_Bot da telegram stars olishingiz mumkin 💵

O'zingizga maqul Stars miqdorini tanlang👇 </b>",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"⭐️50ta Stars",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"⭐️100ta Stars",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"⭐️150ta Stars",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"⭐️200ta Stars",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"⭐️300ta Stars",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"⭐️400ta Stars",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"⭐️500ta Stars",url=>"https://t.me/Uzb_Tech_Admin"]],
]])
]);
}


if($text=="🤖Bot yaratish"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"<b> 🤖Bot yaratib berish bo'limiga hush kelipsiz</b>",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🛍 MukammalSmm Bot",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"🧰 Konstruktor Bot",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"⤵️ Video Yuklovchi Bot",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"💰 Pul Bot",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"🎫 Auto Number Bot",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"🛍 Auto Nakrutka",url=>"https://t.me/Uzb_Tech_Admin"]],
[['text'=>"👥 Obunachi Bot",url=>"https://t.me/Uzb_Tech_Admin"]],
]])
]);
}
if($text=="📘 Qo'llanma"){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"<b> 1. 🤖 Botdan foydalanishda:
🛍Har bir xizmatga buyurtma berayotganingizda xizmat tagiga qanday qilib buyurtma berish yozilgan!

2. 💳To'lov qilmoqchi bo'lsangiz:
Agar siz to'lov qilmoqchi bo'lsangiz '📲Hisobni to'ldirish' tugmasini bosin va o'zingizga qulay bo'lgan tolov usulini tanlab foydalanishingiz mumkun.
🧑‍💻Admin yordamida to'lov qilsangiz 🎁Bonus qo'shib olishingiz mumkun✅.
Agar admin yordamida tolov qilmoqchi bo'lsangiz @Uzb_Tech_Admin 🧑‍💻 ga murojat qiling‼️

3. 🌟Agar Ishonchli Premium xizmatidan foydalanmoqchi bo'lsangiz botdagi « 🌟Ishonchli Premium Xizmati » bo'limiga kiring va o'zingizga ma'qul premium turini tanlab chiqib kelgan admin🧑‍💻 lichkasiga yozasiz.✅

4. Agar Ishonchli ⭐️ Stars xizmatidan foydalanmoqchi bo'lsangiz botdagi « 🌟Ishonchli Stars Xizmati » bo'limiga kiring va o'zingizga yetarli Stars miqdorini tanlab chiqib kelgan admin🧑‍💻 lichkasiga yozasiz.✅

5. Agar Ishonchli 🤖Bot yaratish xizmatidan foydalanmoqchi bo'lsangiz botdagi «🤖 Bot Yaratish Xizmati » bo'limiga kiring va o'zingizga Kerakli bot turini tanlang va chiqib kelgan admin🧑‍💻 lichkasiga yozasiz.✅️ </b>",
'parse_mode'=>"html",
]);
}

if($text=="🗄️ Boshqaruv" and $cid==$admin){
sms($cid,"👨‍💻 <b>$name panelga xush kelibsiz.</b>",$panel);
unlink("user/$cid.step");
exit;
}

if($text=="⚙ Asosiy" and $cid==$admin){
sms($cid,"<b>👉 Asosiy sozlamalar:</b>",$panel2);
exit();
}

if($text=="⏩ Orqaga" and joinchat($cid)==1){
sms($cid,"🖥️ <b>Asosiy menyudasiz</b>",$m);
unlink("user/$cid.step");
unlink("user/$cid.ur");
unlink("user/$cid.params");
unlink("user/$cid.qu");
unlink("user/$cid.si");
exit();
}

if($text=="🤖 Bot holati" and $cid==$admin){
if($xolati=="✅"){$button="❌ O'chirish";
}elseif($xolati=="❌"){$button="✅ Yoqish";}
sms($cid,"<b>🔎 Joriy xolat:</b> $xolati",json_encode(['inline_keyboard'=>[
[['text'=>"$button",'callback_data'=>"xoli"]],
]]));
}

if($data=="botholati"){
if($xolati=="✅"){$button="❌ O'chirish";
}elseif($xolati=="❌"){$button="✅ Yoqish";}
edit($cid2,$mid2,"<b>🔎 Joriy xolat:</b> $xolati",json_encode(['inline_keyboard'=>[
[['text'=>"$button",'callback_data'=>"xoli"]],
]]));
}

if($data=="xoli"){
if($xolati=="❌"){$put="✅";
}elseif($xolati=="✅"){$put="❌";}
del();
sms($cid2,"<b>🤖 Bot ".str_replace(["❌","✅"],["o'chirildi!","yoqildi!"],$put)."</b>",json_encode(['inline_keyboard'=>[
[['text'=>"⏩ Orqaga",'callback_data'=>"botholati"]],
]]));
put("set/xolat.txt",$put);
}

if($text=="📊 Statistika" and $cid==$admin){
$stat=0;
$res = mysqli_query($connect, "SELECT * FROM users");
$stat = mysqli_num_rows($res);
$resi = mysqli_query($connect, "SELECT * FROM orders");
$stati = mysqli_num_rows($resi);
$resw = mysqli_query($connect, "SELECT * FROM soxta");
$statw = mysqli_num_rows($resw);
$ac =0;
$dc =0;
$pc =0;
$cc =0;
$bc =0;
$fc =0;
$jc =0;
$ppc=0;
$cp=0;
$stati ? $stati = $stati : $stati = "0";
while($hi=mysqli_fetch_assoc($resi)){
if($hi['status']=="Pending") {
$pc++;
}elseif($hi['status']=="Completed"){
$cc++;
}elseif($hi['status']=="Canceled") {
$bc++;
}elseif($hi['status']=="Failed"){
$fc++;
}elseif($hi['status']=="In progress"){
$jc++;
}elseif($hi['status']=="Partial"){
$ppc++;
}elseif($hi['status']=="Processing"){
$cp++;
}
}

while($h=mysqli_fetch_assoc($res)){
if($h['status']=="active") {
$ac++;
}elseif($h['status']=="deactive"){
$dc++;
}
}
$seco=0;
$resit= mysqli_query($connect, "SELECT * FROM services");
$seco = mysqli_num_rows($resit);
$resit0= mysqli_query($connect, "SELECT * FROM soxta");
$seco0 = mysqli_num_rows($resit0);
$stet = $stat + $statw;
$qurbaqa = mysqli_query($connect, "SELECT * FROM soxta WHERE come = 'come'");
$tw = mysqli_num_rows($qurbaqa);
$tarketgan = $seco0 - $tw;
$toshbaqa = mysqli_query($connect, "SELECT * FROM soxta WHERE come = 'gone'");
$gone = mysqli_num_rows($toshbaqa);
$azola = $ac - $gone;
$jam = $azola + $tarketgan;
$ohz = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users ORDER BY user_id DESC LIMIT 1"))['user_id'];
$start_time = round(microtime(true) * 1000);
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"",
'parse_mode'=>'html',
]);
$end_time = round(microtime(true) * 1000);
$ping = $end_time - $start_time;
if($ping>1 and $ping<30){$x="juda Sekin";
}elseif($ping>=30 and $ping<80){$x="Sekin";
}elseif($ping>=90 and $ping<170){$x="o'rta";
}elseif($ping>=170 and $ping<200){$x="Tezkor";
}elseif($ping>=200){$x="O'rtacha";}
sms($cid,"
<b>📊 Bot statistikasi:</b>

💡 <b>Bot tezligi:</b> <code>$ping</code> m/s ($x)
👥 <b>Barcha foydalanuvchilar:</b> $jam ta
✅ <b>Aktiv foydalanuvchilar:</b> $azola ta
❌ <b>Botni tark etganlar:</b> $tarketgan ta
⛔ <b>Bloklangan foydalanuvchilar:</b> $dc ta
📋 <b>Barcha xizmatlar:</b> $seco ta
🛍️ <b>Barcha buyurtmalar:</b> $stati ta",keyboard([
[['text'=>"🛍️ Buyurtmalar",'callback_data'=>"update=orders"]],
[['text'=>"🏆 TOP 100 Talik referalar",'callback_data'=>"konkurs"]],
[['text'=>"🏆 TOP 100 Talik balanslar",'callback_data'=>"preyting"]],
]));
unlink("user/$cid.step");

}

if((stripos($data,"update=")!==false)){
$resi = mysqli_query($connect, "SELECT * FROM orders");
$stati = mysqli_num_rows($resi);
$ac =0;
$dc =0;
$pc =0;
$cc =0;
$bc =0;
$fc =0;
$jc =0;
$cp =0;
$ppc=0;

$stati ? $stati = $stati : $stati = "0";
while($hi=mysqli_fetch_assoc($resi)){
if($hi['status']=="Pending") {
$pc++;
}elseif($hi['status']=="Completed"){
$cc++;
}elseif($hi['status']=="Canceled") {
$bc++;
}elseif($hi['status']=="Failed"){
$fc++;
}elseif($hi['status']=="In progress"){
$jc++;
}elseif($hi['status']=="Processing"){
$cp++;
}elseif($hi['status']=="Partial"){
$ppc++;
}
}
	
$res = explode("=", $data)[1];
if($res=="orders") {

del();
sms($cid2,"
📊 Buyurtmalar ro'yxati:

• Jami buyurtmalar: $stati ta
• Bajarilgan buyurtmalar: $cc ta
• Kutilayotgan buyurtmalar: $pc ta
• Jarayondagi buyurtmalar: $jc ta
• Bekor qilingan buyurtmalar: $bc ta
• Muvaffaqiyatsiz buyurtmalar: $fc ta
• Qisman bajarilgan buyurtmalar: $ppc ta
• Qayta ishlangan buyurtmalar: $cp ta
",keyboard([
[['text'=>"Kutilayotgan buyurtmalarni yangilash",'callback_data'=>"update=pending"]],
[['text'=>"Jarayondagi buyurtmalarni yangilash",'callback_data'=>"update=In progress"]],
[['text'=>"Qisman bajarilgan buyurtmalarni yangilash",'callback_data'=>"update=partial"]],
[['text'=>"Qayta ishlangan buyurtmalarni yangilash",'callback_data'=>"update=processing"]],
]));
}elseif($res=="pending"){
del();
sms($cid2,"
📊 Buyurtmalar ro'yxati:

• Kutilayotgan buyurtmalar: $pc ta",keyboard([
[['text'=>"Bajarilgan xolatga o‘tkazish",'callback_data'=>"update=new=Pending=Completed"]],
[['text'=>"Jarayondagi xolatga o‘tkazish",'callback_data'=>"update=new=Pending=In progress"]],
[['text'=>"Orqaga",'callback_data'=>"update=orders"]],
]));
}elseif($res=="processing"){
del();
sms($cid2,"
📊 Buyurtmalar ro'yxati:

• qayta ishlangan buyurtmalar: $cp ta",keyboard([
[['text'=>"Bajarilgan xolatga o‘tkazish",'callback_data'=>"update=new=Processing=Completed"]],
[['text'=>"Jarayondagi xolatga o‘tkazish",'callback_data'=>"update=new=Processing=In progress"]],
[['text'=>"Orqaga",'callback_data'=>"update=orders"]],
]));
}elseif($res=="partial"){
del();
sms($cid2,"
📊 Buyurtmalar ro'yxati:

• • Qisman bajarilgan buyurtmalar: $ppc ta",keyboard([
[['text'=>"Bajarilgan xolatga o‘tkazish",'callback_data'=>"update=new=Partial=Completed"]],
[['text'=>"Jarayondagi xolatga o‘tkazish",'callback_data'=>"update=new=Partial=In progress"]],
[['text'=>"Orqaga",'callback_data'=>"update=orders"]],
]));
}elseif($res=="In progress"){
del();
sms($cid2,"
📊 Buyurtmalar ro'yxati:

• Jarayondagi buyurtmalar: $jc ta",keyboard([
[['text'=>"Bajarilgan xolatga o‘tkazish",'callback_data'=>"update=new=In progress=Completed"]],
[['text'=>"Kutilayotgan xolatga o‘tkazish",'callback_data'=>"update=new=In progress=Pending"]],
[['text'=>"Orqaga",'callback_data'=>"update=orders"]],
]));
}elseif($res=="new"){
$out = explode("=",$data)[2];
$inp = explode("=",$data)[3];
$mysqli = mysqli_query($connect, "SELECT * FROM orders WHERE status = '$out'");
while($all = mysqli_fetch_assoc($mysqli)){
$io = $all['order_id'];

$mysa=mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `myorder` WHERE order_id=$io"));
$adm=$mysa['user_id'];

mysqli_query($connect,"UPDATE orders SET status ='$inp' WHERE order_id = $io");
if($inp=="Completed") {
$sav = date("Y.m.d H:i:s");
mysqli_query($connect,"UPDATE myorder SET status='$input', last_check='$sav' WHERE order_id=$io");
}else{
mysqli_query($connect,"UPDATE myorder SET status='$inp' WHERE order_id=$io");
}
if($inp=="Completed"){
sms($adm,"✅ <b>Sizning $io raqamli buyurtmangiz bajarildi</b>",json_encode([
'inline_keyboard'=>[
[['text'=>"🔎 | Ko‘rish",'callback_data'=>"checkorders=$io"]]]]));
}
}
del();
sms($cid2,"✅ Jarayon tugallandi.",null);
}
}



if($data =="preyting"){
$res = mysqli_query($connect,"SELECT * FROM `users`ORDER BY balance DESC LIMIT 100");
while($roww = mysqli_fetch_assoc($res)){
$id = $roww['id'];
$pul = $roww['balance'];
$member = $roww['refnum'];
$stat = mysqli_num_rows($res);
$top .= "<a href='tg://user?id=$id'>$id</a> - <i>$pul</i> so'm\n";
}
$ids = explode("\n","\n$top");
$soi = substr_count($top,"\n");
$soni = $soi;
foreach($ids as  $id){
$keyboards = [];
$text = "";
for ($i = 1; $i <= $soni; $i++) {
$title = str_replace("\n","",$ids[$i]);
$text .= "<b>$i)</b> ".$ids[$i]." \n";
}
bot('deleteMessage',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
]);
bot('sendMessage',[
'chat_id'=>$cid2,
'text'=>"<b>TOP-100 balanslar reytingi

$text</b>",
'parse_mode'=>'html',
]);
exit();
}
}



if($text == "✉️ Xabar yuborish" and $cid == $admin){
$result = mysqli_query($connect, "SELECT * FROM `send`");
$row = mysqli_fetch_assoc($result);
if(!$row){
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"<b>📤 Foydalanuvchilarga yuboriladigan xabarni botga yuboring!</b>",
'parse_mode'=>'html',
'reply_markup'=>$aort
]);
put("user/$cid.step","send");
}else{
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"<b>📑 Hozirda botda xabar yuborish jarayoni davom etmoqda. Yangi xabar yuborish uchun eski yuborilayotgan xabar barcha foydalanuvchilarga yuborilishini kuting!</b>",
'parse_mode'=>'html',
'reply_markup'=>$panel
]);
}
}

if($step== "send" and $cid==$admin){
$result = mysqli_query($connect, "SELECT * FROM users");
$stat = mysqli_num_rows($result);
$res = mysqli_query($connect,"SELECT * FROM users ORDER BY user_id DESC LIMIT $stat");
$row = mysqli_fetch_assoc($res);
$user_id = $row['id'];
$time1 = date('H:i', strtotime('+1 minutes'));
$time2 = date('H:i', strtotime('+2 minutes'));
$tugma = json_encode($update->message->reply_markup);
$reply_markup = base64_encode($tugma);
mysqli_query($connect, "INSERT INTO `send` (`time1`,`time2`,`start_id`,`stop_id`,`admin_id`,`message_id`,`reply_markup`,`step`) VALUES ('$time1','$time2','0','$user_id','$admin','$mid','$reply_markup','send')");
bot('sendMessage',[
'chat_id'=>$admin,
'text'=>"<b>📋 Saqlandi!
📑 Xabar foydalanuvchilarga $time1 da yuborish boshlanadi!</b>",
'parse_mode'=>'html',
'reply_markup'=>$panel
]);
unlink("user/$cid.step");
}

$result = mysqli_query($connect, "SELECT * FROM `send`"); 
$row = mysqli_fetch_assoc($result);
$sendstep = $row['step'];
if($_GET['update']=="send"){
$row1 = $row['time1'];
$row2 = $row['time2'];
$row3 = $row['time3'];
$row4 = $row['time4'];
$row5 = $row['time5'];
$start_id = $row['start_id'];
$stop_id = $row['stop_id'];
$admin_id = $row['admin_id'];
$mied = $row['message_id'];
$tugma = $row['reply_markup'];
if($tugma == "bnVsbA=="){
$reply_markup = "";
}else{
$reply_markup = base64_decode($tugma);
}
$time1 = date('H:i', strtotime('+1 minutes'));
$time2 = date('H:i', strtotime('+2 minutes'));
$time3 = date('H:i', strtotime('+3 minutes'));
$time4 = date('H:i', strtotime('+4 minutes'));
$time5 = date('H:i', strtotime('+5 minutes'));
$limit = 100;

if($time == $row1 or $time == $row2 or $time == $row3 or $time == $row4 or $time == $row5){
$sql = "SELECT * FROM `users` LIMIT $start_id,$limit";
$res = mysqli_query($connect,$sql);
while($a = mysqli_fetch_assoc($res)){
$id = $a['id'];
if($id == $stop_id){
bot('ForwardMessage',[
'chat_id'=>$id,
'from_chat_id'=>$admin_id,
'message_id'=>$mied,
]);
bot('sendMessage',[
'chat_id'=>$admin_id,
'text'=>"<b>✅ ️Xabar barcha bot foydalanuvchilariga yuborildi!</b>",
'parse_mode'=>'html'
]);
mysqli_query($connect, "DELETE FROM `send`");
exit;
}else{
bot('ForwardMessage',[
'chat_id'=>$id,
'from_chat_id'=>$admin_id,
'message_id'=>$mied,
]);
}
}
mysqli_query($connect, "UPDATE `send` SET `time1` = '$time1'");
mysqli_query($connect, "UPDATE `send` SET `time2` = '$time2'");
mysqli_query($connect, "UPDATE `send` SET `time3` = '$time3'");
mysqli_query($connect, "UPDATE `send` SET `time4` = '$time4'");
mysqli_query($connect, "UPDATE `send` SET `time5` = '$time5'");
$get_id = $start_id + $limit;
mysqli_query($connect, "UPDATE `send` SET `start_id` = '$get_id'");
bot('sendMessage',[
'chat_id'=>$admin_id,
'text'=>"<b>✅ Yuborildi: $get_id</b>",
'parse_mode'=>'html'
]);
}
echo json_encode(["status"=>true,"cron"=>"Sending message"]);
}


if($text=="📑 Birlamchi sozlamalar" and $cid==$admin){
sms($cid,"⭐ <b>Kerakli bo'limni tanlang:</b>",json_encode([
inline_keyboard=>[
[['text'=>"📑 Matnlar",callback_data=>"birlamch=matn"],['text'=>"💳 Hamyonlar",callback_data=>"birlamch=cards"]],
]]));
}

if((stripos($data,"birlamch=")!==false)){
$res=explode("=",$data)[1];
if($res=="matn"){
edit($chat_id,$message_id,"👉 <b>Sozlama turini tanlang</b>:",json_encode([
inline_keyboard=>[
[['text'=>"📑 Nomini o‘zgartirish",callback_data=>"birlamch=editM"]],
[['text'=>"Orqaga",callback_data=>"birlamch=exit"]],
]]));
}elseif($res=="tugma"){
edit($chat_id,$message_id,"👉 <b>Sozlama turini tanlang:</b>",json_encode([
inline_keyboard=>[
[['text'=>"📑 Nomini o‘zgartirish",callback_data=>"birlamch=editT"]],
[['text'=>"Orqaga",callback_data=>"birlamch=exit"]],
]]));
}elseif($res=="exit"){
del();
sms($chat_id,"⭐ Kerakli bo'limni tanlang:",json_encode([
inline_keyboard=>[
[['text'=>"📑 Matnlarni sozlash",callback_data=>"birlamch=matn"]],
[['text'=>"💳 Hamyonlar sozlamalari",callback_data=>"birlamch=cards"]],
]]));
}elseif($res=="editM"){
edit($chat_id,$message_id,"
📑 <b>Kerakli matnni tanlang:</b>

1. Start uchun matn
2. Yangi buyurtma uchun matn
3. Kabinet uchun matn
4. Referal narxi
5. Kunlik bonus miqdori",json_encode([
inline_keyboard=>[
[['text'=>"1",callback_data=>"birlamchi=start"],['text'=>"2",callback_data=>"birlamchi=orders"],['text'=>"3",callback_data=>"birlamchi=kabinet"],['text'=>"4",callback_data=>"birlamchi=referal"],['text'=>"5",callback_data=>"birlamchi_kunlik"]],
[['text'=>"Orqaga",callback_data=>"birlamch=matn"]],
]]));
}elseif($res=="ref"){
edit($chat_id,$mid2,"⚙️ Sozlama turini tanlang:",json_encode([
inline_keyboard=>[
[['text'=>"🎁 Referal tugma xolati",'callback_data'=>"referr=xolati"]],
[['text'=>"🎁 Bonusni o‘zgartirish",'callback_data'=>"referr=edit"]],
[['text'=>"Orqaga",callback_data=>"birlamch=exit"]],
]]));
}elseif($res == "cards"){
del();
$delturi = file_get_contents("set/payments.txt");
$delmore = explode("\n",$delturi);
$delsoni = substr_count($delturi,"\n");
$key=[];
for ($delfor = 1; $delfor <= $delsoni; $delfor++) {
$title=str_replace("\n","",$delmore[$delfor]);
$key[]=["text"=>"$title - ni o'chirish","callback_data"=>"delPayMethod-$title"];
$keyboard2 = array_chunk($key, 1);
$keyboard2[] = [['text'=>"➕ Yangi to'lov tizimi qo'shish",'callback_data'=>"new"]];
$keyboard2[] = [['text'=>"Orqaga",callback_data=>"birlamch=exit"]];
$pay = json_encode([
'inline_keyboard'=>$keyboard2,
]);
}
if($cid2==$admin){
if($delturi == null){
bot('SendMessage',[
	'chat_id'=>$cid2,
	'text'=>"<b>Quyidagilardan birini tanlang:</b>",
	'parse_mode'=>'html',
		'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"➕ Yangi to'lov tizimi qo'shish",'callback_data'=>"new"]],
[['text'=>"Orqaga",callback_data=>"birlamch=exit"]],
]
])
]);

}else{
	bot('SendMessage',[
	'chat_id'=>$cid2,
	'text'=>"<b>Quyidagilardan birini tanlang:</b>",
	'parse_mode'=>'html',
		'reply_markup'=>$pay
]);

}
}
}elseif($res=="autopays"){
edit($cid2,$mid2,"👉 <b>Kerakli tolov tizimini tanlang:</b>",keyboard([
[['text'=>"💳 PAYME",'callback_data'=>"autopay=payme"]],
[['text'=>"Orqaga",callback_data=>"birlamch=exit"]],
]));
}
}

if(mb_stripos($data,"autopay=")!==false){
$ex = explode("=",$data)[1];
if($ex=="payme"){
if(empty($setting['payme_id']) or $setting['payme_id']=="null"){
edit($cid2,$mid2,"👉 Kerakli sozlamani tanlang:",keyboard([
[['text'=>"➕ Karta IDsini qo‘shish",'callback_data'=>"autopay=payme_id"]],
[['text'=>"Orqaga",callback_data=>"birlamch=exit"]],
]));
}else{
edit($cid2,$mid2,"👉 Kerakli sozlamani tanlang

🆔 Hozirgi karta IDsi: ".$setting['payme_id']."",keyboard([
[['text'=>"➕ Karta IDsini o‘zgartirish",'callback_data'=>"autopay=payme_id"]],
[['text'=>"Orqaga",callback_data=>"birlamch=exit"]],
]));
}
}elseif($ex=="payme_id") {
del();
bot("sendMediaGroup",[ 
"chat_id"=>$cid2, 
"media"=>json_encode([ 
["type"=>"photo","media" => "https://t.me/s1_kanal/61"], 
["type"=>"photo","media" => "https://t.me/s1_kanal/62"], 
["type"=>"photo","media" => "https://t.me/s1_kanal/63","caption"=>"
1 - «<b>Kartalarim</b>» tugmasini bosing
2 - «<b>Kerakli karta</b>» ni tanlab ustiga bosing
3 - «<b>Havolani ko‘chirib olish</b>» ga bosib linkni saqlab oling va shuyerga kiriting.",'parse_mode'=>html],
]),
]);
sms($cid2,"📑 Kartangizning unikal manzilini kiriting

✅ Malumotlaringiz 100% maxfiy saqlanadi.",$aort);
put("user/$cid2.step","%%₹_-#");
}
}
if($step=="%%₹_-#" and $cid==$admin){
if((mb_stripos($text,"https://")!==false) and (mb_stripos($text,"https://payme.")!==false) and (mb_stripos($text,"payme.uz")!==false)){
$card = explode("/",$text)[3];
sms($cid,"✅ O‘zgartirish muvaffaqiyatli amalga oshirildi.",$panel);
mysqli_query($connect,"UPDATE settings SET `payme_id` = '$card' WHERE id = 1");
unlink("user/$cid.step");
}}






if(mb_stripos($data,"delPayMethod-")!==false){
	$ex = explode("-",$data)[1];
	$delturi = file_get_contents("set/payments.txt");
	$delturi = str_replace("\n".$ex."","",$delturi);
   file_put_contents("set/payments.txt",$delturi);
bot('deleteMessage',[
	'chat_id'=>$cid2,
	'message_id'=>$mid2,
	]);
bot('SendMessage',[
	'chat_id'=>$cid2,
	'text'=>"🗑️ <b>To'lov tizimi o'chirildi!</b>",
		'parse_mode'=>'html',
	'reply_markup'=>$asosiy
]);
rmdirPro("set/pay/$ex");
}

if($data == "new"){
	bot('deleteMessage',[
	'chat_id'=>$cid2,
	'message_id'=>$mid2,
   ]);
   bot('sendMessage',[
   'chat_id'=>$cid2,
   'text'=>"🔠 <b>Yangi to'lov tizimi nomini yuboring:</b>",
   'parse_mode'=>'html',
   'reply_markup'=>$aort
	]);
	file_put_contents("user/$cid2.step",'turi');
	
}

if($step == "turi"){
if($cid==$admin){
if(isset($text)){
put("set/title.txt",$text);
	bot('SendMessage',[
	'chat_id'=>$cid,
	'text'=>"🔢 <b>Ushbu to'lov tizimidagi hamyoningiz raqamini yuboring:</b>",
	'parse_mode'=>'html',
	]);
	file_put_contents("user/$cid.step",'wallet');
}
}
}


if($step == "wallet"){
if($cid==$admin){
put("set/wallet.txt",$text);
	bot('SendMessage',[
	'chat_id'=>$cid,
	'text'=>"✅ <b>Ushbu to'lov tizimi orqali hisobni to'ldirish bo'yicha ma'lumotni yuboring:</b>

<i>Misol uchun, \"Ushbu to'lov tizimi orqali pul yuborish jarayonida izoh kirita olmasligingiz mumkin. Ushbu holatda, biz bilan bog'laning.</i>\"",
'parse_mode'=>'html',
	]);
	file_put_contents("user/$cid.step",'addition');
}else{
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"🔢 <b>Faqat raqamlardan foydalaning!</b>",
'parse_mode'=>'html',
]);
}
}

if($step == "addition"){
		if($cid==$admin){
	if(isset($text)){
$ttest=get("set/title.txt");
file_put_contents("set/payments.txt","\n".$ttest,FILE_APPEND);
mkdir("set/pay");
mkdir("set/pay/$ttest");
file_put_contents("set/pay/$ttest/addition.txt","$text");
file_put_contents("set/pay/$ttest/wallet.txt",get("set/wallet.txt"));
	bot('SendMessage',[
	'chat_id'=>$cid,
	'text'=>"✅ <b>$ttest to'lov tizimi qo'shildi!</b>",
	'parse_mode'=>'html',
	'reply_markup'=>$panel,
	]);
	unlink("user/$cid.step");
}
}
}


if((stripos($data,"referr=")!==false)){
$res = explode("=",$data)[1];
$fo = explode("=",$data)[2];
if($res=="xolati"){
$m = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM settings WHERE id = 1"))["ref_status"];
if($m == "on"){
$tx = "✅";
$kb = json_encode([
inline_keyboard=>[
[['text'=>"«❌»",'callback_data'=>"referr=ok=off"]],
[['text'=>"Orqaga",callback_data=>"birlamch=exit"]],
]]);
}elseif($m == "off"){
$tx = "❌";
$kb = json_encode([
inline_keyboard=>[
[['text'=>"«✅»",'callback_data'=>"referr=ok=on"]],
[['text'=>"Orqaga",callback_data=>"birlamch=exit"]],
]]);
}
edit($cid2,$mid2,"🎁 Referal tugma xolati: $tx",$kb);
}elseif($res=="ok") {
mysqli_query($connect,"UPDATE settings SET ref_status = '$fo' WHERE id = 1");
$m = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM settings WHERE id = 1"))["ref_status"];
if($m == "on"){
$tx = "✅";
$kb = json_encode([
inline_keyboard=>[
[['text'=>"«❌»",'callback_data'=>"referr=ok=off"]],
[['text'=>"Orqaga",callback_data=>"birlamch=exit"]],
]]);
}elseif($m == "off"){
$tx = "❌";
$kb = json_encode([
inline_keyboard=>[
[['text'=>"«✅»",'callback_data'=>"referr=ok=on"]],
[['text'=>"Orqaga",callback_data=>"birlamch=exit"]],
]]);
}
edit($cid2,$mid2,"🎁 Referal tugma xolati: $tx",$kb);
}elseif($res=="edit") {
$m = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM settings WHERE id = 1"))["bonus"];
del();
sms($cid2,"
🔢 Referal bonus miqdorini kiriting. (raqamlarda)

📝 Hozirgi xolati: <pre>$m%</pre>",$aort);
put("user/$cid2.step","*##");
}
}
if($step=="*##" and $cid==$admin){
if(is_numeric($text)==1){
mysqli_query($connect,"UPDATE settings SET bonus = '$text' WHERE id = 1");
sms($cid,"✅ O‘zgarish saqlandi",$panel);
unlink("user/$cid.step");
}
}


if((stripos($data,"birlamchi=")!==false)){
$res = explode("=",$data)[1];
if($res=="start"){
$arr = "<code>{balance} </code> - Foydalanuvchi hisobi\n<pre>{name}</pre> - Foydalanuvchi ismi\n<pre>{time} </pre> - Hozirgi vaqt (UTC+5 / UZ)";
}elseif($res=="kabinet") {
$arr ="<pre>{id}</pre> - Foydalanuvchi IDsi\n<pre>{balance}</pre> - Foydalanuvchi hisobi\n<pre>{outing}</pre> - Kiritgan pullar miqdori\n<pre>{orders}</pre> - Buyurtmalari soni";
}elseif($res=="referal") {
$arr = "1 ta taklif uchun tolov miqdorini kiriting:";
}elseif($res=="orders") {
$arr ="<pre>{order}</pre> - Buyurtma IDsi (standard)\n<pre>{order_api}</pre> - Buyurtma IDsi (API)";
}
put("bir.txt",$res);
del();
sms($chat_id,"
📝 <b>Yangi matnni kiriting.

⚙️ O‘zgaruvchilar:</b>
$arr

📝 <b>Hozirgi matnlar</b>:",$aort);
$m  = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM settings WHERE id = 1"))[$res];
sms($chat_id,enc("decode",$m),null);
put("user/$chat_id.step","!?+-");
}
if($step=="!?+-" and $cid==$admin){

$vq = get("bir.txt");
$vo = enc("encode",$text);
mysqli_query($connect,"UPDATE settings SET `$vq` = '$vo' WHERE id = 1");
sms($cid,"✅ O‘zgartirishlar saqlandi",$panel);
unlink("bir.txt");
unlink("user/$cid.step");
exit;
}

if($data=="birlamchi_kunlik"){
sms($chat_id,"📝 <b>Yangi qiymatni kiriting:

🎁 Hozirgi bonus miqdori: $kunli so'm</b>:",$aort);
put("user/$chat_id.step","kunlibonus");
exit();
}

if($step=="kunlibonus"){
if(is_numeric($text)==true){
sms($cid,"✅ <b>$text saqlandi!</b>",$panel);
put("set/kunlik.bonus",$text);
unlink("user/$cid.step");
}else{
sms($cid,"<b>Faqat raqamlardan foydalaning:</b>",$aort);
}
}

if($text=="🔎 Buyurtma" and $cid == $admin) {
$resi = mysqli_query($connect, "SELECT * FROM orders");
$stati = mysqli_num_rows($resi);
sms($cid,"
📦 <b>Barcha buyurtmalar:</b> $stati ta

✍️ <b>Buyurtma IDsini kiriting:</b>",$aort);
put("user/$cid.step",orders2);
exit;
}


if($step=="orders2" and $cid==$admin and is_numeric($text)==1){
$resi = mysqli_query($connect, "SELECT * FROM orders WHERE order_id = '$text'");
$stati = mysqli_fetch_assoc($resi);
if(!$stati){
sms($cid,"❌ <b>Buyurtma topilmadi.</b>",$aort);
}else{
$prv = $stati['provider'];
$a = mysqli_query($connect,"SELECT * FROM providers WHERE id = $prv");
$c = mysqli_fetch_assoc($a);
$prg = $stati['provider'];
$m = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `providers` WHERE id = '$prg'"));
$surl = $m['api_url'];
$skey =$m['api_key'];
$api = json_decode(get($surl."?key=$skey&action=status&order=".$stati['api_order'].""), 1);
$prtxt=str_replace(["/api/adapter/default/index","/api/v1","/api/v2","https://"],["","","",""],$c['api_url']);
sms($cid,"
🌐 <b>Server:</b> $prtxt

🆔 <b>Buyurtma IDsi: <code>".$stati['api_order']."</code>

✅ Buyurtma xolati ($prtxt):</b> <code>".$api['status']."</code>",$panel);
unlink("user/$cid.step");
}
exit;
}

if($text=="📈 Bot tezligi"){
$start_time = round(microtime(true) * 1000);
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"",
'parse_mode'=>'html',
]);
$end_time = round(microtime(true) * 1000);
$ping = $end_time - $start_time;
$d = sms($cid,"<b>⏰ Kuting...</b>",null)->result->message_id;
sleep(0.5);
$s = edit($cid,$d,"<b>🤖 Bot</b>",null)->result->message_id;
sleep(0.5);
$e = edit($cid,$s,"<b>🤖 Bot tezligi</b>",null)->result->message_id;
sleep(0.5);
$se = edit($cid,$e,"<b>🤖 Bot tezligi:</b> $ping",null)->result->message_id;
sleep(0.5);
edit($cid,$se,"<b>🤖 Bot tezligi:</b> $ping m/s",null);
}

if($text == "🔑 API sozlash"){
	if($cid == $admin){
	bot('SendMessage',[
	'chat_id'=>$cid,
'text'=>"📑 <b>Quyidagi bo'limlardan birini tanlang:</b>",
	'parse_mode'=>'html',
	'reply_markup'=>json_encode([
	'inline_keyboard'=>[
	[['text'=>"➕ API qo‘shish",'callback_data'=>"api"]],
	[['text'=>"💵 Balans",'callback_data'=>"balans"],['text'=>"🗑️ O‘chirish",'callback_data'=>"deleteapi"]],
	[['text'=>"📝 Tahrirlash",'callback_data'=>"apio=taxrirlash"]],
]
	])
	]);
	exit;
}
}

if((stripos($data,"apio=")!==false)){
$res=explode("=",$data)[1];
if($res=="taxrirlash") {
edit($cid2,$mid2,"📝 <b>Tahrirlash menyusini tanlang:</b>",keyboard([
[['text'=>"🔑 Kalitni o‘zgartirish",'callback_data'=>"apio=kalit"]],
[['text'=>"⬅️ Orqaga", callback_data=>"api1"]],
]));
}elseif($res=="kalit") {
$pr=0;
$prs="";
$a = mysqli_query($connect,"SELECT * FROM providers");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$pr++;
$prtxt=str_replace(["/api/adapter/default/index","/api/v1","/api/v2","https://"],["","","",""],$s['api_url']);
$prs.="$pr: <b>$prtxt\n</b>";
$k[]=["text"=>$pr,"callback_data"=>"apio=edit=".$s['id']];
}
$keyboard2=array_chunk($k,3);
$keyboard2[]=[['text'=>"Orqaga",'callback_data'=>"api1"]];
$kb=json_encode([inline_keyboard=>$keyboard2]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Provayderlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
     bot('editMessageText',[
        'chat_id'=>$chat_id,
       'message_id'=>$message_id,
       'text'=>"<b>Provayderni tanlang:</b>

$prs
",
'parse_mode'=>"HTML",
'reply_markup'=>$kb,
]);

}
}elseif($res=="edit") {
del();
$co=explode("=",$data)[2];
sms($cid2,"🎯<b> Yangi kalitni kiriting:</b>",$aort);
put("user/$cid2.step","kalitnew=$co");
}
}


if((mb_stripos($step,"kalitnew=")!==false) and $cid==$admin){
sms($cid,"✅ O‘zgartirish muvaffaqiyatli amalga oshirildi.",$panel);
$io = explode("=",$step)[1];
mysqli_query($connect,"UPDATE providers SET api_key = '$text' WHERE id = $io");
unlink("user/$cid.step");
}


if($data == "deleteapi"){
$pr=0;
$prs="";
$a = mysqli_query($connect,"SELECT * FROM providers");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$pr++;
$prtxt=str_replace(["/api/adapter/default/index","/api/v1","/api/v2","https://"],["","","",""],$s['api_url']);
$prs.="$pr: <b>$prtxt\n</b>";
$k[]=["text"=>$pr,"callback_data"=>"apidel=".$s['id']];
}
$keyboard2=array_chunk($k,3);
$keyboard2[]=[['text'=>"Orqaga",'callback_data'=>"api1"]];
$kb=json_encode([inline_keyboard=>$keyboard2]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Provayderlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
     bot('editMessageText',[
        'chat_id'=>$chat_id,
       'message_id'=>$message_id,
       'text'=>"<b>Provayderni tanlang:</b>

$prs
",
'parse_mode'=>"HTML",
'reply_markup'=>$kb,
]);
exit;
}
}

if((stripos($data,"apidel=")!==false)){
$res = explode("=",$data)[1];
del();
mysqli_query($connect,"DELETE FROM providers WHERE id = $res");
mysqli_query($connect,"DELETE FROM services WHERE api_service = $res");
sms($cid2,"🗑️ <b>Provayderni o‘chirish yakunlandi.</b>",null);
}

if($data == "api1"){
	bot('deleteMessage',[
	'chat_id'=>$chat_id,
	'message_id'=>$message_id,
	]);
	bot('SendMessage',[
	'chat_id'=>$chat_id,
'text'=>"📑 <b>Quyidagi bo'limlardan birini tanlang:</b>",
	'parse_mode'=>'html',
	'reply_markup'=>json_encode([
	'inline_keyboard'=>[
	[['text'=>"➕ API qo‘shish",'callback_data'=>"api"]],
	[['text'=>"💸 Balans",'callback_data'=>"balans"],['text'=>"🗑️ O‘chirish",'callback_data'=>"deleteapi"]],
	[['text'=>"📝 Tahrirlash",'callback_data'=>"apio=taxrirlash"]],
]
	])
	]);
	exit;
}

if($data == "api"){
	bot('deleteMessage',[
	'chat_id'=>$chat_id,
	'message_id'=>$message_id,
	]);
	bot('SendMessage',[
	'chat_id'=>$chat_id,
	'text'=>"<b>API manzilini yuboring:

Namuna:</b> <pre>https://Uzbek-Smm.uz/api/v2</pre>",
	'parse_mode'=>'html',
	'reply_markup'=>$aort,
	]);
	file_put_contents("user/$chat_id.step",'api_url');
	exit;
}

if($step == "api_url"){
	if($cid == $admin){
   if(mb_stripos($text, "https://")!==false){
	if(isset($text)){
	file_put_contents("set/api_url",$text);
	bot('SendMessage',[
	'chat_id'=>$cid,
	'text'=>"$text <b>qabul qilindi!</b>
	
	Endi esa ushbu saytdan olingan API_KEY'ni kiriting:",
'disable_web_page_preview'=>true,
	'parse_mode'=>'html',
	]);
	file_put_contents("user/$cid.step",'api');
	exit;
}
}else{
	bot('SendMessage',[
	'chat_id'=>$cid,
	'text'=>"<b>API manzilini yuboring:

Namuna:</b> <pre>https://Uzbek-Smm.uz/api/v2</pre>",
	'parse_mode'=>'html',
]);
exit;
}
}
}

if($step == "api"){
	if($cid == $admin){
	if(isset($text)){
$balans = json_decode(file_get_contents(get("set/api_url")."?key=$text&action=balance"),true);
if(isset($balans['error'])){
$admsg="⚠️ Balansni olish imkoni bo'lmadi

Extimol API kalit mavjud emas";
}else{
global $connect;
$admsg="💵 API balansi: ".$balans['balance']." ".$balans['currency']."";
$apc = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM providers"));
$api_url = get("set/api_url");
mysqli_query($connect,"INSERT INTO providers(`api_url`,`api_key`) VALUES ('$api_url','$text')");
}
	bot('SendMessage',[
	'chat_id'=>$cid,
	'text'=>"<b>$admsg</b>",
	'parse_mode'=>'html',
	'reply_markup'=>$asosiy,
	]);
	unlink("set/api_url");
	unlink("user/$cid.step");
}
}
}


if($data == "balans"){
$pr=0;
$prs="";
$a = mysqli_query($connect,"SELECT * FROM providers");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$pr++;
$prtxt=str_replace(["/api/adapter/default/index","/api/v1","/api/v2","https://"],["","","",""],$s['api_url']);
$sa= json_decode(api_query($s['api_url']."?key=".$s['api_key']."&action=balance"));
$prs.="<b>".$pr.") $prtxt</b> - ".$sa->balance." ".$sa->currency." \n";
$k[]=["text"=>$pr,"url"=>$s['api_url']."?key=".$s['api_key']."&action=balance"];
}
$keyboard2=array_chunk($k,3);
$keyboard2[]=[['text'=>"⏪ To back",'callback_data'=>"api1"]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Provayderlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
     bot('editMessageText',[
        'chat_id'=>$chat_id,
       'message_id'=>$message_id,
       'text'=>"💸<b> Choose the provider:</b>

$prs
",
'parse_mode'=>"HTML",
'reply_markup'=>$kb,
]);

}
}

if($text=="⏰ Cron sozlamasi" and $cid==$admin){
sms($cid,"
📝 Quyidagi manzillarni cron qiling
<pre>https://".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']."?update=send</pre> \n- Pochta xabari uchun cron (1 daqiqa)

 <pre>https://".$_SERVER['SERVER_NAME']."".$_SERVER['SCRIPT_NAME']."?update=status</pre>\n- Buyurtma xolati uchun cron (1 daqiqa)

<pre>https://".$_SERVER['SERVER_NAME']."/".str_replace(["/","bot.php"],["",""],$_SERVER['PHP_SELF'])."/update.php</pre> \n- Narxlarni avtomatik yangilash uchun cron (1 daqiqa)
",$m);
}

if($text=="🤝 Hamkorlik (API)" or $text=="/hamkorlik" and joinchat($cid)==1) {
$result = mysqli_query($connect,"SELECT * FROM `users` WHERE id = '$cid'");
$rew = mysqli_fetch_assoc($result);
sms($cid,"<b>🌐 API manzil: <pre>https://".$_SERVER['SERVER_NAME']."/api/v2</pre>

🔑 Sizning API kalitingiz: <pre>".$rew['api_key']."</pre>

💵 API balansingiz: <pre>".$rew['balance']." so‘m</pre></b>",keyboard([
[['text'=>"🔑 API kalitni yangilash",'callback_data'=>"reset_api"],['text'=>"📝 Xizmatlar Ro'yxati",'url'=>"https://".$_SERVER['HTTP_HOST']."/services"]],
[['text'=>"📑 Qo‘llanma",'web_app'=>['url'=>"https://".$_SERVER['SERVER_NAME']."/api"]]],
]));
}

if($data=="hamkorlik") {
del();
sms($cid2,"<b>🌐 API manzil: <pre>https://".$_SERVER['SERVER_NAME']."/api/v2</pre>

🔑 Sizning API kalitingiz: <pre>".$rew['api_key']."</pre>

💵 API balansingiz: <pre>".$rew['balance']." so‘m</pre></b>",keyboard([
[['text'=>"🔑 API kalitni yangilash",'callback_data'=>"reset_api"],['text'=>"📝 Xizmatlar Ro'yxati",'url'=>"https://".$_SERVER['HTTP_HOST']."/services"]],
[['text'=>"📑 Qo‘llanma",'web_app'=>['url'=>"https://".$_SERVER['SERVER_NAME']."/api"]]],
]));
}

if($data == "reset_api") {
edit($cid2,$mid2,"
<b>⚠️ API kalitingizni yangisiga almashtirishga ishonchingiz komilmi?</b>\n\n❔ <i>API kalitingiz yangilanganda, avvalgi API kalitdan foydalana olmaysiz.</i>",keyboard([
[['text'=>"✅ Kalitni yangilash",'callback_data'=>"apidetail=newkey"]],
[['text'=>"⏪ Ortga",'callback_data'=>"hamkorlik"]],
]));
}

if((stripos($data,"apidetail=")!==false)){
$res = explode("=",$data)[1];
if($res == "newkey"){
$newkey = md5(uniqid());
mysqli_query($connect,"UPDATE users SET api_key = '$newkey' WHERE id = '$chat_id'");
$result = mysqli_query($connect,"SELECT * FROM `users` WHERE id = '$chat_id'");
$rew = mysqli_fetch_assoc($result);
bot('editMessageText',[
'chat_id'=>$chat_id,
'parse_mode'=>"html",
'message_id'=>$message_id,
'text'=>"<b>
✅ API kalit yangilandi.

🔑 Yangi API:</b> <code>".$rew['api_key']."</code>",
'reply_markup'=>keyboard([
[['text'=>"⏪ Orqaga",'callback_data'=>"hamkorlik"]],
])
]);
}elseif($res == "qoi") {
	bot('editMessageText',[
'chat_id'=>$chat_id,
'parse_mode'=>"html",
'message_id'=>$message_id,
'text'=>"<pre>Diqqat O'qing !</pre>
<b>Botdagi Xizmatlarni admin ruhsatisiz ulab oloshingiz taqiqlanadi! agarda botdagi xizmatlarni o'z botingizga yoki saytingizga admin ruhsatisiz ulasangiz botdan bloklanasiz 📛</b>",
'reply_markup'=>keyboard([
[['text'=>"📑 Qo‘llanma",'web_app'=>['url'=>"https://".$_SERVER['SERVER_NAME']."/api"]]],
[['text'=>"⏪ Orqaga",'callback_data'=>"hamkorlik"]],
])
]);
}
}


if($text=="☎️ Murojaat" or $text=="/murojaat" and joinchat($cid)==1) {
sms($cid,"<b>🌟 Bizga savollaringiz bormi ?

📑 Murojaat matnini yozib yuboring.</b>",$ort);
put("user/$cid.step","murojaat");

}

if($step=="murojaat"){
sms($cid,"<b>✅ Murojaatingiz qabul qilindi!

iltimos admin javobini kuting ☎️</b>",$m);
bot('copyMessage',[
chat_id=>$admin,
from_chat_id=>$cid,
'message_id'=>$mid,
'reply_markup'=>json_encode([
inline_keyboard=>[
[['text'=>"👁️ Ko‘rish",url=>"tg://user?id=$cid"]],
[['text'=>"📑 Javob yozish",'callback_data'=>"javob=$cid"]],
]
]),
]);
put("user/$cid.step","");
}

if((stripos($data,"javob=")!==false)){
$ida = explode("=", $data)[1];
sms($admin,"<b>$ida Foydalanuvchiga yuboriladigan xabaringizni kiriting.</b>",$ort);
put("user/$cid2.step","ticket=$ida");

}
if((mb_stripos($step,"ticket=")!==false) and ($cid==$admin)){
$ida = explode("=",$step)[1];
$if = bot('copyMessage',[
chat_id=>$ida,
from_chat_id=>$admin,
'message_id'=>$mid,
]);

if($if->ok == 1){
sms($cid,"<i>✅ Xabar yuborildi</i>",$panel);
}else{
sms($cid,"❌ Xabar yuborilmari, extimol botni bloklagan.",$panel);
}
unlink("user/$cid.step");

}


if($text == "🛍 Xizmatlar sozlash" and $cid==$admin){
		bot('sendMessage',[
		'chat_id'=>$cid,
		'text'=>"<b>Quyidagilardan birini tanlang:</b>",
		'parse_mode'=>'html',
		'reply_markup'=>json_encode([
		'inline_keyboard'=>[
		[['text'=>"📂 Bo'limlarni sozlash",'callback_data'=>"bolim"]],
		[['text'=>"📂 Ichki bo'limlarni sozlash",'callback_data'=>"ichki"]],
		[['text'=>"🛍 Xizmatlarni sozlash",'callback_data'=>"xizmat"]]
]
])
]);

}

if($data == "xsetting" ){
del();
		bot('sendMessage',[
		'chat_id'=>$chat_id,
		'text'=>"<b>Quyidagilardan birini tanlang:</b>",
		'parse_mode'=>'html',
		'reply_markup'=>json_encode([
		'inline_keyboard'=>[
		[['text'=>"📂 Bo'limlarni sozlash",'callback_data'=>"bolim"]],
		[['text'=>"📂 Ichki bo'limlarni sozlash",'callback_data'=>"ichki"]],
		[['text'=>"🛍 Xizmatlarni sozlash",'callback_data'=>"xizmat"]]
]
])
]);

}

if($data == "bolim"){
     bot('editMessageText',[
        'chat_id'=>$chat_id,
       'message_id'=>$message_id,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"Yangi bo'lim qo'shish",'callback_data'=>"newFol"]],
[['text'=>"Tahrirlash",'callback_data'=>"editFol"]],
[['text'=>"O'chirish",'callback_data'=>"delFol"]],
[['text'=>"🔙 Orqaga", 'callback_data'=>"xsetting"]],
]
])
]);
}

if($data == "editFol"){
     bot('editMessageText',[
        'chat_id'=>$cid2,
       'message_id'=>$mid2,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"Nomini o'zgartirish",'callback_data'=>"editFols"]],
]
])
]);
}


if($data == "editFols"){
$a = mysqli_query($connect,"SELECT * FROM categorys");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$k[]=['text'=>enc("decode",$s['category_name']),'callback_data'=>"editFolss-".$s['category_id']];
}

$keyboard2=array_chunk($k,2);
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Bo'limlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
     bot('editMessageText',[
        'chat_id'=>$cid2,
       'message_id'=>$mid2,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>$kb
]);
}
}

if(mb_stripos($data, "editFolss-")!==false){
	$ex = explode("-",$data)[1];
	bot('deleteMessage',[
	'chat_id'=>$cid2,
	'message_id'=>$mid2,
]);
   bot('sendMessage',[
   'chat_id'=>$cid2,
   'text'=>"<b>Yangi qiymatni kiriting:</b>",
   'parse_mode'=>'html',
   'reply_markup'=>$ort
]);
file_put_contents("user/$cid2.step","editFol-$ex");
}

if((mb_stripos($step,"editFol-")!==false)){
	$ex = explode("-",$step)[1];
if(isset($text)){
$text=enc("encode",$text);
mysqli_query($connect,"UPDATE categorys SET category_name = '$text' WHERE category_id = $ex");
		bot('SendMessage',[
		'chat_id'=>$cid,
		'text'=>"<b>Muvaffaqiyatli o'zgartirildi.</b>",
		'parse_mode'=>'html',
		'reply_markup'=>$m
]);
unlink("user/$cid.step");
}
}



if($data=="delFol"){
$a = mysqli_query($connect,"SELECT * FROM categorys");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$k[]=['text'=>enc("decode",$s['category_name']),'callback_data'=>"delFols=".$s['category_id']];
}

$keyboard2=array_chunk($k,1);
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Bo‘limlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
edit($chat_id,$message_id,"👉 <b>O‘zingizga kerakli tarmoqni tanlang:</b>",$kb);
}
}

if(mb_stripos($data, "delFolx=")!==false){
$ex = explode("=",$data)[1];
edit($chat_id,$mid2,"<b>🗑️ Ushbu bo'limni olib tashlamoqchimisiz?\n\n⚠️ Eslatma: keyinchalik qayta tiklab bo'lmaydi!</b>",json_encode(['inline_keyboard'=>[
[['text'=>"✅ Xa",'callback_data'=>"delFols=$ex"],['text'=>"❌ Yo'q",'callback_data'=>"tanla1=$ex"]],
]]));
}

if(mb_stripos($data, "delFols=")!==false){
	$ex = explode("=",$data)[1];
	$sd = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM categorys WHERE category_id  = $ex"));
	$cd=$sd['category_id'];
	$d=enc("decode",$sd['category_name']);
$qd = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM cates WHERE category_id  = $ex"));
$sa=$qd['cate_id'];
mysqli_query($connect,"DELETE FROM services WHERE category_id=$sa");
mysqli_query($connect,"DELETE FROM cates WHERE category_id = $cd");
mysqli_query($connect,"DELETE FROM categorys WHERE category_id='$ex'");
     bot('deleteMessage',[
	'chat_id'=>$chat_id,
	'message_id'=>$message_id,
]);
   bot('sendMessage',[
   'chat_id'=>$chat_id,
       'text'=>"✅ <b>Bo'lim va uning ichki bo'limlari muvaffaqiyatli olib tashlandi!</b>",
'parse_mode'=>'html',
'reply_markup'=>$m
]);
}



if($data == "newFol"){
	bot('deleteMessage',[
	'chat_id'=>$chat_id,
	'message_id'=>$message_id,
]);
   bot('sendMessage',[
   'chat_id'=>$chat_id,
   'text'=>"<b>Yangi bo'lim nomini yuboring:</b>",
   'parse_mode'=>'html',
   'reply_markup'=>$ort
]);
file_put_contents("user/$chat_id.step",'newFol');
}

if($step == "newFol" and $text!="▶️ Orqaga"){
$res = mysqli_query($connect, "SELECT * FROM `categorys`");
$n = mysqli_fetch_assoc($res);
$texti=enc("encode",$text);
mysqli_query($connect,"INSERT INTO categorys(category_name,category_status) VALUES('$texti','ON');");
		bot('SendMessage',[
		'chat_id'=>$cid,
		'text'=>"✅ <b>Bo'lim muvaffaqiyatli qo'shildi:</b> $text",
		'parse_mode'=>'html',
		'reply_markup'=>$m
]);
unlink("user/$cid.step");
}


if($data == "ichki"){
     bot('editMessageText',[
        'chat_id'=>$chat_id,
       'message_id'=>$message_id,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"Yangi ichki bo'lim qo'shish",'callback_data'=>"newFold"]],
[['text'=>"Tahrirlash",'callback_data'=>"editFold"]],
[['text'=>"O'chirish",'callback_data'=>"delFold"]],
[['text'=>"🔙 Orqaga", 'callback_data'=>"xsetting"]],
]
])
]);
}

if($data == "editFold"){
     bot('editMessageText',[
        'chat_id'=>$cid2,
       'message_id'=>$mid2,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"Nomini o'zgartirish",'callback_data'=>"editFolds"]],
]
])
]);
}



if($data == "editFolds"){
$a = mysqli_query($connect,"SELECT * FROM categorys");
while($s = mysqli_fetch_assoc($a)){
$k[]=['text'=>enc("decode",$s['category_name']),'callback_data'=>"editFolds-".$s['category_id']];
}

$keyboard2=array_chunk($k,1);
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
     bot('editMessageText',[
        'chat_id'=>$cid2,
       'message_id'=>$mid2,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>$kb
]);
}

if(mb_stripos($data, "editFolds-")!==false){
$n = explode("-",$data)[1];
$new_arr = [];
$k = [];
$a = mysqli_query($connect,"SELECT * FROM cates WHERE category_id = $n");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
if(!in_array(enc("decode",$s['name']), $new_arr)){
$new_arr[] = enc("decode",$s['name']);
$k[]=['text'=>enc("decode",$s['name']),'callback_data'=>"editFoldm-".$s['cate_id']];
}
}
$keyboard2=array_chunk($k,1);
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Ushbu bo'lim uchun xizmat turlari topilmadi!",
		'show_alert'=>true,
		]);
	}else{
     bot('editMessageText',[
        'chat_id'=>$cid2,
       'message_id'=>$mid2,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>$kb
]);
}
}

if(mb_stripos($data, "editFoldm-")!==false){
	$ex = explode("-",$data)[1];
	bot('deleteMessage',[
	'chat_id'=>$cid2,
	'message_id'=>$mid2,
]);
   bot('sendMessage',[
   'chat_id'=>$cid2,
   'text'=>"<b>Yangi qiymatni kiriting:</b>",
   'parse_mode'=>'html',
   'reply_markup'=>$ort
]);
file_put_contents("user/$cid2.step","editFoldms-$ex");

}

if(mb_stripos($step, "editFoldms-")!==false){
	$ex = explode("-",$step)[1];
	if(isset($text)){
	$text=enc("encode",$text);
		mysqli_query($connect,"UPDATE cates SET name = '$text' WHERE cate_id = $ex");
		bot('SendMessage',[
		'chat_id'=>$cid,
		'text'=>"<b>Muvaffaqiyatli o'zgartirildi.</b>",
		'parse_mode'=>'html',
		'reply_markup'=>$m
]);
unlink("user/$cid.step");
}
}





if($data == "delFold"){
$a = mysqli_query($connect,"SELECT * FROM categorys");
while($s = mysqli_fetch_assoc($a)){
$k[]=['text'=>enc("decode",$s['category_name']),'callback_data'=>"delFolds=".$s['category_id']];
}

$keyboard2=array_chunk($k,2);
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
     bot('editMessageText',[
        'chat_id'=>$cid2,
       'message_id'=>$mid2,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>$kb
]);
}

if(mb_stripos($data, "delFolds=")!==false){
$bolim = explode("=",$data)[1];
$new_arr = [];
$k = [];
$a = mysqli_query($connect,"SELECT * FROM cates WHERE category_id = $bolim");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
if(!in_array(enc("decode",$s['name']), $new_arr)){
$new_arr[] = enc("decode",$s['name']);
$k[]=['text'=>enc("decode",$s['name']),'callback_data'=>"delFolm=".$s['cate_id']];
}
}
$keyboard2=array_chunk($k,1);
$keyboard2[]=[['text'=>"Orqaga",'callback_data'=>"absd"]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Ushbu bo'lim uchun xizmat turlari topilmadi!",
		'show_alert'=>true,
		]);
	}else{
     bot('editMessageText',[
        'chat_id'=>$cid2,
       'message_id'=>$mid2,
     'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>$kb
]);
}
}

if(mb_stripos($data,"ichkidel=")!==false){
$ex = explode("=",$data)[1];
edit($cid2,$mid2,"<b>⚠️ Ushbu ichki bo'limni o'chirasizmi?</b>",json_encode([        
        'inline_keyboard'=>[
        [['text'=>"✅ Xa",'callback_data'=>"delFolm=$ex"],['text'=>"❌ Yo'q",'callback_data'=>"tanla2=$ex"]]
]]));
exit();
}


if(mb_stripos($data, "delFolm=")!==false){
	$ex = explode("=",$data)[1];
$qd = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM cates WHERE cate_id  = $ex"));
$sa=$qd['cate_id'];
$d = enc("decode",$qd['name']);
mysqli_query($connect,"DELETE FROM services WHERE category_id=$sa");
mysqli_query($connect,"DELETE FROM cates WHERE cate_id=$ex");
     bot('deleteMessage',[
	'chat_id'=>$cid2,
	'message_id'=>$mid2,
]);
   bot('sendMessage',[
   'chat_id'=>$cid2,
       'text'=>"<b>✅ Muvaffaqiyatli olib tashlandi!</b>",
'parse_mode'=>'html',
'reply_markup'=>$m
]);

}


if($data == "newFold"){
$a = mysqli_query($connect,"SELECT * FROM categorys");
while($s = mysqli_fetch_assoc($a)){
$k[]=['text'=>enc("decode",$s['category_name']),'callback_data'=>"adFol=".$s['category_id']];
}

$keyboard2=array_chunk($k,2);
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
     bot('editMessageText',[
        'chat_id'=>$chat_id,
       'message_id'=>$message_id,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>$kb
]);
}


if(mb_stripos($data, "adFol=")!==false){
	$ex = explode("=",$data)[1];
	file_put_contents("set/c.txt",$ex);
	bot('deleteMessage',[
	'chat_id'=>$chat_id,
	'message_id'=>$message_id,
]);
   bot('sendMessage',[
   'chat_id'=>$chat_id,
   'text'=>"📝 <b>Yangi ichki bo'lim nomini yuboring:</b>",
   'parse_mode'=>'html',
   'reply_markup'=>$ort
]);
file_put_contents("user/$chat_id.step",'newFold');
}


if($step == "newFold"){
		if(isset($text)){
$ci=get("set/c.txt");
$to=enc("encode",$text);
mysqli_query($connect,"INSERT INTO cates(`name`,`category_id`) VALUES ('$to','$ci')");
		bot('sendMessage',[
		'chat_id'=>$cid,
		'text'=>"✅ <b>Ichki bo'lim muvaffaqiyatli qo'shildi:</b> $text",
		'parse_mode'=>'html',
		'reply_markup'=>json_encode([        
        'inline_keyboard'=>[
        [['text'=>"➕ Yana ichki bo'lim qo'shish",'callback_data'=>"adFol=$ci"]],
        [['text'=>"⏩ Orqaga",'callback_data'=>"main"]],
       ]]),
]);
unlink("user/$cid.step");
}
}

if(mb_stripos($data,"edxizm=")!==false){
$n=explode("=",$data)[1];
$ex=explode("=",$data)[2];
$ex2=explode("=",$data)[3];
$a = mysqli_query($connect,"SELECT * FROM services WHERE service_id= '$n'");
while($s = mysqli_fetch_assoc($a)){
$nam = base64_decode($s['service_name']);
$sid = $s['service_id'];
$narx = $s['service_price'];
$curr = $s['api_currency'];
$ab = $s['service_desc'] ? $ab=$s['service_desc'] : null;
$api = $s['api_service'];
$type=$s['service_type'];
$spi = $s['service_api'];
$min=$s["service_min"];
$max=$s["service_max"];
}

$ap = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM providers WHERE id = $api"));
$surl=$ap['api_url'];
$skey=$ap['api_key'];
$j=json_decode(get($surl."?key=".$skey."&action=services"), true);
foreach($j as $el){
if($el['service']==$spi){
$amin=$el["min"];
$amax=$el["max"];
break;
}
}
if($ab==null){$abs="null";}else{
$abs=base64_decode($ab);}
edit($cid2,$mid2,"<b>
✅ Tahrirlash uchun ko‘rib chiqing:

📝 Narx:</b> $narx so'm 
📝 <b>API valyutasi:</b> $curr
📝 <b>API saytdagi ID:</b> $api
📝 <b>Turi:</b> $type
📝 <b>Minimal:</b> $min
📝 <b>Maximal:</b> $max
📝 <b>Nomi:</b> $nam
📝 <b>Ma'lumot: $abs</b>", json_encode([
'inline_keyboard'=>[
[['text'=>"📝 API ID",'callback_data'=>"editXts-$sid-api_service"],['text'=>"📝 Narxi",'callback_data'=>"editXts-$sid-service_price"]],
[['text'=>"📝 Nomi",'callback_data'=>"editXts-$sid-service_name"],['text'=>"📝 Malumot",'callback_data'=>"editXts-$sid-service_desc"]],
[['text'=>"📝 Minimal",'callback_data'=>"editXts-$sid-service_min"],['text'=>"📝 Maksimal",'callback_data'=>"editXts-$sid-service_max"]],
[['text'=>"🗑️ O'chirish",'callback_data'=>"dxiz-$sid"],['text'=>"⏩ Orqaga",'callback_data'=>"ordered=$sid=$ex=$ex2"]],
]]));
}

if(mb_stripos($data,"dxiz-")!==false){
$sid = explode("-",$data)[1];
$ex = explode("-",$data)[2];
$ex2 = explode("-",$data)[3];
edit($cid2,$mid2,"<b>🗑️ Ushbu xizmatni o'chirmoqchimisiz?</b>",json_encode(['inline_keyboard'=>[
[['text'=>"✅ Xa",'callback_data'=>"delmat-$sid"],['text'=>"❌ Yo'q",'callback_data'=>"edxizm=$sid=$ex=$ex2"]],
]]));
}

if($data == "xizmat"){
     bot('editMessageText',[
        'chat_id'=>$chat_id,
       'message_id'=>$message_id,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"Yangi xizmat qo'shish",'callback_data'=>"newXiz"]],
[['text'=>"Xizmatlarni yuklab olish",'callback_data'=>"uplXiz"]],
[['text'=>"Tahrirlash",'callback_data'=>"editXiz"]],
[['text'=>"O'chirish",'callback_data'=>"delXiz"]],
[['text'=>"🔙 Orqaga", 'callback_data'=>"xsetting"]],
]
])
]);
}

if($data == "uplXiz"){
$a = mysqli_query($connect,"SELECT * FROM categorys");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$k[]=['text'=>enc("decode",$s['category_name']),'callback_data'=>"uplad=".$s['category_id']];
}
$keyboard2=array_chunk($k,2);
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Bo‘limlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
     bot('editMessageText',[
        'chat_id'=>$chat_id,
       'message_id'=>$message_id,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>$kb
]);
}
}


if(mb_stripos($data, "uplad=")!==false){
$n = explode("=",$data)[1];
$upx = json_decode(get("set/upladd.json"),1);
$upx['category_id']=$n;
file_put_contents("set/upladd.json",json_encode($upx,JSON_PRETTY_PRINT));
$new_arr = [];
$k = [];
$a = mysqli_query($connect,"SELECT * FROM cates WHERE category_id = $n");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
if(!in_array(enc("decode",$s['name']), $new_arr)){
$new_arr[] = enc("decode",$s['name']);
$k[]=['text'=>enc("decode",$s['name']),'callback_data'=>"uplads-".$s['cate_id']];
}
}
$keyboard2=array_chunk($k,1);
$keyboard2[]=[['text'=>"Orqaga",'callback_data'=>"uplXiz"]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Ushbu bo'lim uchun xizmat turlari topilmadi!",
		'show_alert'=>true,
		]);
	}else{
bot('editMessageText',[
        'chat_id'=>$chat_id,
       'message_id'=>$message_id,
'text'=>"<b>Quyidagilardan birini tanlang:</b>",
   'parse_mode'=>'html',
   'reply_markup'=>$kb
]);
}
}

if(stripos($data,"uplads-")!==false){
$n = explode("-",$data)[1];
$upx = json_decode(get("set/upladd.json"),1);
$upx['cate_id']=$n;
file_put_contents("set/upladd.json",json_encode($upx,JSON_PRETTY_PRINT));
$pr=0;
$prs="";
$a = mysqli_query($connect,"SELECT * FROM providers");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$pr++;
$prtxt=str_replace(["/api/adapter/default/index","/api/v1","/api/v2","https://"],["","","",""],$s['api_url']);
$prs.="<b>".$pr."</b>: $prtxt\n";
$k[]=['text'=>$pr,'callback_data'=>"uplprv-".$s['id']];
}
$keyboard2=array_chunk($k,3);
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Provayderlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
		del();
     bot('sendMessage',[
        'chat_id'=>$chat_id,
       'text'=>"Provayderni tanlang:
 
$prs",
'parse_mode'=>"HTML",
'reply_markup'=>$kb,
]);

}
}

if(stripos($data,"uplprv-")!==false){
$n = explode("-",$data)[1];
$upx = json_decode(get("set/upladd.json"),1);
$upx['provider']=$n;
file_put_contents("set/upladd.json",json_encode($upx,JSON_PRETTY_PRINT));
edit($chat_id,$message_id,"Provayderning API valyutasini tanlang:",json_encode([
inline_keyboard=>[
[['text'=>"UZS",'callback_data'=>"uplval-UZS-".$upx['provider']]],
[['text'=>"USD",'callback_data'=>"uplval-USD-".$upx['provider']]],
[['text'=>"RUB",'callback_data'=>"uplval-RUB-".$upx['provider']]],
[['text'=>"INR",'callback_data'=>"uplval-INR-".$upx['provider']]],
[['text'=>"TRY",'callback_data'=>"uplval-TRY-".$upx['provider']]],
]]));

}


if(stripos($data,"uplval-")!==false){
$n = explode("-",$data)[1];
$prv = explode("-",$data)[2];
$upx = json_decode(get("set/upladd.json"),1);
$upx['currency']=$n;
file_put_contents("set/upladd.json",json_encode($upx,JSON_PRETTY_PRINT));
$h = json_decode(arr($prv));
$ko=1;
if($h->error) {
bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Serverda nosozlik

Qaytadan urining",
		'show_alert'=>true,
		]);
		
		}else{
for($i=0;$i<=22;$i++){
if($h->results[$i]->name){
$arr3 []=['text'=>"".$h->results[$i]->name."",'callback_data'=>"apload=$i=$prv"];
}
}
}
$arr = array_chunk($arr3,1);
$arr[]=[['text'=>"🔙Orqaga",'callback_data'=>"main"],['text'=>"▶️ Keyingi",'callback_data'=>"nexti=next=$prv=$ko=$i"]];
$kb = json_encode([
'inline_keyboard'=>$arr,
]);
if(empty($h->results[$i]->name)){exit;}else{
edit($chat_id,$message_id,"<b>Xizmat yuklash uchun kategoriyani tanlang:</b>",$kb);
}}

if((stripos($data,"nexti=")!==false)){
$res=explode("=",$data)[1];
$prv=explode("=",$data)[2];
$ko=explode("=", $data)[3];
$kl=explode("=",$data)[4];
$h = json_decode(arr($prv));
$ko=$kl;
if($h->error) {
bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Serverda nosozlik

Qaytadan urining",
		'show_alert'=>true,
		]);
		
		}else{
if($res=="next"){
$ma = $kl*2;
for($i=$kl;$i<=$ma;$i++){
$d = $h->results[$i]->name ? $h->results[$i]->name : "";
if($h->results[$i]->name){
$arr3 []=['text'=>$d,'callback_data'=>"apload=$i=$prv"];
}}}

$arr = array_chunk($arr3,1);

$arr[]=[['text'=>"Orqaga",'callback_data'=>"main"],['text'=>"▶️ Keyingi",'callback_data'=>"nexti=next=$prv=$ko=$i"]];
$kb = json_encode([
'inline_keyboard'=>$arr,
]);
if(empty($d)){}else{
edit($chat_id,$message_id,"<b>Xizmat yuklash uchun kategoriyani tanlang:</b>",$kb);
exit();
}}
}

if((stripos($data,"apload=")!==false)){
$qa = explode("=", $data)[1];
$qa=$qa+1;
$prv=explode("=",$data)[2];
$h = json_decode(arr($prv),1);
if($h['error']){
bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Serverda nosozlik
	
Qaytadan urining",
		'show_alert'=>true,
		]);

		}
foreach($h['results'] as $vs){
if($vs['id']==$qa){
$nq = $vs['name'] ? $nq=$vs['name'] : "";
}
}
bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"$nq - uchun xizmatlar qidirilmoqda

Iltimos kuting...",
		'show_alert'=>true,
		]);
$upx = json_decode(get("set/upladd.json"),1);
$upx['category']=$nq;
file_put_contents("set/upladd.json",json_encode($upx,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
$s = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `providers` WHERE id = $prv"));
$j=json_decode(file_get_contents($s['api_url']."?key=".$s['api_key']."&action=services"),1);
$service_count = 0;
$serviceid = 0;
foreach($j as $el){
if($el['category']==$nq){

$service_count++;
$serviceid++;
$name=$el["name"];
$txe = $el['service'];
$min=$el["min"];
$max=$el["max"];
$type=$el['type'];
$service_ide=$el['service'];
$cancel=$el['cancel'] ? 'true':'false';
$dripfeed=$el['dripfeed'] ? 'true':'false';
$refill=$el['refill'] ? 'true':'false';
$k[]=['text'=>($name),'callback_data'=>"couple=".$txe];
}
}
$ko =array_chunk($k,1);
if(empty($service_count)) {
bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Serverda nosozlik
	
Qaytadan urining",
		'show_alert'=>true,
		]);

}else{
$ko[]=[['text'=>"✅ Barchasini yuklab olish",'callback_data'=>"allapl=$prv"]];
}
$ko[]=[['text'=>"Orqaga",'callback_data'=>"xizmat"]];
$kb = json_encode([
inline_keyboard=>$ko
]);
if($service_count != "0"){
edit($chat_id,$message_id,"
<b>$nq</b>

🔢 <u>Xizmatlar soni:</u> $service_count - ta",$kb);
}
}

if((stripos($data,"allapl=")!==false)){
del();
	$prv=explode("=",$data)[1];
$mas=bot('sendMessage',[
		'chat_id'=>$chat_id,
		'text'=>"📂 <b>Yuklab olish boshlandi!..

🔔 Iltimos kuting...</b>",
'parse_mode'=>html,
		])->result->message_id;
		
		$upx = json_decode(get("set/upladd.json"),1);
		
$s = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `providers` WHERE id = $prv"));

$j=json_decode(file_get_contents($s['api_url']."?key=".$s['api_key']."&action=services"),1);
if(empty($j)){
edit($cid2,$mas,"⚠️ Serverda nosozlik

Qaytadan urining",null);
}else{
$service_id = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM `services`"));
foreach($j as $el){
if($el['category']==$upx['category']){
$service_id++;
$name=($el["name"]);
$tas = $el['service'];
$min=$el["min"];
$max=$el["max"];
$rate=$el["rate"];
$type=$el['type'];
$cancel=$el['cancel'] ? 'true':'false';
$dripfeed=$el['dripfeed'] ? 'true':'false';
$refill=$el['refill'] ? 'true':'false';
if($upx['currency']=="USD"){
$fr=get("set/usd");
}elseif($upx['currency']=="RUB"){
$fr=get("set/rub");
}elseif($upx['currency']=="INR"){
$fr=get("set/inr");
}elseif($upx['currency']=="TRY"){
$fr=get("set/try");
}elseif($upx['currency']=="UZS"){
$fr = 1;
}

$foiz=mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM percent WHERE id = 1"))['percent'];
$rate=$rate*$fr;
$rp=$rate/100;
$rp=$rp*$foiz+$rate;


$service_price = $rp;
$category_id=$upx['cate_id'];
$api_service=$prv; 
$api_currency =$upx['currency']; 
$service_name = base64_encode(mb_convert_encoding(trans($name),"UTF-8","UTF-8"));
$service_desc=null;
$service_edit = "true";
$sq=mysqli_query($connect,"INSERT INTO 
services(`service_status`,`service_edit`,`service_price`,`category_id`,`service_api`,`api_service`,`api_currency`,`service_type`,`api_detail`,`service_name`,`service_desc`,`service_min`,`service_max`) VALUES ('on','$service_edit','$service_price','$category_id','$tas','$api_service','$api_currency','$type','{\"name\":\"$name\",\"min\":\"$min\",\"max\":\"$max\",\"type\":\"$type\",\"cancel\":\"$cancel\",\"refill\":\"$refill\",\"dripfeed\":\"$dripfeed\"}','$service_name','$service_desc','$min','$max');");
}
}
edit($chat_id,$mas,"✅ <b>Yuklab olish jarayoni tugallandi.</b>",json_encode(['inline_keyboard'=>[
[['text'=>"⏩ Orqaga",'callback_data'=>"absd"]]]]));
unlink("user/$cid2.step");
}
}



if($data == "editXiz"){
     bot('editMessageText',[
        'chat_id'=>$cid2,
       'message_id'=>$mid2,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"API xizmat IDsini o'zgartirish",'callback_data'=>"editXizmat-service_api"]],
[['text'=>"Xizmat nomini o'zgartirish",'callback_data'=>"editXizmat-service_name"]],
[['text'=>"Malumotlarni o'zgartirish", 'callback_data'=>"editXizmat-service_desc"]],
[['text'=>"Narxini o‘zgartirish",'callback_data'=>"editXizmat-service_price"]],
[['text'=>".Min buyurtmani o‘zgartirish",'callback_data'=>"editXizmat-service_min"]],
[['text'=>".Max buyurtmani o‘zgartirish",'callback_data'=>"editXizmat-service_max"]],
[['text'=>"🔙 Orqaga", 'callback_data'=>"xizmat"]],
]
])
]);
}

if(mb_stripos($data, "editXizmat-")!==false){
$nomi = explode("-",$data)[1];
file_put_contents("user/$cid2.txt",$nomi);
$a = mysqli_query($connect,"SELECT * FROM categorys");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$k[]=['text'=>enc("decode",$s['category_name']),'callback_data'=>"editXizmats-".$s['category_id']];
}

$keyboard2=array_chunk($k,2);
$keyboard2[]=[['text'=>"Orqaga",'callback_data'=>"editXiz"]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Tarmoqlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
     bot('editMessageText',[
        'chat_id'=>$cid2,
       'message_id'=>$mid2,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>$kb
]);
}
}


if(mb_stripos($data, "editXizmats-")!==false){
$bolim = explode("-",$data)[1];
$new_arr = [];
$k = [];
$a = mysqli_query($connect,"SELECT * FROM cates WHERE category_id = $bolim");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
if(!in_array(enc("decode",$s['name']), $new_arr)){
$new_arr[] = enc("decode",$s['name']);
$k[]=['text'=>enc("decode",$s['name']),'callback_data'=>"editXt-".$s['cate_id']];
}
}
$keyboard2=array_chunk($k,1);
$keyboard2[]=[['text'=>"Orqaga",'callback_data'=>"editXizmat-$bolim"]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Ushbu bo'lim uchun xizmat turlari topilmadi!",
		'show_alert'=>true,
		]);
	}else{
     bot('editMessageText',[
        'chat_id'=>$cid2,
       'message_id'=>$mid2,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>$kb
]);
}
}


if(mb_stripos($data, "editXt-")!==false){
$n=explode("-",$data)[1];
$as=1;
$a = mysqli_query($connect,"SELECT * FROM services WHERE category_id = '$n'");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$txts.="<b>".$as."</b>: ".base64_decode($s['service_name'])."\n";
$k[]=['text'=>$as++,'callback_data'=>"editXts-".$s['service_id']];
}
$keyboard2=array_chunk($k,2);
$keyboard2[]=[['text'=>"Orqaga",'callback_data'=>"editXizmats-$n"]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>" ⚠️ Ushbu bo'lim uchun xizmatlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
     bot('editMessageText',[
        'chat_id'=>$cid2,
       'message_id'=>$mid2,
    'text'=>"<b>Quyidagilardan birini tanlang:\n\n$txts</b>",
'parse_mode'=>'html',
'reply_markup'=>$kb
]);
}
}

if(mb_stripos($data, "editXts-")!==false){
	$xiz = explode("-",$data)[1];
	$xizm = explode("-",$data)[2];
	/*bot('deleteMessage',[
	'chat_id'=>$cid2,
	'message_id'=>$mid2,
]);*/
   bot('sendMessage',[
   'chat_id'=>$cid2,
   'text'=>"<b>Yangi qiymatni kiriting:</b>",
   'parse_mode'=>'html',
   'reply_markup'=>$ort
]);
file_put_contents("user/$cid2.step","editXizmatlar-$xiz-$xizm");
}

if(mb_stripos($step, "editXizmatlar-")!==false){
	$xiz = explode("-",$step)[1];
	$ex = explode("-",$step)[2];
	//$ex = file_get_contents("user/$cid.txt");
	if($cid == $admin and isset($text)){
		if($ex=="service_desc"){
		$ex = file_get_contents("user/$cid.txt");
		$vo = base64_encode($text);
		mysqli_query($connect,"UPDATE services SET service_desc='$vo' WHERE service_id = $xiz");
		}elseif($ex=="service_name"){
		$ex = file_get_contents("user/$cid.txt");
		$vo = base64_encode($text);
		mysqli_query($connect,"UPDATE services SET service_name='$vo' WHERE service_id = $xiz");
		}elseif($ex=="service_id"){
		$ex = file_get_contents("user/$cid.txt");
		$vo = $text;
		mysqli_query($connect,"UPDATE services SET service_api='$vo' WHERE service_id = $xiz");
		}elseif($ex=="service_price"){
		$ex = file_get_contents("user/$cid.txt");
		$vo = $text;
		mysqli_query($connect,"UPDATE services SET service_edit='false', service_price='$vo' WHERE service_id = $xiz");
		}elseif($ex=="service_min"){
		$ex = file_get_contents("user/$cid.txt");
		$vo = $text;
		mysqli_query($connect,"UPDATE services SET service_edit='false', service_min='$vo' WHERE service_id = $xiz");
		}elseif($ex=="service_max"){
		$ex = file_get_contents("user/$cid.txt");
		$vo = $text;
		mysqli_query($connect,"UPDATE services SET service_edit='false', service_max='$vo' WHERE service_id = $xiz");
		}
		bot('SendMessage',[
		'chat_id'=>$cid,
		'text'=>"<b> Muvaffaqiyatli o'zgartirildi.</b>",
		'parse_mode'=>'html',
		'reply_markup'=>json_encode(['inline_keyboard'=>[
[['text'=>"⏩ Orqaga",'callback_data'=>"ordered=$sid=$ex=$ex2"]]]])
]);
unlink("user/$cid.step");
unlink("user/$cid.txt");
}
}




if($data == "delXiz"){
$a = mysqli_query($connect,"SELECT * FROM categorys");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$k[]=['text'=>enc("decode",$s['category_name']),'callback_data'=>"deleteXiz-".$s['category_id']];
}
$keyboard2=array_chunk($k,2);
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Bo‘limlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
     bot('editMessageText',[
        'chat_id'=>$chat_id,
       'message_id'=>$message_id,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>$kb
]);

}
}

if(mb_stripos($data, "deleteXiz-")!==false){
	$n = explode("-",$data)[1];
   file_put_contents("set/c.txt",$ex);
$new_arr = [];
$k = [];
$a = mysqli_query($connect,"SELECT * FROM cates WHERE category_id = $n");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
if(!in_array(enc("decode",$s['name']), $new_arr)){
$new_arr[] = enc("decode",$s['name']);
$k[]=['text'=>enc("decode",$s['name']),'callback_data'=>"delx-".$s['cate_id']];
}
}
$keyboard2=array_chunk($k,1);
$keyboard2[]=[['text'=>"Orqaga",'callback_data'=>"newXiz"]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Ushbu bo'lim uchun xizmat turlari topilmadi!",
		'show_alert'=>true,
		]);
	}else{
bot('editMessageText',[
        'chat_id'=>$chat_id,
       'message_id'=>$message_id,
'text'=>"<b>Quyidagilardan birini tanlang:</b>",
   'parse_mode'=>'html',
   'reply_markup'=>$kb
]);
}
}

if(mb_stripos($data, "delx-")!==false){
	$n=explode("-",$data)[1];
$as=0;
$a = mysqli_query($connect,"SELECT * FROM services WHERE category_id = '$n'");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$as++;
$narx = $s['service_price'];
$txts.="<b>".$as."</b>: ".base64_decode($s['service_name'])." $narx - so‘m\n";

$k[]=['text'=>$as,'callback_data'=>"delmat-".$s['service_id']];
}
$keyboard2=array_chunk($k,5);
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Ushbu bo'lim uchun xizmatlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
edit($chat_id,$message_id,"
👉 O‘zingizga kerakli xizmatni tanlang:

$txts",$kb);

}
}

if(mb_stripos($data, "delmat-")!==false){
$ichki = explode("-",$data)[1];
mysqli_query($connect,"DELETE FROM services WHERE service_id = $ichki");
     bot('deleteMessage',[
	'chat_id'=>$cid2,
	'message_id'=>$mid2,
]);
   bot('sendMessage',[
   'chat_id'=>$cid2,
       'text'=>"<b>✅ Muvaffaqiyatli o'chirildi !</b>",
'parse_mode'=>'html',
'reply_markup'=>$ort
]);
}







if($data == "newXiz"){
$a = mysqli_query($connect,"SELECT * FROM categorys");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$k[]=['text'=>enc("decode",$s['category_name']),'callback_data'=>"add=".$s['category_id']];
}
$keyboard2=array_chunk($k,2);
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Bo‘limlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
     bot('editMessageText',[
        'chat_id'=>$chat_id,
       'message_id'=>$message_id,
       'text'=>"<b>Quyidagilardan birini tanlang:</b>",
'parse_mode'=>'html',
'reply_markup'=>$kb
]);
}
}


if(mb_stripos($data, "add=")!==false){
$n = explode("=",$data)[1];
file_put_contents("set/c.txt",$n);
$new_arr = [];
$k = [];
$a = mysqli_query($connect,"SELECT * FROM cates WHERE category_id = $n");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
if(!in_array(enc("decode",$s['name']), $new_arr)){
$new_arr[] = enc("decode",$s['name']);
$k[]=['text'=>enc("decode",$s['name']),'callback_data'=>"adds-".$s['cate_id']];
}
}
$keyboard2=array_chunk($k,1);
$keyboard2[]=[['text'=>"Orqaga",'callback_data'=>"newXiz"]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Ushbu bo'lim uchun xizmat turlari topilmadi!",
		'show_alert'=>true,
		]);
	}else{
bot('editMessageText',[
        'chat_id'=>$chat_id,
       'message_id'=>$message_id,
'text'=>"<b>Quyidagilardan birini tanlang:</b>",
   'parse_mode'=>'html',
   'reply_markup'=>$kb
]);
}
}

if(mb_stripos($data, "adds-")!==false){
$pw=explode("-",$data)[1];
$adds=json_decode(get("set/adds.json"),1);
$adds['cate_id']=$pw;
$a = mysqli_query($connect,"SELECT * FROM providers");
$c = mysqli_num_rows($a);
if(!$c){
bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Provayderlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
$adds['category_id']=file_get_contents("set/c.txt");
put("set/adds.json",json_encode($adds,JSON_UNESCAPED_UNICODE));
	bot('deleteMessage',[
	'chat_id'=>$chat_id,
	'message_id'=>$message_id,
]);
   bot('sendMessage',[
   'chat_id'=>$chat_id,
   'text'=>"<b>Yangi xizmat nomini yuboring:</b>",
   'parse_mode'=>'html',
   'reply_markup'=>$ort
]);
file_put_contents("user/$chat_id.step",'servisw');

}
}
if($step == "servisw"){
$pr=0;
$prs="";
$a = mysqli_query($connect,"SELECT * FROM providers");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$pr++;
$prtxt=str_replace(["/api/v1","/api/v2","https://"],["","",""],$s['api_url']);
$prs.="<b>".$pr."</b>: $prtxt\n";
$k[]=['text'=>$pr,'callback_data'=>"checkC-".$s['id']];
}
$keyboard2=array_chunk($k,3);
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	bot('sendMessage',[
		chat_id=>$cid,
		'text'=>"⚠️ Provayderlar topilmadi!",
		]);
	}else{
     bot('sendMessage',[
        'chat_id'=>$cid,
       'text'=>"Provayderni tanlang:
 
$prs",
'parse_mode'=>"HTML",
'reply_markup'=>$kb,
]);

put("set/adds.json.name",$text);
file_put_contents("user/$cid.step","servis0");

}
}

if((stripos($data,"checkC-")!==false and $stepc=="servis0" and $chat_id==$admin)){
$pw=explode("-",$data)[1];
sms($chat_id,"Provayderning API xizmatlari bolimida korsatilgan valyutani tanlang:",json_encode([
'inline_keyboard'=>[
[['text'=>"UZS ",'callback_data'=>"checkP-UZS"]],
[['text'=>"USD ",'callback_data'=>"checkP-USD"]],
[['text'=>"RUB ",'callback_data'=>"checkP-RUB"]],
[['text'=>"INR ",'callback_data'=>"checkP-INR"]],
[['text'=>"TRY ",'callback_data'=>"checkP-TRY"]],
]]));
$adds=json_decode(get("set/adds.json"),1);
$adds['api_service']=$pw;
put("set/adds.json",json_encode($adds,JSON_UNESCAPED_UNICODE));
file_put_contents("user/$chat_id.step",'servis1');
}

if((stripos($data,"checkP-")!==false and  $stepc=="servis1" and $chat_id==$admin)){
$pw=explode("-",$data)[1];
if(isset($data)){
del();
sms($chat_id,"📝 Xizmat xaqida malumotlar kiriting:


⚠️ Ma'lumot kiritish ni xoxlamasangiz <b>Kiritilmagan</b> tugmasini bosing",json_encode([
'resize_keyboard'=>true,
'keyboard'=>[
[['text'=>"Kiritilmagan"]],
[['text'=>"⏩ Orqaga"]],
]]));
$adds=json_decode(get("set/adds.json"),1);
$adds['api_currency']=$pw;
put("set/adds.json",json_encode($adds,JSON_UNESCAPED_UNICODE));
file_put_contents("user/$chat_id.step",'servis2');
}
}
if(($step=="servis2" and $cid==$admin)){
if(isset($text)){
sms($cid,"💵 <b>Buyurtma narxini yuboring (1000 ta)</b>",$aort);
if($text=="Kiritilmagan"){
put("set/adds.json.desc","");
}else{
put("set/adds.json.desc",$text);
}
file_put_contents("user/$cid.step",'servis3');
}
}


if(($step=="servis3" and $cid==$admin)){
if(is_numeric($text)){
sms($cid,"🆔 <b>Xizmat ID sini yuboring:</b>",$ort);
$adds=json_decode(get("set/adds.json"),1);
$adds['service_price']=$text;
put("set/adds.json",json_encode($adds,JSON_UNESCAPED_UNICODE));
file_put_contents("user/$cid.step",'servisID');
}
}


if($step=="servisID"){
if(is_numeric($text)){
$pw = json_decode(get("set/adds.json"));
$cure = $pw->api_service;
$ap = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM providers WHERE id = $cure"));
$surl=$ap['api_url'];
$skey=$ap['api_key'];
$j=json_decode(get($surl."?key=".$skey."&action=services"), true);
foreach($j as $el){
if($el['service']=="$text"){
$name=$el["name"];
$min=$el["min"];
$max=$el["max"];
$rate=$el["rate"];
$rate=$el["rate"];
$type=$el['type'];
$tas = $el['service'];
$cancel=$el['cancel'] ? 'true':'false';
$dripfeed=$el['dripfeed'] ? 'true':'false';
$refill=$el['refill'] ? 'true':'false';
break;
}
}


if(empty($min) or empty($max)){
sms($cid,"
🔕 <b>Noma'lum xatolik yuz berdi.

Qaytadan xizmat IDsini yuboring:</b>",null);
}else{
$category_id=$pw->cate_id;
$service_price = $pw->service_price;
$api_service=$pw->api_service; 
$api_currency =$pw->api_currency; 
$service_name = base64_encode(mb_convert_encoding(get("set/adds.json.name"),"UTF-8","UTF-8"));
$service_desc = base64_encode(get("set/adds.json.desc"));
$service_edit = "true";
mysqli_query($connect,"INSERT INTO services(`service_status`,`service_price`,`service_edit`,`category_id`,`service_api`,`api_service`,`api_currency`,`service_type`,`api_detail`,`service_name`,`service_desc`,`service_min`,`service_max`) VALUES ('on','$service_price','$service_edit','$category_id','$text','$api_service','$api_currency','$type','{\"name\":\"$name\",\"min\":\"$min\",\"max\":\"$max\",\"type\":\"$type\",\"cancel\":\"$cancel\",\"refill\":\"$refill\",\"dripfeed\":\"$dripfeed\"}','$service_name','$service_desc','$min','$max');");
sms($cid,"✅ <b>Yangi xizmat qo'shildi.</b>",json_encode(['inline_keyboard'=>[
[['text'=>"⏩ Orqaga",'callback_data'=>"tanla2=$category_id"]]]]));
}
}
}




if($text=="📲 Hisobni toldirish" or $text=="/pay" and joinchat($cid)==1){
$ops=get("set/payments.txt");
$s=explode("\n",$ops);
if(empty($setting['payme_id']) or $setting['payme_id']=="null" or $setting['payme_id']=="NULL"){
}else{
$paymee = "💳 PAYME";
}
$soni = substr_count($ops,"\n");
for($i=1;$i<=$soni;$i++){
$k[]=['text'=>$s[$i],'callback_data'=>"payBot=".$s[$i]];
}
$keyboard2=array_chunk($k,2);
$keyboard2[]=[['text'=>"💳 PAYME [AVTO]",'callback_data'=>"payme"]];
$keyboard2[]=[['text'=>"☎️ Admin yordamida",url=>"tg://user?id=$admin"]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
sms($cid,"<b>Botimizdan hisobingizni to'ldirib bot xizmatlaridan to'liq foydalanishingiz mumkin, botda hisobni to'ldirish qulay va 100% xafsiz sanaladi ✅

🆔 ID raqamingiz <code>$cid</code></b>",$kb);
}

if($text=="💵 Kursni o‘rnatish" and $cid==$admin){
$usd = get("set/usd");
$rub = get("set/rub");
$inr = get("set/inr");
$try = get("set/try");
sms($cid,"📑 <b>Kerakli valyutani tanlang:</b>",json_encode([
'inline_keyboard'=>[
[['text'=>"USD - $usd so'm",'callback_data'=>"course=usd"],['text'=>"RUB - $rub so'm",'callback_data'=>"course=rub"]],
[['text'=>"INR - $inr so'm",'callback_data'=>"course=inr"],['text'=>"TRY - $try so'm",'callback_data'=>"course=try"]],
]]));
}

if((stripos($data,"course=")!==false)){
$val=explode("=",$data)[1];
if(get("set/".$val."")){
$VAL=get("set/".$val);
}else{
$VAL=0;
}
del();
sms($chat_id,"
1 - ".strtoupper($val)." narxini kiriting:

♻️ Joriy narx: ".$VAL." so‘m",$aort);
put("user/$chat_id.step","course=$val");
}

if((mb_stripos($step,"course=")!==false and is_numeric($text))){
$val=explode("=",$step)[1];
put("set/".$val,"$text");
sms($cid,"
✅ 1 - ".strtoupper($val)." narxi $text so‘mga o‘zgardi",$panel);
unlink("user/$cid.step");
}

if($text == "🔗 Pul ishlash"  or $text=="/ref" and joinchat($cid)==1){
if($kunli > "0"){$za="🎁 Kunlik bonus";}
sms($cid,"<b>⬇️ Quyidagilardan birini tanlang:</b>",json_encode([
inline_keyboard=>[
[['text'=>"🔗 Takliflar",'callback_data'=>"referal"]],
[['text'=>"$za",'callback_data'=>"daily"]],
]]));
}

if($data == "pulishla" and joinchat($chat_id)==1){
if($kunli > "0"){$za="🎁 Kunlik bonus";}
edit($cid2,$mid2,"<b>⬇️ Quyidagilardan birini tanlang:</b>",json_encode([
inline_keyboard=>[
[['text'=>"🔗 Takliflar",'callback_data'=>"referal"]],
[['text'=>$za,'callback_data'=>"daily"]],
]]));
}

if($data == "referal" and joinchat($chat_id)==1) {
$result = mysqli_query($connect, "SELECT * FROM users WHERE id = $chat_id");
$row = mysqli_fetch_assoc($result);
$myid = $row['user_id'];
edit($cid2,$mid2,"
🔗 <b>Sizning referal havolangiz:</b>

<code>t.me/$bot?start=BY$myid</code>

➕ <b><i>Sizning har bir to'liq ro'yhatdan o'tgan taklifingiz uchun ".enc("decode",$setting['referal'])." so'm beriladi.</i></b>",json_encode([
inline_keyboard=>[
[['text'=>"🔄 Uashish",'url'=>"https://t.me/share/url/?url=https://t.me/$bot?start=BY$myid"]],
[['text'=>"🔥 TOP 10",'callback_data'=>"top10"]],
]]));
}


if($data == "konkurs" and joinchat($chat_id)==1){
edit($cid2,$mid2,referal(100),json_encode([
inline_keyboard=>[
[['text'=>"↔️ Ortga",'callback_data'=>"referal"]],
]]));
}

if($data == "top10" and joinchat($chat_id)==1){
edit($cid2,$mid2,referal(10),json_encode([
inline_keyboard=>[
[['text'=>"↔️ Ortga",'callback_data'=>"referal"]],
]]));
}

if($data == "daily" and joinchat($cid2)==1){
if(file_get_contents("kunlik/$cid2.txt")){
edit($cid2,$mid2,"<b>❌ Siz bugun bonus olgansiz!

🎁 Keyingi bonus 00:00 dan so'ng.</b>",json_encode([
inline_keyboard=>[
[['text'=>"⏪ Ortga",'callback_data'=>"pulishla"]],
]]));
}else{
edit($cid2,$mid2,"<b>🎁 Kunlik bonus berildi!\n\n✅ Bonus: $kunli so'm</b>",json_encode([
inline_keyboard=>[
[['text'=>"⏪ Ortga",'callback_data'=>"pulishla"]],
]]));
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $cid2"));
$miqdor = $rew['balance'] + $kunli;
mysqli_query($connect,"UPDATE users SET balance=$miqdor WHERE id = $cid2");
put("kunlik/$cid2.txt","true");
}
}

if($text=="⚖️ Foizni o‘rnatish" and $cid==$admin){
$m = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM percent WHERE id = 1"))['percent'];
$m ? $m : 0;
sms($cid,"
🛒 <b>Bot xizmatlari uchun foizni kiriting

✉️ Joriy foiz:</b> <pre>$m%</pre>",$aort);
put("user/$cid.step","updFoiz");
}

if($step=="updFoiz"){
if(is_numeric($text)){
mysqli_query($connect,"UPDATE percent SET percent = '$text' WHERE id = 1");
sms($cid,"✅ O‘zgartirish muvaffaqiyatli bajarildi.",$panel);
}
put("user/$cid.step","");
}

$saved = file_get_contents("user/us.id");

if($text == "🔎 Foydalanuvchini boshqarish"){
if($cid == $admin){
$keybot = json_encode([
'inline_keyboard'=>[
[['text'=>"🔹 iD raqam orqali",'callback_data'=>"orqali=id"]],
]]);
sms($cid,"<b>📋 Quyidagilardan birini tanlang:</b>",$keybot);
}
}

if(mb_stripos($data,"orqali=")!==false){
$by=explode("=",$data)[1];
if($by=="id"){$k="ID";}else{$k="tartib";}
del();
sms($cid2,"<b>Foydalanuvchi $k raqamini kiriting:</b>",$aort);
put("user/$cid2.step","by—$by");
exit();
}
if(mb_stripos($step,"by—")!==false){
$bz=explode("—",$step)[1];
if($cid == $admin){
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE $bz = $text"));
if($rew){
$idi = $rew['id'];
file_put_contents("user/us.id",$idi);
$pul = $rew['balance'];
$ban = $rew['status'];
if($ban == "active"){
	$bans = "🔔 Banlash";
}
if($ban == "deactive"){
	$bans = "🔕 Bandan olish";
}

bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"<b>🔎 Qidirilmoqda...</b>",
'parse_mode'=>'html',
]);
bot('editMessageText',[
        'chat_id'=>$cid,
        'message_id'=>$mid + 1,
        'text'=>"<b>Qidirilmoqda...</b>",
       'parse_mode'=>'html',
]);
bot('editMessageText',[
      'chat_id'=>$cid,
     'message_id'=>$mid + 1,
'text'=>"<b>Foydalanuvchi topildi ✔️

ID:</b> <a href='tg://user?id=$idi'>$text</a>
<b>Balans: $pul so‘m</b>",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
	'inline_keyboard'=>[
[['text'=>"$bans",'callback_data'=>"ban"]],
[['text'=>"➕ Pul qo'shish",'callback_data'=>"plus"],['text'=>"➖ Pul ayirish",'callback_data'=>"minus"]],
]
])
]);
unlink("user/$cid.step");
}else{
bot('SendMessage',[
	'chat_id'=>$cid,
	'text'=>"<b>Foydalanuvchi topilmadi ❌.</b>

Qayta urinib ko'ring:",
'parse_mode'=>'html',
]);
}
}

}

if($data == "plus"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"<a href='tg://user?id=$saved'>$saved</a> <b>ning hisobiga qancha pul qo'shmoqchisiz?</b>",
'parse_mode'=>"html",
	'reply_markup'=>$aort,
]);
file_put_contents("user/$chat_id.step",'plus');

}

if($step == "plus"){
if($cid == $admin){
if(is_numeric($text)=="true"){
bot('sendMessage',[
'chat_id'=>$saved,
'text'=>"<b>Adminlar tomonidan hisobingiz $text ➕ so‘m to'ldirildi</b>",
'parse_mode'=>"html",
'reply_markup'=>$menu,
]);
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"<b>Foydalanuvchi hisobiga $text ➕ so‘m qo'shildi!</b>",
'parse_mode'=>"html",
'reply_markup'=>$panel,
]);
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $saved"));
$miqdor = $text+$rew['balance'];
$p2 =$text+$rew['outing'];
mysqli_query($connect,"UPDATE users SET balance=$miqdor, outing=$p2 WHERE id =$saved");
unlink("user/$cid.step");
}else{
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"<b>🔢 Faqat raqamlardan foydalaning!</b>",
'parse_mode'=>'html',
'protect_content'=>true,
]);

}
}

}

if($data == "minus"){
bot('sendMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"<a href='tg://user?id=$saved'>$saved</a> <b>ning hisobidan qancha pul ➖ ayirmoqchisiz?</b>",
'parse_mode'=>"html",
	'reply_markup'=>$aort,
]);
file_put_contents("user/$chat_id.step",'minus');

}

if($step == "minus"){
if($cid == $admin){
if(is_numeric($text)=="true"){
bot('sendMessage',[
'chat_id'=>$saved,
'text'=>"<b>Adminlar tomonidan hisobingizdan $text ➖ so‘m olindi.</b>",
'parse_mode'=>"html",
'reply_markup'=>$menu,
]);
bot('sendMessage',[
'chat_id'=>$cid,
'text'=>"<b>Foydalanuvchi hisobidan $text ➖  so‘m olindi !</b>",
'parse_mode'=>"html",
'reply_markup'=>$panel,
]);
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $saved"));
$miqdor =$rew['balance'] - $text;
$p2 =$rew['outing'] - $text;
mysqli_query($connect,"UPDATE users SET balance=$miqdor WHERE id =$saved");
unlink("user/$cid.step");
}else{
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"<b>🔢 Faqat raqamlardan foydalaning!</b>",
'parse_mode'=>'html',
'protect_content'=>true,
]);
}
}

}

if($data=="ban"){
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $saved"));
if($admin!=$saved){
if($rew['status'] == "deactive"){
mysqli_query($connect,"UPDATE users SET status='active' WHERE id =$saved");
bot('sendMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"<b>🔔 Foydalanuvchi ($saved) bandan olindi!</b>",
'parse_mode'=>"html",
	'reply_markup'=>$panel,
]);
}else{
mysqli_query($connect,"UPDATE users SET status='deactive' WHERE id =$saved");
bot('sendMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"<b>🔕 Foydalanuvchi ($saved) banlandi!</b>",
'parse_mode'=>"html",
	'reply_markup'=>$panel,
]);
}
}else{
bot('answerCallbackQuery',[
'callback_query_id'=>$qid,
'text'=>"🎛️ Bloklash mumkin emas!",
'show_alert'=>true,
]);
}

}


if($data=="result" and joinchat($chat_id)==1){
if(joinchat($chat_id)==1){
	$usid = get("user/$chat_id.id");
$pul = mysqli_fetch_assoc(mysqli_query($connect,"SELECT*FROM users WHERE id=$usid"))['balance'];
$a = $pul+enc("decode",$setting['referal']);
mysqli_query($connect,"UPDATE users SET balance = $a WHERE id = $usid");
$text = "
✅ <b>Siz taklif qilgan <a href='tg://user?id=$chat_id'>foydalanuvchi</a> kanallarga obuna bo‘ldi.</b>

➕ <b>Hisobingizga ".enc("decode",$setting['referal'])." so‘m qo'shildi✔️ !</b>";
sms($usid,"$text",$m);
$p = get("user/$usid.users");
put("user/$usid.users",$p+1);
unlink("user/$chat_id.id");
}
del();
sms($chat_id,"<b>✅ Obunangiz tasdiqlandi. Bosh menyudasiz!</b>",$m);
unlink("user/$cid2.step");
unlink("user/$cid2.ur");
unlink("user/$cid2.params");
unlink("user/$cid2.qu");
unlink("user/$cid2.si");
}



if($text=="🛒 Buyurtmalarim" or $text=="/buyurtmam" and joinchat($cid)==1) {
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM myorder WHERE user_id = $cid"));
$all_orders = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM `myorder` WHERE `user_id` = $cid"));
$canceled_orders = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `myorder` WHERE `user_id` = '$cid' AND status = 'Canceled'"));
$done_orders = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `myorder` WHERE `user_id` = '$cid' AND status = 'Completed'"));
$partial_orders = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `myorder` WHERE `user_id` = '$cid' AND status = 'Partial'"));
$pending_orders = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `myorder` WHERE `user_id` = '$cid' AND status = 'Pending'"));
$inprog_orders = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `myorder` WHERE `user_id` = '$cid' AND status = 'In Progress'"));
if(!$rew){
sms($cid,"<b>🤷‍♂️ Sizga tegishli buyurtma ma'lumotlari topilmadi

🌐 <u>Xizmatlar</u></b> — <i>bo'limi orqali buyurtma berishingiz mumkin.</i>",null);
}else{
$rew = mysqli_query($connect,"SELECT * FROM myorder WHERE user_id = $cid");
while($my=mysqli_fetch_assoc($rew)){
$bid = $my['order_id'];
$k[]=['text'=>"$bid",'callback_data'=>"checkorders=$bid"];
}
$keyboard2=array_chunk($k,6);
$keyboard2[]=[['text'=>"🔎 Qidirish",'callback_data'=>"myorders"]];
$keyboard=json_encode([
'inline_keyboard'=>
$keyboard2,
]);
sms($cid,"🛒 <b>Sizning buyurtmalaringiz menyusi:

🌐 Barcha buyurtmalaringiz:</b> $all_orders ta",$keyboard);
}
}

if($data=="myorders" and joinchat($cid2)==1) {
$resi = mysqli_query($connect, "SELECT * FROM orders");
$stati = mysqli_num_rows($resi);
del();
sms($cid2,"🆔 O'zingizga kerak buyurtma ID raqamini yuboring: ",$ort);
put("user/$cid2.step","myorder");
exit;
}

if($step=="myorder" and is_numeric($text)==1){
$orde = mysqli_query($connect, "SELECT * FROM myorder WHERE order_id = '$text'");
$order = mysqli_fetch_assoc($orde);
if(!$order){
sms($cid,"❌ Buyurtma topilmadi.",$m);
}else{
if($order['user_id'] == $cid){
$row = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM orders WHERE order_id = $text"));
$pro = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM providers WHERE id = ".$row['provider'].""));
$j=json_decode(get($pro['api_url']."?key=".$pro['api_key']."&action=status&order=".$row['api_order'].""),1);
$start_count = "".$j['start_count']."";
$qold = "".$j['remains']."";

if($order['status'] == "Completed"){
$status = "✅ Bajarilgan.";
}
if($order['status'] == "Pending" or $order['status'] == "In progress" or $order['status'] == "Partial"){
$status = "🔄 Bajarilmoqda...";
}
if($order['status'] == "Processing"){
$status = "🔄 Qayta ishlanmoqda.";
}
if($order['status'] == "Canceled"){
$status = "⛔️ Bekor qilingan.";
}

{
if($order['status'] == "Completed" or $order['status'] == "Canceled"){
}else{
{
if($j['status'] == null){
}else{
$qoldi = "\n<b>🔢 Qolgan miqdor:</b> $qold ta";
}
}

{
if($j['start_count'] == null){
}else{
$boshlanish = "\n<b>⏩ Boshlash:</b> $start_count ta";
}
}
}
}

sms($cid,"
<b>🆔 ID:</b> <code>$text</code>
<b>♻️ Holat:</b> $status
<b>⏰ Sana:</b> ".$order['order_create']."
<b>💰 Narxi:</b> ".$order['retail']." so'm $boshlanish $qoldi
",$m);
}else{
sms($cid,"⚠️ Bu buyurtma sizga tegishli emas.",$m);
}
unlink("user/$cid.step");
}
exit;
}


if($data == "my-orders"){
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM myorder WHERE user_id = $cid2"));
$all_orders = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM `myorder` WHERE `user_id` = $cid2"));
$canceled_orders = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `myorder` WHERE `user_id` = '$cid2' AND status = 'Canceled'"));
$done_orders = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `myorder` WHERE `user_id` = '$cid2' AND status = 'Completed'"));
$partial_orders = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `myorder` WHERE `user_id` = '$cid2' AND status = 'Partial'"));
$pending_orders = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `myorder` WHERE `user_id` = '$cid2' AND status = 'Pending'"));
$inprog_orders = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `myorder` WHERE `user_id` = '$cid2' AND status = 'In Progress'"));
if(!$rew){
edit($cid2,$mid2,"<b>🤷‍♂️ Sizga tegishli buyurtma ma'lumotlari topilmadi

🌐 <u>Xizmatlar</u></b> — <i>bo'limi orqali buyurtma berishingiz mumkin.</i>",null);
}else{
$rew = mysqli_query($connect,"SELECT * FROM myorder WHERE user_id = $cid2");
while($my=mysqli_fetch_assoc($rew)){
$bid = $my['order_id'];
$k[]=['text'=>"$bid",'callback_data'=>"checkorders=$bid"];
}
$keyboard2=array_chunk($k,6);
$keyboard=json_encode([
'inline_keyboard'=>
$keyboard2,
]);
edit($chat_id,$message_id,"🛒 <b>Sizning buyurtmalaringiz menyusi:

🌐 Barcha buyurtmalaringiz:</b> $all_orders ta",$keyboard);
}
}

if($data=="searchorder"){
del();
sms($cid2,"<b>🔎 Buyurtma ID raqamini yuboring:</b>",$ort);
put("user/$cid2.step","searchorder");
}

if($step=="searchorder"){
unlink("user/$cid.step");
if(is_numeric($text)==true){
$order=mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `myorder` WHERE `order_id` = '$text'"));
$response=$order['status'];
$usid=$order['user_id'];
if($response=="Completed") {
  $status="✔️ bajarilgan";
   }
   if($response=="In progress") {
   $status="🔄 bajarilmoqda";
   }
   if($response=="Partial"){
   $status="♻️ qayta ishlanmoqda";
   }
   if($response=="Pending"){
  $status="🔄 bajarilmoqda";
  }
  if($response=="Processing"){
  $status="🔄 bajarilmoqda";
  }
  if($response=="Canceled"){
  $status="❌ bekor qilingan";
  }
if($usid==$cid){
sms($cid,"<b>🛒 Buyurtma ID: <pre>$text</pre>

🌐 Xolati:</b> <i>$status</i>",json_encode([
'inline_keyboard'=>[
[['text'=>"🔎 Batafsil",'callback_data'=>"checkorders=$text"]]
]]));
}else{
sms($cid,"<b>🤖 Kechirasiz, ushbu buyurtma sizga tegishli emas!</b>",$m);
}
}
}

if((stripos($data,"checkorders=")!==false)){
$id = str_replace("checkorders=", "", $data);
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM orders WHERE order_id = $id"));
$ori =$rew['api_order'];
$prov =$rew['provider'];
$ap = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM providers WHERE id = $prov"));
$ourl=$ap['api_url'];
$okey=$ap['api_key'];
$s=json_decode(get($ourl."?key=".$okey."&action=status&order=$ori"),1);
$err=$s['error'];
$response=$rew['status'];
if($response=="Completed") {
   $status="✔️ bajarilgan";
   }
   if($response=="In progress") {
   $status="🔄 bajarilmoqda";
   }
   if($response=="Partial"){
   $status="♻️ qayta ishlanmoqda";
   }
   if($response=="Pending"){
  $status="🔄 bajarilmoqda";
  }
  if($response=="Processing"){
  $status="🔄 bajarilmoqda";
  }
  if($response=="Canceled"){
  $status="❌ bekor qilingan";
  }
bot('deleteMessage',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
]);
$price = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM myorder WHERE user_id = $cid2 AND order_id = $id"))['retail'];
$service_id = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM myorder WHERE user_id = $cid2 AND order_id = $id"))['service'];
$tim = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM myorder WHERE user_id = $cid2 AND order_id = $id"))['order_create'];
$tims = explode(" ",$tim);
$date_order = $tims[0];
$time = $tims[1];
$serv_name = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM services WHERE service_id = $service_id"))['service_name'];
bot('sendmessage',[
'chat_id'=>$chat_id,
'text'=>"<b>🛒 Buyurtmangiz haqida ma’lumot:

🆔 Buyurtma ID raqami: <pre>$id</pre>
💸 Buyurtma narxi:</b> $price so'm
<b>💌 Xizmat ID si: <pre>$service_id</pre>
📆 Buyurtma sanasi:</b> $date_order<b>
⏱️ Buyurtma berilgan vaqt:</b> $time<b>
🌐 Xizmat nomi: </b>". base64_decode($serv_name) ."<b>

🔎 Buyurtmangiz xolati: </b>$status\n\n",
'parse_mode'=>html,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"♻️ Yangilash",'callback_data'=>"checkorders=$id"],['text'=>"▶️ Orqaga",'callback_data'=>"main"]],
]
]),
]);
unlink("user/$chat_id.step");
}

if($text=="/start" and joinchat($cid)==1){
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $cid"));
$start =str_replace(["{name}","{balance}","{time}"],["$name","".$rew['balance']."","$time"],enc("decode",$setting['start']));
sms($cid,"<b>$start</b>",$m);
}

if($text=="/valute" and $cid==$admin){
$json3=json_decode(file_get_contents("https://cbu.uz/uz/arkhiv-kursov-valyut/json/"),1);
foreach($json3 as $json4){
if($json4['Ccy']=="USD"){
$usd=$json4['Rate'];
break;
}
}
foreach($json3 as $json4){
if($json4['Ccy']=="RUB"){
$rub=$json4['Rate'];
break;
}
}
foreach($json3 as $json4){
if($json4['Ccy']=="INR"){
$inr=$json4['Rate'];
break;
}
}
foreach($json3 as $json4){
if($json4['Ccy']=="TRY"){
$try=$json4['Rate'];
break;
}
}

sms($cid,"<b> 
1 $(USD) - $usd UZS
1 ₽(RUB) - $rub UZS
1 ₹(INR) - $inr UZS
1 ₺(TRY) - $try UZS
</b>",$panel);

}

/*
if($text == "/otkazchi") {
	sms($cid,"Boshlandi",null);
$us = get("users.txt");
$a = explode("\n",$us);
$co = substr_count($us,"\n");
for($i = 1;$i<=$co;$i++){
adduser($a[$i]
}
sms($cid,"Tugadi",null);
}*/

if($text=="💳 Hisobim" or $text=="/hisobim" and joinchat($cid)==1) {
$result = mysqli_query($connect,"SELECT * FROM kabinet WHERE user_id = $cid");
$rew = mysqli_fetch_assoc($result);
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $cid"));
$orders = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `myorder` WHERE `user_id` = '$cid'"));
$pul = mysqli_fetch_assoc(mysqli_query($connect,"SELECT*FROM kabinet WHERE user_id = $cid2"))['pul'];
$kabinet =str_replace(["{outing}","{balance}","{id}","{orders}"],["".$rew['outing']."","".$rew['balance']."",$rew['user_id'], $orders],enc("decode",$setting['kabinet']));
sms($cid,"<b>🆔 ID raqamingiz:</b> <code>$cid</code>

<b>💵 Balansingiz:</b> ".$rew['balance']." so'm
<b>🌐 Buyurtmalaringiz:</b> $orders ta

<b>💳 Kiritgan pullaringiz:</b> ".$rew['outing']." so'm",json_encode([
inline_keyboard=>[
[['text'=>"💳 Hisobni Toldirish",'callback_data'=>"menu=tolov"]],
]

]));


}

if((stripos($data,"menu=")!==false and joinchat($chat_id)==1)){
$res=explode("=",$data)[1];
if(empty($setting['payme_id']) or $setting['payme_id']=="null" or $setting['payme_id']=="NULL" or $setting['payme_id']==""){
}else{
$paymee = "💳 PAYME";
}
if($res=="tolov"){
$ops=get("set/payments.txt");
$s=explode("\n",$ops);
$soni = substr_count($ops,"\n");
for($i=1;$i<=$soni;$i++){
$k[]=['text'=>$s[$i],'callback_data'=>"payBot=".$s[$i]];
}
$keyboard2=array_chunk($k,2);
$keyboard2[]=[['text'=>"💳 PAYME [AVTO]",'callback_data'=>"payme"]];
$keyboard2[]=[['text'=>"☎️ Admin yordamida",url=>"tg://user?id=$admin"]];
$keyboard2[]=[['text'=>"↔️ Orqaga",'callback_data'=>"menu=back"]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
edit($chat_id,$message_id,"📑 <b>Kerakli tolov tizimini tanlang:</b>",$kb);
}elseif($res=="back"){
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $chat_id"));
del();
$orders = mysqli_num_rows(mysqli_query($connect, "SELECT * FROM `myorder` WHERE `user_id` = '$cid2'"));
$pul = mysqli_fetch_assoc(mysqli_query($connect,"SELECT*FROM kabinet WHERE user_id = $cid2"))['pul'];
$kabinet =str_replace(["{outing}","{balance}","{id}","{orders}"],["".$rew['outing']."","".$rew['balance']."","". $rew['user_id'] ."", $orders],enc("decode",$setting['kabinet']));
sms($chat_id,"<b>🆔 ID raqamingiz:</b> <code>$cid</code>

<b>🔢 Tartib raqamingiz:</b> <pre>".$rew['user_id']."</pre>
<b>💵 Balansingiz:</b> ".$rew['balance']." so'm
<b>🌐 Buyurtmalaringiz:</b> $orders ta

<b>💳 Kiritgan pullaringiz:</b> ".$rew['outing']." so'm",json_encode([
inline_keyboard=>[
[['text'=>"📊 Hisobni Toldirish",'callback_data'=>"menu=tolov"]],
]]));

}elseif($res=="PAYME") {
if(empty($setting['payme_id']) or $setting['payme_id']=="null" or $setting['payme_id']=="NULL"){
bot('answerCallbackQuery',[
'callback_query_id'=>$cqid,
'text'=>"⚠️ Ushbu tolov tizimidagi kerakli malumotlar yetishmaydi",
'show_alert'=>true,
]);
}else{
del();
sms($chat_id,"
💵 To‘lov miqdorini kiriting:

⬇️ Minimal 1000 so‘m
⬆️ Maksimal 12000000 so‘m",$ort);
put("user/$chat_id.step","payme");
}
}
}

if((stripos($data,"payBot=")!==false)){
$h=explode("=", $data)[1];
$card=get("set/pay/$h/wallet.txt");
$info=get("set/pay/$h/addition.txt");
edit($cid2,$mid2,"
🧾 <b>To'lov tizimi: $h

💳 Karta:</b> <code>$card</code>

📑 Izoh: <pre>$cid2</pre>

<b><blockquote>$info</blockquote></b>
",json_encode([
'inline_keyboard'=>[
[['text'=>"✅ To‘lov qildim",'callback_data'=>"payed=$h"]],
[['text'=>"↔️ Orqaga",'callback_data'=>"menu=tolov"]],
]]));
}

if(mb_stripos($data,"payed=")!==false){
$h = explode("=",$data)[1];
sms($chat_id,"🧾 <b>To’lov miqdorini kiriting:

🔹 Minimal: 1000 so'm</b>",$ort);
put("user/$chat_id.step","tolovqldm=$h");
}


if(mb_stripos($step,"tolovqldm=")!==false){
$h = explode("=",$step)[1];
if(is_numeric($text)==true){
if(($text >= 1000) and ("100000000000000" >= $text)){
sms($cid,"
📑 <b>To’lov uchun chek rasmini yuboring:</b>",$ort);
file_put_contents("user/$cid.step","payed=$h=$text");
}else{
sms($cid,"
⛔ <b>Qaytadan kiriting:

🔹 Minimal: 1000 so'm</b>",$ort);
}
}else{
sms($cid,"<b>
⛔ Faqat raqamlardan foydalaning:

🔹 Minimal: 1000 so'm",$ort);
}
}

if(mb_stripos($step,"payed=")!==false){
$name = bot('getchat',['chat_id'=>$cid])->result->first_name;
unlink("user/$cid.step");
$ex = explode("=",$step);
$h = $ex[1];
$miqdor = $ex[2];
if($message->photo){
sms($cid,"<b>✅ To’lovingiz adminga yuborildi!</b>",$m);
$ax = bot('CopyMessage',[
'chat_id'=>$paychannel,
'message_id'=>$mid,
'from_chat_id'=>$cid,
])->result->message_id;
bot('sendMessage',[
'chat_id'=>$paychannel,
'reply_to_message_id'=>$ax,
'parse_mode'=>html,
'text'=>"<b>
📑 #chek | To'lov uchun chek

💳 To'lov tizimi: $h
🔢 To'lov miqdori: $miqdor so'm</b>",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Tasdiqlash",'callback_data'=>"pdone=$cid=$h=$miqdor"],['text'=>"⛔ Bekor qilish",'callback_data'=>"notpay=$cid=$miqdor"]],
[['text'=>"$name",'url'=>"tg://user?id=$cid"]],
]
]),
]);
}else{
sms($cid,"<b>⛔ Faqat rasm (screenshot) qabul qilinadi!</b>",$m);
}
}

$uid = $message->from->id;
if(mb_stripos($data,"notpay=")!==false and $Tc != "private"){
if($callfrid == $admin){
$ex = explode("=",$data);
$use = $ex[1];
$miqdor = $ex[2];
bot('editMessageText',[
'chat_id'=>$chat_id,
'parse_mode'=>html,
'message_id'=>$message_id,
'text'=>"⛔ <b>Foydalanuvchi ($use) hisobini $miqdor so'mga to'ldirish uchun so'rovi bekor qilindi! || #canceled</b>",
]);
sms($use,"<b>⛔ Hisobingizni $miqdor so'mga to'ldirish uchun so'rovingiz bekor qilindi!</b>", null);
}else{
bot('answerCallbackQuery',[
'callback_query_id'=>$cqid,
'text'=>"⚠️ Siz administrator emassiz!",
'show_alert'=>false,
]);
}
}

if(mb_stripos($data,"pdone=")!==false and $Tc != "private"){
if($callfrid == $admin){
$ex = explode("=",$data);
$id = $ex[1];
$tizim = $ex[2];
$miqdor = $ex[3];
sms($id,"<b>✅ So'rovingiz tasdiqlandi va hisobingizga $miqdor so'm qo'shildi !</b>

<i>Ishonchingiz uchun Rahmat</i> 🤗",null);
bot('editMessageText',[
'chat_id'=>$chat_id,
'parse_mode'=>html,
'message_id'=>$message_id,
'text'=>"💵 <b>Foydalanuvchi  (<code>$id</code>) hisobi $miqdor so'mga to'ldirildi. || #done</b>",
]);
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $id"));
$put = $miqdor+$rew['balance'];
$p2 =$miqdor+$rew['outing'];
mysqli_query($connect,"UPDATE users SET balance=$put, outing=$p2 WHERE id = $id");
}else{
bot('answerCallbackQuery',[
'callback_query_id'=>$cqid,
'text'=>"⚠️ Siz administrator emassiz!",
'show_alert'=>false,
]);
}
}

if($text=="📢 Kanallar" and $cid==$admin){
sms($cid,"<b>$text bo'limi:</b>",json_encode([
'inline_keyboard'=>[
[['text'=>"➕ Qo‘shish",'callback_data'=>"kanal=add"]],
[['text'=>"*️⃣ Ro‘yxat",'callback_data'=>"kanal=list"],['text'=>"🗑️ O'chirish",'callback_data'=>"kanal=dl"]],
]]));

}

if((stripos($data,"kanal=")!==false)){
$rp=explode("=",$data)[1];
if($rp=="list"){
$ops=get("set/channel");
if(empty($ops)){
sms($chat_id,"🤷‍♂️ Xechqanday kanal topilmadi.",null);

}else{
$s=explode("\n",$ops);
$soni = substr_count($ops,"\n");
for($i=0;$i<=count($s)-1;$i++){
$k[]=['text'=>$s[$i],'url'=>"t.me/".str_replace("@","",$s[$i])];
}
$keyboard2=array_chunk($k,2);
$keyboard=json_encode([
'inline_keyboard'=>$keyboard2,
]);
sms($chat_id,"🌐 <b>Barcha kanallar:</b>",$keyboard);

}
}elseif($rp=="dl"){
$ops=get("set/channel");
if(empty($ops)){
sms($chat_id,"🤷‍♂️ Xechqanday kanal topilmadi.",null);

}else{
$s=explode("\n",$ops);
$soni = substr_count($ops,"\n");
for($i=0;$i<=count($s)-1;$i++){
$k[]=['text'=>$s[$i],'callback_data'=>"kanal=del".$s[$i]];
}
$keyboard2=array_chunk($k,2);
$keyboard=json_encode([
'inline_keyboard'=>$keyboard2,
]);
sms($chat_id,"🗑️ <b>O‘chiriladigan kanalni tanlang</b>:",$keyboard);
}
}elseif(mb_stripos($rp,"del@")!==false){
$d=explode("@",$rp)[1];
$ops=get("set/channel");
$soni = explode("\n",$ops);
if(count($soni)==1){
unlink("set/channel");
}else{
$ss="@".$d;
$ops=str_replace("\n".$ss."","",$ops);
put("set/channel",$ops);
}
del();
sms($chat_id,"✅ O‘chirildi",null);
}elseif($rp=="add"){
del();
sms($chat_id,"
♻️ Kanal userini kiriting

Namuna: @$bot",$aort);
put("user/$chat_id.step","kanal_add");

}
}

if($step=="kanal_add"){
if(mb_stripos($text,"@")!==false){
$kanal=get("set/channel");
sms($cid,"✅ Saqlandi!",$panel);
if($kanal==null){
file_put_contents("set/channel",$text);
}else{
file_put_contents("set/channel","$kanal\n$text");
}
unlink("user/$chat_id.step");
}
}

if($data == "auto-pm"){
$keyBot = json_encode([
'inline_keyboard'=>[
[['text'=>"🌐 Telegram post",'callback_data'=>"autopm"]],
[['text'=>"⏪ Orqaga",'callback_data'=>"absd"]],
]
]);
edit($cid2,$mid2,"<b>➡️ Quyidagilardan birini tanlang:</b>",$keyBot);
}

if($data=="autopm"){
bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"
🚫 Ushbu bo'lim aktiv emas!

⏰ Tez kunda ishga tushadi...",
		'show_alert'=>true,
		]);
}



if($text=="🌐 Xizmatlar" or $text=="/xizmat" and joinchat($cid)==1){
if($cid!=$admin){$me=$menu;}else{
$qoshish = "➕ Kategoriya qo'shish";
$me=json_encode(['inline_keyboard'=>[
[['text'=>"$qoshish",'callback_data'=>"newFol"]],
]]);}
$a = mysqli_query($connect,"SELECT * FROM `categorys`");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$catID = $s['category_id'];
$cat = mysqli_query($connect, "SELECT * FROM `cates` WHERE `category_id` = '$catID'");
// $count = mysqli_num_rows($cat);
$k[]=['text'=>"".enc("decode",$s['category_name']) ." ",'callback_data'=>"tanla1=".$s['category_id']];
}
if(!$c){
sms($cid,"<b>🤷 Kategoriyalar topilmadi!</b>",$me);
}else{
$keyboard2=array_chunk($k,2);
$keyboard2[]=[['text'=>"$qoshish",'callback_data'=>"newFol"]];
$keyboard2[]=[['text'=>"📝 Xizmatlar Ro'yxati",'url'=>"https://".$_SERVER['HTTP_HOST']."/services"]];
$keyboard2[]=[['text'=>"🔎 Qidirish",'callback_data'=>"searchSrv"]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
sms($cid,"<b>🌟 Bizning Xizmatlarni tanlaganingizdan mamnunmiz!

👇 Quyidagi tarmoqlar birini tanlang.</b>",$kb);
exit; 
}
}

if($data=="searchSrv" and joinchat($chat_id)==1){
bot('deleteMessage',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
]);
sms($cid2,"🔎<i> Xizmat id raqamini kiriting:</i>", $ort);
file_put_contents("user/$cid2.step","srch");
}

if($step=="srch"){
$delmid = sms($cid,"<b>⏱️ Kuting...</b>", null)->result->message_id;
$id = $text;
$a = mysqli_query($connect,"SELECT * FROM services WHERE service_id= '$id'");
while($s = mysqli_fetch_assoc($a)){
$nam = base64_decode($s['service_name']);
$sid = $s['service_id'];
$narx = $s['service_price'];
$curr = $s['api_currency'];
$cancel = explode(":",$s['api_detail'])[5];
$cancel = str_replace(['"',',','refill'],['','',''], $cancel);
if($cancel=="false"){
$cancel = "kuzatilmaydi";
}else{
$cancel = "mavjud";
}
$dripfeed = explode(":",$s['api_detail'])[7];
$dripfeed = str_replace("}","",$dripfeed);
$dripfeed = str_replace('"','',$dripfeed);
if($dripfeed == "true"){
$dripfeed = "ha";
}else{
$dripfeed = "yo‘q";
}
$ab = $s['service_desc'] ? $ab=$s['service_desc'] : null;
$api = $s['api_service'];
$type=$s['service_type'];
$spi = $s['service_api'];
$min=$s["service_min"];
$max=$s["service_max"];
}
$ap = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM providers WHERE id = $api"));
$surl=$ap['api_url'];
$skey=$ap['api_key'];
$j=json_decode(get($surl."?key=".$skey."&action=services"), true);
foreach($j as $el){
if($el['service']==$spi){
$amin=$el["min"];
$amax=$el["max"];
break;
}
}
if($curr=="USD"){
$fr=get("set/usd");
}elseif($curr=="RUB"){
$fr=get("set/rub");
}elseif($curr=="INR"){
$fr=get("set/inr");
}elseif($curr=="TRY"){
$fr=get("set/try");
}
$ab ? $abs = "".base64_decode($ab)."": null;

if($type=="Default" or $type=="default"){
if(empty($abs)){
$ab = "\n🔽 <b><u>Minimal buyurtma:</u></b> $min ta
🔼 <b><u>Maksimal buyurtma:</u></b> $max ta";
}else{
$ab = " 📑 <b>Batafsil ma'lumot</b>
<b>$abs</b>

🔽 <b><u>Minimal buyurtma:</u></b> $min ta
🔼 <b><u>Maksimal buyurtma:</u></b> $max ta";
}
}elseif($type=="Package"){
$ab = "$abs";
}
if(empty($min) or empty($max) or empty($a)){
sleep(1);
sms($cid,"<b>🤷 Ushbu id orqali xizmat topilmadi!</b>",$m);
bot('deleteMessage',[
'chat_id'=>$cid,
'message_id'=>$delmid,
]);
unlink("user/$cid.step");
}else{
edit($cid,$delmid,"
🎯 <b><u>Xizmat nomi:</u></b> $nam

🔑 <b><u>Xizmat IDsi:</u></b> <code>$sid</code>
💵 <b><u>Narxi (1000 ta)</u></b> - $narx so‘m
$ab
",json_encode([
inline_keyboard=>[
[['text'=>"✅ Buyurtma berish",'callback_data'=>"order=$spi=$min=$max=".$narx."=$type=".$api."=$sid"]],
[['text'=>"🚫 Yopish",'callback_data'=>"main"]],
]]));
unlink("user/$cid.step");
exit; 
}
}

if($data=="absd" and joinchat($chat_id)==1){
$a = mysqli_query($connect,"SELECT * FROM `categorys`");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$catID = $s['category_id'];
$cat = mysqli_query($connect, "SELECT * FROM `cates` WHERE `category_id` = '$catID'");
$count = mysqli_num_rows($cat);
$k[]=['text'=>"".enc("decode",$s['category_name']) ." ",'callback_data'=>"tanla1=".$s['category_id']];
}
if(!$c){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"⚠️ Tarmoqlar topilmadi!",
		'show_alert'=>true,
		]);
	}else{
$keyboard2=array_chunk($k,2);
$keyboard2[]=[['text'=>"📝 Xizmatlar Ro'yxati",'url'=>"https://".$_SERVER['HTTP_HOST']."/services"]];
$keyboard2[]=[['text'=>"🔎 Qidirish",'callback_data'=>"searchSrv"]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
edit($chat_id,$mid2,"<b>🌟 Bizning Xizmatlarni tanlaganingizdan mamnunmiz!

👇 Quyidagi tarmoqlar birini tanlang.</b>",$kb);
bot('AnswerCallbackQuery',[
'callback_query_id'=>$qid,
'text'=>"✅ Quyidagi tarmoqlardan birini tanlang:",
'show_alert'=>false,
]);
exit; 
}
}


if((mb_stripos($data,"tanla1=")!==false and joinchat($chat_id)==1)){
$n=explode("=",$data)[1];
if($chat_id==$admin){
$add="➕";$del="🗑️";$edit="📝";
$qoshish="➕ Ichki bo'lim qo'shish";
$adm=json_encode(['inline_keyboard'=>[
[['text'=>"$add",'callback_data'=>"adFol=$n"],['text'=>"$edit",'callback_data'=>"editFoldm-$n"],['text'=>"$del",'callback_data'=>"edit"]],
[['text'=>"⏪ Orqaga",'callback_data'=>"absd"]]
]]);
}
$nomu = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `categorys` WHERE `category_id` = '$n'"))['category_name'];
$nomz = enc("decode",$nomu);
$adds=json_decode(get("set/sub.json"),1);
$adds['cate_id']=$n;
put("set/sub.json",json_encode($adds));
$new_arr = [];
$k = [];
$a = mysqli_query($connect,"SELECT * FROM cates WHERE category_id = $n");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
if(!in_array(enc("decode",$s['name']), $new_arr)){
$catname = enc("decode",$s['name']);
$new_arr[] = enc("decode",$s['name']);
$catID = $s['cate_id'];
$cat = mysqli_query($connect,"SELECT * FROM services WHERE category_id = '$catID'");
$count = mysqli_num_rows($cat);
$k[]=['text'=>"$catname ",'callback_data'=>"tanla2=".$s['cate_id']."=$n"];
}
}
$keyboard2=array_chunk($k,1);
$keyboard2[]=[['text'=>"$add",'callback_data'=>"adFol=$n"],['text'=>"$edit",'callback_data'=>"editFolss-$n"],['text'=>"$del",'callback_data'=>"delFolx=$n"]];
$keyboard2[]=[['text'=>"⏪ Orqaga",'callback_data'=>"absd"]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	if($chat_id!=$admin){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"🚫 Ichki bo'limlar mavjud emas!",
		'show_alert'=>true,
		]);
	}else{
	edit($chat_id,$message_id,"<b>🚫 Ichki bo'limlar mavjud emas!</b>",$adm);
	}
	}else{
edit($chat_id,$message_id,"<b>$nomz bo‘limiga xush kelibsiz!
📋 Kerakli xizmat turini tanlang:</b>",$kb);
bot('AnswerCallbackQuery',[
'callback_query_id'=>$qid,
'text'=>"✅ Kerakli xizmat turini tanlang:",
'show_alert'=>false,
]);
exit; 
}
}

if(mb_stripos($data,"tanla2=")!==false and joinchat($chat_id)==1){
$n=explode("=",$data)[1];
$m=explode("=",$data)[2];
if($cid2==$admin){
$exx="⬇️ Xizmatlarni yuklab olish";
$add="➕";$del="🗑️";$edit="📝";}
$as=0;

$a = mysqli_query($connect,"SELECT * FROM services WHERE category_id = '$n' AND service_status = 'on'");
$c = mysqli_num_rows($a);
while($s = mysqli_fetch_assoc($a)){
$as++;

$narx = $s['service_price'];
$k[]=['text'=>"". str_replace(["ᴛɢ ", "ɪɢ ", "ʏᴛ ", "ғʙ ","IG ", "TG ", " (prasmotir)", "YT "], [null, null, null, null, null, null, null, null], base64_decode($s['service_name']))." - $narx so‘m",'callback_data'=>"ordered=".$s['service_id']."=$n=$m"];
}
$keyboard2=array_chunk($k,1);
$adds=json_decode(get("set/sub.json"),1);
$keyboard2[]=[['text'=>"$exx",'callback_data'=>"uplads-$n"]];
$keyboard2[]=[['text'=>"$add",'callback_data'=>"adds-$n"],['text'=>"$del",'callback_data'=>"ichkidel=$n"],['text'=>"$edit",'callback_data'=>"editFoldm-$n"]];
$keyboard2[]=[['text'=>"⏪ Orqaga",'callback_data'=>"tanla1=".$adds['cate_id']]];
$kb=json_encode([
'inline_keyboard'=>$keyboard2,
]);
if(!$c){
	if($cid2!=$admin){
	bot('answerCallbackQuery',[
		'callback_query_id'=>$qid,
		'text'=>"🚫 Xizmatlar mavjud emas!",
		'show_alert'=>true,
		]);
	}else{
	edit($chat_id,$message_id,"
🚫 <b>Ushbu bo'limda xizmatlar mavjud emas!</b>",json_encode(['inline_keyboard'=>[
[['text'=>$add,'callback_data'=>"adds-$n"],['text'=>$del,'callback_data'=>"ichkidel=$n"],['text'=>$edit,'callback_data'=>"editFoldm-$n"]],
[['text'=>"$exx",'callback_data'=>"uplads-$n"]],
[['text'=>"⏪ Orqaga",'callback_data'=>"tanla1=".$adds['cate_id']]]]]));
	}
	}else{
edit($chat_id,$message_id,"
📋 <b>Quyidagi ta'riflardan birini tanlang:</b>",$kb);
bot('AnswerCallbackQuery',[
'callback_query_id'=>$qid,
'text'=>"✅ Kerakli xizmatni tanlang:",
'show_alert'=>false,
]);
exit; 
}
}







if((stripos($data,"ordered=")!==false)){
bot('AnswerCallbackQuery',[
'callback_query_id'=>$qid,
'text'=>"✅ Xizmat tanlandi. Buyurtma berishingiz mumkin!",
'show_alert'=>false,
]);
$n=explode("=",$data)[1];
$n2=explode("=",$data)[2];
$n3=explode("=",$data)[3];
$a = mysqli_query($connect,"SELECT * FROM services WHERE service_id= '$n'");
while($s = mysqli_fetch_assoc($a)){
$nam = base64_decode($s['service_name']);
$sid = $s['service_id'];
$narx = $s['service_price'];
$curr = $s['api_currency'];
$cancel = explode(":",$s['api_detail'])[5];
$cancel = str_replace(['"',',','refill'],['','',''], $cancel);
if($cancel=="false"){
$cancel = "kuzatilmaydi";
}else{
$cancel = "mavjud";
}
$dripfeed = explode(":",$s['api_detail'])[7];
$dripfeed = str_replace("}","",$dripfeed);
$dripfeed = str_replace('"','',$dripfeed);
if($dripfeed == "true"){
$dripfeed = "ha";
}else{
$dripfeed = "yo‘q";
}
$ab = $s['service_desc'] ? $ab=$s['service_desc'] : null;
$api = $s['api_service'];
$type=$s['service_type'];
$spi = $s['service_api'];
$min=$s["service_min"];
$max=$s["service_max"];
}

if($cid2==$admin){
$edit="📝 Xizmatni tahrirlash";
}

$ap = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM providers WHERE id = $api"));
$surl=$ap['api_url'];
$skey=$ap['api_key'];
$j=json_decode(get($surl."?key=".$skey."&action=services"), true);
foreach($j as $el){
if($el['service']==$spi){
$amin=$el["min"];
$amax=$el["max"];
break;
}
}


if($curr=="USD"){
$fr=get("set/usd");
}elseif($curr=="RUB"){
$fr=get("set/rub");
}elseif($curr=="INR"){
$fr=get("set/inr");
}elseif($curr=="TRY"){
$fr=get("set/try");
}
$ab ? $abs = "".base64_decode($ab)."": null;

if($type=="Default" or $type=="default"){
if(empty($abs)){
$ab = "\n🔽 <b><u>Minimal buyurtma:</u></b> $min ta
🔼 <b><u>Maksimal buyurtma:</u></b> $max ta";
}else{
$ab = " 📑 <b>Batafsil ma'lumot:</b>
<b>$abs</b>

🔽 <b><u>Minimal buyurtma:</u></b> $min ta
🔼 <b><u>Maksimal buyurtma:</u></b> $max ta";
}
}elseif($type=="Package"){
$ab = "$abs";
}
if(empty($min) or empty($max)){
bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'text'=>"⚠️ Nimadir xato ketdi qaytadan urining.",
'show_alert'=>true,
]);
}else{
edit($chat_id,$message_id,"
<blockquote>🎯 Xizmat nomi: $nam </blockquote>

🔑 <b><u>Xizmat IDsi:</u></b> <code>$sid</code>
💵 <b><u>Narxi (1000 ta)</u></b> - $narx so‘m
$ab
",json_encode([
inline_keyboard=>[
[['text'=>"$edit",'callback_data'=>"edxizm=$sid=$n2=$n3"]],
[['text'=>"✅ Buyurtma berish",'callback_data'=>"order=$spi=$min=$max=".$narx."=$type=".$api."=$sid"]],
[['text'=>"⏪ Orqaga",'callback_data'=>"tanla2=$n2=$n3"]],
]]));
exit; 
}
}

if((stripos($data,"order=")!==false)){
$oid=explode("=",$data)[1];
$omin=explode("=",$data)[2];
$omax=explode("=", $data)[3];
$orate=explode("=", $data)[4];
$otype=explode("=", $data)[5];
$prov=explode("=",$data)[6];
$serv=explode("=",$data)[7];

if($otype=="Default" or $otype=="default"){
del();
sms($chat_id,"⬇️ <b>Kerakli buyurtma miqdorini kiriting:\n\n Na'muna: <pre>1500</pre></b>",$ort);
put("user/$chat_id.step","order=default=sp1");
put("user/$chat_id.params","$oid=$omin=$omax=$orate=$prov=$serv");
put("user/$chat_id.si",$oid);
exit; 
}elseif($otype=="Package") {
del();
sms($chat_id,"📎 <b>Kerakli xavolani kiriting (https://):</b>",$ort);
put("user/$chat_id.step","order=package=sp2=1=$orate");
put("user/$chat_id.params","$oid=$omin=$omax=$orate=$prov=$serv");
put("user/$chat_id.si",$oid);
exit; 
}
}

$s=explode("=",$step);
if($s[0]=="order" and $s[1]=="default" and $s[2]=="sp1" and is_numeric($text) and joinchat($cid)==1) {
$p=explode("=",get("user/$cid.params"));
$narxi=$p[3]/1000*$text;
if($text>=$p[1] and $text<=$p[2]){
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $cid"));
if(($rew['balance']>=$narxi)){
sms($cid,"
✅ <b>«<u>$text</u>» saqlandi!</b>

📎 <i>Kerakli xavolani kiriting</i> (<u>https://</u>):",$ort);
put("user/$cid.step","order=$s[1]=sp2=$text=$narxi");
put("user/$cid.qu",$text);
exit; 
}else{
$rewe = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $cid"));
sms($cid,"❌ <b>Yetarli mablag‘ mavjud emas

💰 Buyurtma narxi: $narxi so'm
↔️ Sizning balans: ".$rewe['balance']."</b> so'm 

<i>✍️ Boshqa miqdor kiritib koring:</i>",null);
exit; 
}
}else{
sms($cid,"
⚠️ <b>Buyurtma miqdorini notog’ri kiritilmoqda
 
 ⬇️ <u>Minimal buyurtma:</u></b> $p[1]
 ⬆️ <b><u>Maksimal buyurtma:</u></b> $p[2]
 
✍️<i> Boshqa miqdor kiriting:</i>",null);
 exit;
 }
 }
 
 

if(($s[0]=="order" and ($s[1]=="default" or $s[1]=="package") and $s[2]=="sp2" and joinchat($cid)==1)){
if($s[1]=="default"){
$pc="📊 <b>Buyurtma miqdori:</b> $s[3] ta";
}
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $cid"));
if(($rew['balance']>=$s[4])){
if((mb_stripos($tx,"https://")!==false) or (mb_stripos($text,"@")!==false) ){
$msid=sms($cid,"<b>📑<u> Malumotlarni tekshirib chiqing:</u>

↔️ Buyurtma narxi:</b> $s[4] so‘m
📎 <b>Buyurtma manzili:</b> <pre>$text</pre>
$pc

📋 <i>Malumotlar to‘g‘ri bo‘lsa (✅ Tasdiqlash) tugmasiga bosing. Sizning xisobingizdan $s[4] so‘m miqdorda pul yechib olinadi va buyurtma yuboriladi.</i>

⚠️ <b>Keyinchalik buyurtmani bekor qilish imkoni bo'lmaydi!</b>",json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Tasdiqlash",'callback_data'=>"checkorder=".uniqid()]],
[['text'=>"🚫 Bekor qilish",'callback_data'=>"main"]],
]]))->result->message_id;
put("user/$cid.step","order=$s[1]=sp3=$s[3]=$s[4]=$text");
put("user/$cid.ur",$text);
exit;
}else{
sms($cid,"⚠️ <b>Havola notog’ri yuborilmoqda</b>

Qaytadan xarakat qiling",null);
}
}else{
sms($cid,"
❌ Yetarli mablag‘ mavjud emas

Hisobingizni to‘ldirib urinib koring.",$m);
}
}

$sc=explode("=",get("user/$chat_id.step"));
if((stripos($data,"checkorder=")!==false and $sc[0]=="order" and ($sc[1]=="default" or $sc[1]=="package") and $sc[2]=="sp3" and joinchat($chat_id)==1)){
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $chat_id"));
if($rew['balance']>=$sc[4]){
$sc=explode("=",get("user/$chat_id.step"));
$sp=explode("=",get("user/$chat_id.params"));
$m = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM providers WHERE id = ".$sp[4].""));
$surl = $m['api_url'];
$skey =$m['api_key'];
$j=json_decode(get($surl."?key=".$skey."&action=add&service=".get("user/$chat_id.si")."&link=".get("user/$chat_id.ur")."&quantity=".get("user/$chat_id.qu").""),1);
$jid=$j['order'];
$jer=$j['error'];
if(empty($jid)){
sms(5813831511,"
<b>⚠️ API saytda xatolik yuz berdi!
🌐 Sayt:</b> ".str_replace(["https://","/api/v2","/api/v1"],["","",""],$surl)."
<b>🔑 Kalit:</b> <code>$skey</code>
<b>‼️ Sabab:</b> ".trans(str_replace("."," ",$jer))."",null);
if($jer=="neworder.error.link_duplicate"){
$ns="❌ Siz kiritgan havolaga buyurtma bajarilmoqda! Buyurtma bajarilganidan so'ng qaytadan urining.";
}else{$ns="⚠️ Xatolik yuz berdi!";}
bot('answerCallbackQuery', [
'callback_query_id'=>$cqid,
'text'=>"$ns",
'show_alert'=>1,
]);
bot('deleteMessage',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
]);
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"🖥️ <b>Asosiy menyudasiz</b>",
'reply_markup'=>$m,
'parse_mode'=>html,
]);
unlink("user/$chat_id.step");
unlink("user/$chat_id.params");
unlink("user/$chat_id.ur");
unlink("user/$chat_id.qu");
unlink("user/$chat_id.si");
exit();
}else{
$oe = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM orders"));
$or=$oe+1;
$sav = date("Y.m.d H:i:s");
mysqli_query($connect,"INSERT INTO myorder(`order_id`,`user_id`,`retail`,`status`,`service`,`order_create`,`last_check`) VALUES ('$or','$chat_id','$sc[4]','Pending','$sp[5]','$sav','$sav');");
mysqli_query($connect,"INSERT INTO orders(`api_order`,`order_id`,`provider`,`status`) VALUES ('$jid','$or','$sp[4]','Pending');");
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $cid"));
$order =str_replace(["{order}","{order_api}"],["$or","$jid"],enc("decode",$setting['orders']));
sms($chat_id,$order,json_encode(['inline_keyboard'=>[ 
[['text'=>"🔎 | Ko‘rish",'callback_data'=>"checkorders=$or"],['text'=>"⏩ Orqaga",'callback_data'=>"absd"]],
]
]));
$bdh = $sp[4];
$bdj = $sp[5];
$ur0 = get("user/$chat_id.ur");
$qu0 = get("user/$chat_id.qu");
$si0 = get("user/$chat_id.si");
$retail = $sc[4];
$getname = bot('getchat',['chat_id'=>$chat_id]);
$name = $getname->result->first_name;
$sename = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM services WHERE service_id = $bdj"))['service_name'];
$xizmatn = base64_decode($sename);
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $chat_id"));
$new = $rew['balance']-$sc[4];
sms($orderschannel,
"<blockquote><b>🆕 𝗬𝗮𝗻𝗴𝗶 𝗯𝘂𝘆𝘂𝗿𝘁𝗺𝗮 (@$bot)

☎️ 𝗔𝗗𝗠𝗜𝗡 <a href='tg://user?id=$admin'>$admin</a></b></blockquote>

🛍️ <b>𝙱𝚞𝚢𝚞𝚛𝚝𝚖𝚊 𝙸𝙳 𝚛𝚊𝚚𝚊𝚖𝚒:</b> <code>$or</code>
🆔 <b>Xizmat id raqami:</b> <code>$bdj</code>
🔢 <b>Buyurtma miqdori:</b> $qu0 ta
📊 <b>Buyurtma narxi:</b> $retail 𝚜𝚘'𝚖 
📖 <b>Xizmat nomi:</b> $xizmatn
👤 <b>Buryurtmachi: <a href='tg://user?id=$chat_id'>$name</a>
🔗 <b>Havola</b>: <code>$ur0</code></b>
💸 <b>Burtmachini balansi:</b> $new 𝚜𝚘'𝚖",json_encode(['inline_keyboard'=>[[['text'=>"🔎 𝘽𝙪𝙮𝙪𝙧𝙩𝙢𝙖 𝙭𝙤𝙡𝙖𝙩𝙞",'callback_data'=>"orderz=$or"]]]]));
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $chat_id"));
$miqdor = $rew['balance']-$sc[4];
mysqli_query($connect,"UPDATE users SET balance=$miqdor WHERE id =$chat_id");
unlink("user/$chat_id.step");
del();
exit;
}
}
}

if(mb_stripos($data,"orderz=")!==false){
$id = str_replace("orderz=","",$data);
$response = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM orders WHERE order_id = $id"))['status'];
if($response=="Completed") {
   $status="Bajarilgan ✅";
   }
   if($response=="In progress") {
   $status="Kutilmoqda..⌛";
   }
   if($response=="Partial"){
   $status="Qayta ishlanmoqda 🔁";
   }
   if($response=="Pending"){
  $status="Bajarilmoqda..⌛";
  }
  if($response=="Processing"){
  $status="Bajarilmoqda..⌛";
  }
  if($response=="Canceled"){
  $status="Bekor qilingan ❌";
 }
bot('answerCallbackQuery',[
'callback_query_id'=>$qid,
'text'=>"
🔎 Holati: $status",
'show_alert'=>true,
]);
}




if($_GET['update']=="status"){
echo json_encode(["status"=>true,"cron"=>"Orders status"]);

$mysql=mysqli_query($connect,"SELECT * FROM `orders`");
while($mys=mysqli_fetch_assoc($mysql)){
$prv=$mys['provider'];
$order=$mys['api_order'];
$uorder=$mys['order_id'];
$mysa=mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `myorder` WHERE order_id=$uorder"));
$adm=$mysa['user_id'];
$retail=$mysa['retail'];
if($mys['status']=="Canceled" or $mys['status']=="Completed"){
}else{
$m = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM `providers` WHERE id = $prv"));
$surl = $m['api_url'];
$skey =$m['api_key'];
$sav = date("Y.m.d H:i:s");
$j=json_decode(get($surl."?key=".$skey."&action=status&order=$order"),1);
$status=$j['status'];
if($status){
mysqli_query($connect,"UPDATE orders SET status='$status' WHERE order_id=$uorder");
mysqli_query($connect,"UPDATE myorder SET status='$status', last_check='$sav' WHERE order_id=$uorder");
}
$error=$j['error'];
if(isset($error)){
$oi = $mys['order_id'];
mysqli_query($connect,"DELETE FROM myorder WHERE order_id = $oi");
}elseif($status=="Completed"){
sms($adm,"✅ <b>Sizning $uorder raqamli burtmangiz bajarildi !
' @$bot dan uzoqlashmang !</b>",json_encode([
'inline_keyboard'=>[
[['text'=>"🔎 | 𝙆𝙤‘𝙧𝙞𝙨𝙝",'callback_data'=>"checkorders=$uorder"]]]]));
}elseif($status=="Canceled"){
sms($adm,"❌ <b>Sizning $uorder raqamli burtmangiz bekor qilindi ❌

✅Hisobingizga $retail so'm qaytarildi !</b>",null);
$rew = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $adm"));
$miqdor = $retail+$rew['balance'];
mysqli_query($connect,"UPDATE users SET balance=$miqdor WHERE id =$adm");
}
}
}
}


$res = mysqli_query($connect,"SELECT*FROM users WHERE id=$cid");
while($a = mysqli_fetch_assoc($res)){
$flid = $a['id'];
}
if(mb_stripos($text,"/start BY")!==false){
$id = str_replace("/start BY","",$text);
$refid = mysqli_fetch_assoc(mysqli_query($connect,"SELECT*FROM users WHERE user_id = $id"))['id'];
if(strlen($refid)>0 and $refid>0){
if($refid == $cid){
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"⚠️ <b>Siz o‘zingizga referal bo‘lishingiz mumkin emas</b>",
'parse_mode'=>'html',
'reply_markup'=>$m,
]);
}else{
if(mb_stripos($flid,"$cid")!==false){
bot('SendMessage',[
'chat_id'=>$cid,
'text'=>"⚠️ <b>Siz bizning botimizda allaqachon mavjudsiz.</b>",
'parse_mode'=>'html',
'reply_markup'=>$m
]);
}else{
$kanal = file_get_contents("set/channel");
if(joinchat($cid)==1){
$pul = mysqli_fetch_assoc(mysqli_query($connect,"SELECT*FROM users WHERE id=$refid"))['balance'];
$a = $pul+enc("decode",$setting['referal']);
mysqli_query($connect,"UPDATE users SET balance = $a WHERE id = $refid");
$text = "🖇️ <b>Sizda yangi <a href='tg://user?id=$cid'>taklif</a> mavjud!</b>

Hisobingizga ".enc("decode",$setting['referal'])." so‘m qo'shildi!";
$p = get("user/$refid.users");
put("user/$refid.users",$p+1);
}else{
file_put_contents("user/$cid.id",$refid);
$text = "🖇️ <b>Sizda yangi <a href='tg://user?id=$cid'>taklif</a> mavjud 🚀!</b>";
}
bot('sendMessage',[
'chat_id'=>$cid,
    'text'=>"🖥 <b>Asosiy menyudasiz.</b>",
    'parse_mode'=>'html',
'reply_markup'=>$m,
]);
bot('SendMessage',[
'chat_id'=>$refid,
'text'=>$text,
'parse_mode'=>'html',
]);
adduser($cid);
}
}
}
}


if($message){
adduser($cid);
}

if($data == "payme"){
$step = file_get_contents("step/$cid2.dav");
bot('sendmessage',[
'chat_id'=>$cid2,
'text'=>"<b>💵 To'lov miqdorini kiriting

🔸 Minimal miqdor:</b> 1000",
'parse_mode'=>html,
'reply_markup'=>$ort
]);
file_put_contents("user/$cid2.step","payme");
exit;
}

if($step=="payme" and $text != "⬅️ Orqaga"){
if(preg_match('%^[0-9]%',trim($text))){
if($text>=1000 and $text<=100000000000){
$json=json_decode(get("https://smart.missim.uz/create?key=$payme_id&amount=$text"),1);
$card=$json['card'];
$amount=$json['amount'];
$sum = $amount/100;
$olasan = $amount+$sum;
sms($cid,"<b>✅ To'lov miqdori qabul qilindi!

💰 To'lov aniq bo'lishi uchun $amount so'm to'lov qilishingiz kerak ✅

💳 Payme Karta: <code>$card</code>

➕ Bot hisobingizga $amount so'm o'tkaziladi!</b>

<blockquote>[ ⚡️Hozirda Har Qanday To'lovga 1% chegirma🔥]</blockquote>",json_encode([
'inline_keyboard'=>[
    [["text"=>"🔁 Tekshirish","callback_data"=>"tek|$amount"]],
]]));
unlink("user/$cid.step");
exit();
}else{
sms($cid,"<b>⬇️Minimal:</b> 1000 so'm",null);
exit();
}  
}else{
sms($cid,"🔢 Faqat raqamlardan foydalaning!",null);
exit();
}
}


///tasdiqlash

if((stripos($data,"tek|")!==false)){
    $amount=explode("|",$data)[1];
    $json=json_decode(get("https://smart.missim.uz/checkout?key=$payme_id&amount=$amount&day=$day"),1);
    $status=$json['status'];
    $pay_id = $json['id'];
    $sum = $amount/100;
    $olasan = $amount+$sum;

    $ids=file_get_contents("step/payments.txt");

    // To'lov ID si avval kiritilganligini tekshirish
    if(mb_stripos($ids,$pay_id)!==false){
    bot("answerCallbackQuery",[
  "callback_query_id"=>$qid,
  "text"=>"⚠️ To'lov O'tkazilgan!",
  "show_alert"=>true,
  ]);
  exit;
    }

    if($status == "payed"){
        // To'lovni qayd etishdan oldin tekshirish va faylga yozish
        file_put_contents("step/payments.txt","\n".$pay_id,FILE_APPEND);
        del();
        sms($cid2,"✅ Hisobingizga $olasan so'm qoʻshildi!",null);
        sms($admin,"🆕 Botga To'lov Qilindi! [ <code>$cid2</code> ]

<u>🗄 To'lov Usuli:</u> <code>💳 PAYME [AVTO]</code>
<u>💰 To'lov: </u> <code>$amount so'm</code>

<u>⏰Soat:</u> <code>$soat</code> | <u>📅Sana:</u> <code>$sana</code>",json_encode([
            'inline_keyboard'=>[
                [["text"=>"👁Ko'rish","url"=>"tg://user?id=$cid2"]],
            ]]));
    $kabinet = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $cid2"));
    $a = $kabinet['balance'] + $olasan;
    mysqli_query($connect,"UPDATE users SET balance = '$a' WHERE id = $cid2");
        exit();
    }else{
    bot("answerCallbackQuery",[
  "callback_query_id"=>$qid,
  "text"=>"⚠️ To'lov Qilinmagan!",
  "show_alert"=>true,
  ]);
  exit;
    }
}

if($text=="📞 Nomer olish" or $text=="/numbers" and joinchat($cid)==1){
sms($cid, "<b>❗️Bo'limdan foydalanish uchun ushbu shartlarga roziligingizni bildiring

- Sizga virtual nomer berilganda uni bemalol almashtirishingiz yoki bekor qilishingiz mumkin bo'ladi va buning uchun pul olinmaydi
- Agar sizga sms kod kelsa virtual nomerni boshqa almashtirolmaysiz va nomer uchun pul yechiladi
- Agarda kelgan kod notog'ri bo'lsa siz berilgan 10 daqiqa ichida yangi sms kod so'rashingiz mumkin va buning uchun ortiqcha pul olinmaydi
- Agar sizga sms kelsa lekin nomerga kira olmasangiz hamda berilgan 20 daqiqani ham o'tkazib yuborsangiz nomer baribir sizga sotilgan hisoblanadi va buning uchun da'volar qabul qilinmaydi
- Bot orqali olgan nomeringizni o'chirsangiz yoki u block bo'lsa nomer tiklab berilmaydi
- Telegram uchun nomer olganingizda Kod telegram orqali yuborildi deyilgan habar chiqsa nomerni darhol bekor qiling! (Aks holda katta ehtimol bilan nomerda 2 bosqichli parol o'rnatilgan bo'lishi mumkin)

☝️ Yuqoridagi holatlar uchun da'volar qabul qilinmaydi chunki bunga rozilik bildirgan bo'lasiz.</b>", json_encode([
'inline_keyboard'=>[
[['text'=>"✅ Roziman",'callback_data'=>"hop"]],
[['text'=>"❌ Bekor qilish",'callback_data'=>"menu"]],
]]));
}

if($data=="hop") {
$url = json_decode(file_get_contents("https://api.sms-activate.org/stubs/handler_api.php?api_key=$simkey&action=getCountries"), true);
$urla = file_get_contents("https://api.sms-activate.org/stubs/handler_api.php?api_key=$simkey&action=getCountries");
if($urla=="BAD_KEY" or $urla=="NO_KEY"){
bot('answerCallbackQuery',[
'callback_query_id'=>$qid,
'text'=>"⚠️ Botga API kalit ulanmagan!",
'show_alert'=>true,
]);
}else{
$key = [];
if($url["$i"]['eng'] == "Russia"){
$n = "🇷🇺 Rossiya";
}else{     
}
}
for ($i = 0; $i < 10; $i++){
if($url["$i"]['eng'] == "Russia"){
$n = "🇷🇺 Rossiya";
}elseif ($url["$i"]['eng'] == "Ukraine"){
$n = "🇺🇦 Ukraina";
}elseif ($url["$i"]['eng'] == "Kazakhstan"){
$n = "🇰🇿 Qozog'iston";
}elseif ($url["$i"]['eng'] == "China"){
$n = "🇨🇳 Xitoy";
}elseif ($url["$i"]['eng'] == "Philippines"){
$n = "🇵🇭 Filippin";
}elseif ($url["$i"]['eng'] == "Myanmar"){
$n = "🇲🇲 Myanma";
}elseif ($url["$i"]['eng'] == "Indonesia"){
$n = "🇮🇩 Indoneziya";
}elseif ($url["$i"]['eng'] == "Malaysia"){
$n = "🇲🇾 Malayziya";
}elseif ($url["$i"]['eng'] == "Kenya"){
$n = "🇰🇪 Keniya";
}elseif ($url["$i"]['eng'] == "Tanzania"){
$n = "🇹🇿 Tanzaniya";
}
$key[] = ["text" => "$n", 'callback_data' => "raqam=".$url["$i"]['id']."=".$url["$i"]['eng']];
}
$key1 = array_chunk($key,1);
$key1[]=[["text"=>" ","callback_data"=>"nu2ll"],["text"=>"1/5","callback_data"=>"null"],['text'=>"⏩",'callback_data'=>"davlat2"]];
bot('editMessageText',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
'text'=>"⤵️ Kerakli davlatni tanlang", 
'parse_mode'=>'markdown',
'reply_markup' => json_encode([
'inline_keyboard'=>$key1,
]),
]);
}

if($data=="davlat2") {
$key = [];
$url = json_decode(file_get_contents("https://api.sms-activate.org/stubs/handler_api.php?api_key=$simkey&action=getCountries"), true);
for ($i = 10; $i < 20; $i++) {
if($url["$i"]['eng'] == "Vietnam"){
$n = "🇻🇳 Vetnam";
}elseif ($url["$i"]['eng'] == "Kyrgyzstan"){
$n = "🇰🇬 Qirg'iziston";
}elseif ($url["$i"]['eng'] == "USA (virtual)"){
$n = "🇺🇸 AQSH";
}elseif ($url["$i"]['eng'] == "Israel"){
$n = "🇮🇱 Isroil";
}elseif ($url["$i"]['eng'] == "HongKong"){
$n = "🇭🇰 Gonkong";
}elseif ($url["$i"]['eng'] == "Poland"){
$n = "🇵🇱 Polsha";
}elseif ($url["$i"]['eng'] == "England"){
$n = "🏴󠁧󠁢󠁥󠁮󠁧󠁿 Angliya";
}elseif ($url["$i"]['eng'] == "Madagascar"){
$n = "🇲🇬 Madagaskar";
}elseif ($url["$i"]['eng'] == "DCongo"){
$n = "🇨🇬 Kongo";
}elseif ($url["$i"]['eng'] == "Nigeria"){
$n = "🇳🇬 Nigeriya";
}
$key[] = ["text" =>"$n", 'callback_data' => "raqam=".$url["$i"]['id']."=".$url["$i"]['eng']];
}
$key1 = array_chunk($key,1);
$key1[]=[['text'=>"⏪",'callback_data'=>"hop"],["text"=>"2/5","callback_data"=>"null"],['text'=>"⏩",'callback_data'=>"davlat3"]];
bot('editMessageText',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
'text'=>"⤵️ Kerakli davlatni tanlang", 

'parse_mode'=>'markdown',
'reply_markup' => json_encode([
 'inline_keyboard'=>$key1,
 ]),
]);
}

if($data=="davlat3") {
$key = [];
$url = json_decode(file_get_contents("https://api.sms-activate.org/stubs/handler_api.php?api_key=$simkey&action=getCountries"), true);
for ($i = 20; $i < 30; $i++) {
if($url["$i"]['eng'] == "Macao"){
$n = "🇲🇴 Makao";
}elseif ($url["$i"]['eng'] == "Egypt"){
$n = "🇪🇬 Misr";
}elseif ($url["$i"]['eng'] == "India"){
$n = "🇮🇳 Hindiston";
}elseif ($url["$i"]['eng'] == "Ireland"){
$n = "🇮🇪 Irlandiya";
}elseif ($url["$i"]['eng'] == "Cambodia"){
$n = "🇰🇭 Kambodja";
}elseif ($url["$i"]['eng'] == "Laos"){
$n = "🇱🇦 Laos";
}elseif ($url["$i"]['eng'] == "Haiti"){
$n = "🇭🇹 Gaiti";
}elseif ($url["$i"]['eng'] == "Ivory"){
$n = "🇨🇮 Ivory";
}elseif ($url["$i"]['eng'] == "Gambia"){
$n = "🇬🇲 Gambiya";
}elseif ($url["$i"]['eng'] == "Serbia"){
$n = "🇷🇸 Serbiya";
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
$key[] = ["text" => "$n", 'callback_data' => "raqam=".$url["$i"]['id']."=".$url["$i"]['eng']];
}
$key1 = array_chunk($key,1);
$key1[]=[['text'=>"⏪",'callback_data'=>"davlat2"],["text"=>"3/5","callback_data"=>"null"],['text'=>"⏩",'callback_data'=>"davlat4"]];
bot('editMessageText',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
'text'=>"⤵️ Kerakli davlatni tanlang", 

'parse_mode'=>'markdown',
'reply_markup' => json_encode([
 'inline_keyboard'=>$key1,
 ]),
]);
}

if($data=="davlat4") {
$key = [];
$url = json_decode(file_get_contents("https://api.sms-activate.org/stubs/handler_api.php?api_key=$simkey&action=getCountries"), true);
for ($i = 30; $i < 40; $i++) {
if($url["$i"]['eng'] == "Yemen"){
$n = "🇾🇪 Yaman";
}elseif ($url["$i"]['eng'] == "Southafrica"){
$n = "🇿🇦 Janubiy Afrika";
}elseif ($url["$i"]['eng'] == "Romania"){
$n = "🇷🇴 Ruminiya";
}elseif ($url["$i"]['eng'] == "Colombia"){
$n = "🇨🇴 Kolumbiya";
}elseif ($url["$i"]['eng'] == "Estonia"){
$n = "🇪🇪 Estoniya";
}elseif ($url["$i"]['eng'] == "Azerbaijan"){
$n = "🇦🇿 Ozarbayjon";
}elseif ($url["$i"]['eng'] == "Canada"){
$n = "🇨🇦 Kanada";
}elseif ($url["$i"]['eng'] == "Morocco"){
$n = "🇲🇦 Marokash";
}elseif ($url["$i"]['eng'] == "Ghana"){
$n = "🇬🇭 Gana";
}elseif ($url["$i"]['eng'] == "Argentina"){
$n = "🇦🇷 Argentina";
}  
$key[] = ["text" => "$n", 'callback_data' => "raqam=".$url["$i"]['id']."=".$url["$i"]['eng']];
}
$key1 = array_chunk($key,1);
$key1[]=[['text'=>"⏪",'callback_data'=>"davlat3"],["text"=>"4/5","callback_data"=>"null"],['text'=>"⏩",'callback_data'=>"davlat5"]];
bot('editMessageText',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
'text'=>"⤵️ Kerakli davlatni tanlang", 

'parse_mode'=>'markdown',
'reply_markup' => json_encode([
 'inline_keyboard'=>$key1,
]),
]);
}

if($data=="davlat5") {
$key = [];
$url = json_decode(file_get_contents("https://api.sms-activate.org/stubs/handler_api.php?api_key=$simkey&action=getCountries"), true);
for ($i = 40; $i < 50; $i++) {
if($url["$i"]['eng'] == "Uzbekistan"){
$n = "🇺🇿 O'zbekiston";
}elseif ($url["$i"]['eng'] == "Cameroon"){
$n = "🇨🇲 Kamerun";
}elseif ($url["$i"]['eng'] == "Chad"){
$n = "🇹🇩 Chad";
}elseif ($url["$i"]['eng'] == "Germany"){
$n = "🇩🇪 Germaniya";
}elseif ($url["$i"]['eng'] == "Lithuania"){
$n = "🇱🇹 Litva";
}elseif ($url["$i"]['eng'] == "Croatia"){
$n = "🇭🇷 Xorvatiya";
}elseif ($url["$i"]['eng'] == "Sweden"){
$n = "🇸🇪 Shvetsiya";
}elseif ($url["$i"]['eng'] == "Iraq"){
$n = "🇮🇶 Iroq";
}elseif ($url["$i"]['eng'] == "Netherlands"){
$n = "🇳🇱 Niderlandiya";
}elseif ($url["$i"]['eng'] == "Latvia"){
$n = "🇱🇻 Latviya";
} 
$key[] = ["text" => "$n", 'callback_data' => "raqam=".$url["$i"]['id']."=".$url["$i"]['eng']];
}
$key1 = array_chunk($key,1);
$key1[]=[['text'=>"⏪",'callback_data'=>"davlat4"],["text"=>"5/5","callback_data"=>"null"],["text"=>" ","callback_data"=>"null1"]];
bot('editMessageText',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
'text'=>"⤵️ Kerakli davlatni tanlang", 

'parse_mode'=>'markdown',
'reply_markup' => json_encode([
 'inline_keyboard'=>$key1,
 ]),
]);
}


if(mb_stripos($data,"buy=")!==false){
$ex=explode("=",$data);
$xizmat=$ex[1];
$dav=$ex[3];
$json = json_decode(file_get_contents("https://api.sms-activate.org/stubs/handler_api.php?api_key=$simkey&action=getTopCountriesByService&operator=any&service=".$xizmat), true);
$id=$ex[2];
$country = $id;
foreach($json as $element){
if($element['country'] == $country){
$rate=$element['retail_price'];
$tson=$element['count'];
break; 
}
}
if(empty($tson)){
$tson=0;
}else{
$tson=$tson;
}
$rate=$rate*$simrub;
$rp=$rate/100;
$na=$rp*$simfoiz+$rate;
bot('deleteMessage',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
]);
bot('sendMessage',[
'chat_id'=>$cid2,
'text'=>"🌍 <b>Davlat:</b> $dav

🔢 <b>Qolgan raqamlar:</b> $tson ta
💰 <b>Raqam narxi:</b> $na so‘m",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"💸 Sotib olish - $na so'm",'callback_data'=>"olish=$xizmat=$id=any=$na"]],
[['text'=>"⏪ Orqaga",'callback_data'=>"raqam=$id=$dav"]],
]])
]);
}

if(mb_stripos($data, "raqam=")!==false){
$ex = explode("=",$data);
$id = $ex[1];
$davlat = $ex[2];
$urla = file_get_contents("https://api.sms-activate.org/stubs/handler_api.php?api_key=$simkey&action=getCountries");
if($urla=="BAD_KEY" or $urla=="NO_KEY"){
bot('answerCallbackQuery',[show_alert=>1,
'callback_query_id'=>$qid,
'text'=>"⚠️ Botga API kalit ulanmagan!",
]);
}else{
bot('editMessageText',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
'text'=>"📲 *O'zingizga kerakli tarmoqni tanlang:*",
'parse_mode'=>'markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$me Telegram ",'callback_data'=>"buy=tg=$id=$davlat"],['text'=>"$me Instagram",'callback_data'=>"buy=ig=$id=$davlat"]],
[['text'=>"$me Viber",'callback_data'=>"buy=vi=$id=$davlat"],['text'=>"$me Facebook",'callback_data'=>"buy=fb=$id=$davlat"]],
[['text'=>"$me TikTok",'callback_data'=>"buy=lf=$id=$davlat"],['text'=>"$me Twitter",'callback_data'=>"buy=tw=$id=$davlat"]],
[['text'=>"$me WhatsApp",'callback_data'=>"buy=wh=$id=$davlat"],['text'=>"$me Google",'callback_data'=>"buy=go=$id=$davlat"]],
[['text'=>"$me Imo",'callback_data'=>"buy=im=$id=$davlat"],['text'=>"$me Snapchat",'callback_data'=>"buy=fu=$id=$davlat"]],
[['text'=>"$me Mail.ru",'callback_data'=>"buy=ma=$id=$davlat"],['text'=>"$me OLX",'callback_data'=>"buy=sn=$id=$davlat"]],
[['text'=>"$me PayPal",'callback_data'=>"buy=ts=$id=$davlat"],['text'=>"$me Yandex",'callback_data'=>"buy=ha=$id=$davlat"]],
[['text'=>"$me Stream",'callback_data'=>"buy=mt=$id=$davlat"],['text'=>"$me Tinder",'callback_data'=>"buy=oi=$id=$davlat"]],
[['text'=>"🏠 Menyu",'callback_data'=>"hop"]],
]])
]);
}}


if(stripos($data,"olish=")!==false){
$xiz=explode("=",$data)[1];
$id=explode("=",$data)[2];
$op=explode("=",$data)[3];
$pric=explode("=",$data)[4];
$kabinet = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $cid2"));
if($kabinet['balance']>=$pric){
$arrContextOptions=array(
"ssl"=>array(
"verify_peer"=>false,
"verify_peer_name"=>false,),);
$response = file_get_contents("https://api.sms-activate.org/stubs/handler_api.php?api_key=$simkey&action=getNumber&service=$xiz&country=$id&operator=$op", false, stream_context_create($arrContextOptions));
$pieces = explode(":",$response);
$simid = $pieces[1];
$phone = $pieces[2];
if($response=="NO_NUMBERS") {
$msgs="Raqamlar qolmadi!";
}elseif($response=="NO_BALANCE") {
$msgs="⚠️ Xatolik yuz berdi!";
}
if($response == "NO_NUMBERS" or $response == "NO_BALANCE"){
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
'text'=>$msgs,
"show_alert"=>true,
]);
}elseif(mb_stripos($response,"ACCESS_NUMBER")!==false){
$a = $kabinet['balance'] - $pric;
mysqli_query($connect,"UPDATE users SET balance = '$a' WHERE id = $cid2");
bot('editmessagetext',[
'chat_id'=>$cid2,
'message_id'=>$mid2,
'text'=>"<b>✅ Raqam olindi!</b>

<b>📲 Narx:</b> $pric so‘m
<b>📞 Nomer:</b> <code>+$phone</code>

<b>⚠️ Diqqat o'qing:
👤 Olgan nomeringiz o'chib ketsa bunga javob bermaymiz!
	
🌐 Telegram uchun nomerga faqat rasmiy Telegram??ga sms keladi.

🔑 Kod botga keladi!

Nomerni 5-15 daqiqa ichida bekor qilish mumkin, nomerni bekor qilsangiz hisobingiz pular to'liq qaytariladi *️⃣</b>",
'parse_mode'=>'html',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"📩 SMS-kod olish",'callback_data'=>"pcode_".$simid."_".$pric]],
[['text'=>"❌ Bekor qilish",'callback_data'=>"otmena_".$simid."_".$pric],],
]
])
]);
bot('sendMessage',[
'chat_id'=>$admin,
'text'=>"📞 Yangi nomer olindi: <code>+$phone</code>

💰 Nomer narxi: $pric so'm

👤Buyurtmachi: <code>$cid2</code> <a href='tg://user?id=$cid2'>Ko'rish</a>
⏺ Oldingi Balansi: ".$kabinet['balance']." so'm
➡️ Yangi Balansi: $a so'm",
'parse_mode'=>'html',
]);
}
}else{
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
'text'=>"⛔️ Mablag'ingiz yetarli emas!",
"show_alert"=>true,
]);
}
}
if(stripos($data,"pcode_")!==false){
$ex=explode("_",$data);
$simid=$ex[1];
$so=$ex[2];
$kabinet = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $cid2"));
$sims=file_get_contents("simcard.txt");
if(mb_stripos($sims,$simid)!==false){
bot('answerCallbackQuery',[
'callback_query_id'=>$qid,
'text'=>"⛔️ Nomalum buyruq!",
'show_alert'=>true,
]);
exit();
}else{
$response = file_get_contents("https://api.sms-activate.org/stubs/handler_api.php?api_key=$simkey&action=getStatus&id=$simid", false);
if (mb_stripos($response,"STATUS_OK")!==false){
$pieces = explode(":", $response);
$smskod = $pieces[1];
bot('sendMessage',[
'chat_id'=>$cid2,
'text'=>"🔑 Faollashtirish kodi: $smskod",
'parse_mode'=>'markdown',
]);
}elseif($response=="STATUS_CANCEL") {
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
'text'=>"✔️ Balansingizga $so so‘m qaytarildi",
"show_alert"=>true,
]);
$a = $kabinet['balance'] + $so;
mysqli_query($connect,"UPDATE users SET balance = '$a' WHERE id = $cid2");
file_put_contents("simcard.txt","\n".$simid,FILE_APPEND);
}elseif($response=="BAD_STATUS") {
bot('sendMessage',[
'chat_id'=>$cid2,
'text'=>"🖥 Asosiy menyudasiz",
'parse_mode'=>'markdown',
]);
}else{
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
'text'=>"Kirish kodi kelmadi kuting..",
"show_alert"=>true,
]);
}
}
}

if(stripos($data,"otmena_")!==false){
$simid=explode("_",$data)[1];
$so=explode("_",$data)[2];
$kabinet = mysqli_fetch_assoc(mysqli_query($connect,"SELECT * FROM users WHERE id = $cid2"));
$sims=file_get_contents("simcard.txt");
$response = file_get_contents("https://api.sms-activate.org/stubs/handler_api.php?api_key=$simkey&action=setStatus&status=8&id=$simid");
if(mb_stripos($sims,$simid)!==false){
bot('answerCallbackQuery',[
'callback_query_id'=>$qid,
'text'=>"⛔️ Nomalum buyruq!",
'show_alert'=>true,
]);
exit();
}else{
if(mb_stripos($response,"ACCESS_CANCEL")!==false){ bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
'text'=>"✔️ Balansingizga $so so‘m qaytarildi",
"show_alert"=>true,
]);
$a = $kabinet['balance'] + $so;
mysqli_query($connect,"UPDATE users SET balance = '$a' WHERE id = $cid2");
file_put_contents("simcard.txt","\n".$simid,FILE_APPEND);
}else{
bot("answerCallbackQuery",[
"callback_query_id"=>$update->callback_query->id,
'text'=>" Iltimos 1 - 2 daqiqa kuting...",
"show_alert"=>true,
]);
bot('sendMessage',[
'chat_id'=>$cid2,
'text'=>"🖥 Asosiy menyudasiz",
'parse_mode'=>'markdown',
]);
}
}//Ushbu kodni @SARVAR_6364 TUZIB CHIQGAN
}